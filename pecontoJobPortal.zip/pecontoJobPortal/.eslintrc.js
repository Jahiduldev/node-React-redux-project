module.exports = {
    "extends": ["standard", 'plugin:react/recommended'],
    rules: {
        semi: [2, 'always'],
        'handle-callback-err': "error"
    },
    settings: {
        react: {
          version: 'detect',
        },
    },
};
