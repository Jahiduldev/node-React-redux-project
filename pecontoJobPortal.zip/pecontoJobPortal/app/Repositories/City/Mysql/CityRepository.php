<?php

namespace App\Repositories\City\Mysql;

use App\Models\City;
use App\Repositories\City\CityRepositoryInterface;

class CityRepository implements CityRepositoryInterface
{

    protected $model = '';

    /**
     * CityRepository constructor.
     * @param City $model
     */
    public function __construct(City $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return City|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->model->create($data))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return City|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return City
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return City
     */
    public function getModel()
    {
        return $this->model;
    }
}
