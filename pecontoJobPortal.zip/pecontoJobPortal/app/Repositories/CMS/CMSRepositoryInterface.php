<?php

namespace App\Repositories\CMS;

interface CMSRepositoryInterface
{
    public function get();

    public function find($id);

    public function update(array $data);

    public function delete();

    public function getModel();
}
