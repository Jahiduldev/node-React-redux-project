<?php

namespace App\Repositories\CMS\Mysql;


use App\Models\CMS;
use App\Repositories\CMS\CMSRepositoryInterface;

class CMSRepository implements CMSRepositoryInterface
{

    protected $model = '';

    /**
     * CMSRepository constructor.
     * @param CMS $model
     */
    public function __construct(CMS $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
            ? $this
            : null;
    }

    /**
     * @param array $data
     * @return CMS|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
            ? $this->model
            : false;
    }

    /**
     * @return CMS
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
            ? $model
            : false;
    }

    /**
     * @return CMS
     */
    public function getModel()
    {
        return $this->model;
    }
}
