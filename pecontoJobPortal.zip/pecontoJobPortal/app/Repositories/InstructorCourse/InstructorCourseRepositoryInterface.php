<?php

namespace App\Repositories\InstructorCourse;

interface InstructorCourseRepositoryInterface
{
    public function get();

    public function getByUser($id);

    public function find($id);

    public function create(array $data);

    public function update(array $data);

    public function delete();

    public function getModel();
}
