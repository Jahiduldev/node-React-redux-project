<?php

namespace App\Repositories\ContactUs\MySQL;

use App\Models\ContactUs;
use App\Repositories\ContactUs\ContactUsRepositoryInterface;

class ContactUsRepository implements ContactUsRepositoryInterface
{

    protected $model = '';

    protected $contactUsMsg = "Visitor with Name: %s, and Email: %s, sent you an Email.";

    /**
     * ContactUsRepository constructor.
     * @param ContactUs $model
     */
    public function __construct(ContactUs $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return ContactUs|boolean false
     */
    public function create(array $data)
    {
        $return = ($this->model = $this->model->create($data))
        ? $this->model
        : false;

        // Notify App Owner
        $this->mail($data);

        return $return;
    }

    /**
     * @param array $data
     * @return ContactUs|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return ContactUs
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return ContactUs
     */
    public function getModel()
    {
        return $this->model ? $this->model : new ContactUs;
    }
    
    protected function mail($data)
    {
        $msg = sprintf($this->contactUsMsg, $data['name'], $data['email']);
        $body = $msg ." <br> ". $data['content'];

        \Mail::send([], [], function ($message) use ($data, $body) {
            $message->from($data['email']);
            $message->to(config('services.contactus_email'))
                ->subject($data['subject'])
                ->setBody($body, 'text/html');
        });
    }
}
