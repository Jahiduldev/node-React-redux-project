<?php

namespace App\Repositories\Course\Mysql;

use App\Models\Course;
use App\Repositories\Course\CourseRepositoryInterface;

class CourseRepository implements CourseRepositoryInterface
{
    protected $model = '';

    /**
     * CourseRepository constructor.
     * @param Course $model
     */
    public function __construct(Course $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @return mixed
     */
    public function getByUser($id, $perPage = 10)
    {
        $this->model = $this->model->where('user_id', $id)->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    public function getCoursesByCategoryId($categoryId)
    {
        return $this->model->where('category_id', $categoryId)->get();
    }

    /**
     * @param array $data
     * @return Course|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->model->create($data))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return Course|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Course
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Course
     */
    public function getModel()
    {
        return $this->model;
    }
}
