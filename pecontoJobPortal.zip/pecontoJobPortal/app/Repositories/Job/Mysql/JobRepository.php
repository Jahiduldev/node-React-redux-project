<?php

namespace App\Repositories\Job\MySQL;

use App\Models\Job;
use App\Repositories\Job\JobRepositoryInterface;

class JobRepository implements JobRepositoryInterface
{

    protected $model = '';

    /**
     * JobRepository constructor.
     * @param Job $model
     */
    public function __construct(Job $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        if (auth()->user()->role == 'instructor') {
            return $this->model->paginate($perPage);
        }
        return $this->model->where('user_id', auth()->user()->id)->paginate($perPage);
    }

    /**
     * @param $id
     * @return mixed
     */

    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }
    public function filter()
    {
        // filter
        $query = $this->model::orderby('title');
        if (request()->has('title') && ! empty(request('title'))) {
            $query->where('title', 'LIKE', '%' . request('title') . '%');
        }

        if (request()->has('category_id') && ! empty(request('category_id'))) {
            $query->where('category_id', request('category_id'));
        }

        if (request()->has('country_id') && ! empty(request('country_id'))) {
            $query->where('country_id', request('country_id'));
        }

        if (request()->has('city_id') && ! empty(request('city_id'))) {
            $query->where('city_id', request('city_id'));
        }

        if (request()->has('course_lang') && ! empty(request('course_lang'))) {
            $query->where('course_lang', request('course_lang'));
        }

        if (request()->has('payment') && ! empty(request('payment'))) {
            switch (request('payment')) {
                case 'fixed':
                    $query->whereNotNull('fixed_amount');
                    break;

                case 'hourly':
                    $query->whereNotNull('hourly_rate');
                    break;

                default:
                    # code...
                    break;
            }
        }
        return $query->get();
    }



    /**
     * @param string $key
     * @return mixed
     */
    public function search(string $key)
    {

        $query =  $this->model::orderby('title')
            ->where('title', 'LIKE', '%' . $key . '%');

        return request()->has('perPage')
        ? $query->paginate(request('perPage'))
        : $query->limit(10)->get();
    }

    /**
     * @param array $data
     * @return Job|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->model->create(array_merge($data, ['user_id' => auth()->user()->id])))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return Job|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Job
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Job
     */
    public function getModel()
    {
        return $this->model;
    }
}
