<?php

namespace App\Repositories\Job;

interface JobRepositoryInterface
{
    public function get();

    public function find($id);
    
    public function filter();

    public function search(string $key);

    public function create(array $data);

    public function update(array $data);

    public function delete();

    public function getModel();
}
