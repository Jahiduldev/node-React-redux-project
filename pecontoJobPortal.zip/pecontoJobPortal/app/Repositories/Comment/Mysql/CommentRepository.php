<?php

namespace App\Repositories\Comment\MySQL;

use App\Models\Comment;
use App\Repositories\Comment\CommentRepositoryInterface;

class CommentRepository implements CommentRepositoryInterface
{

    protected $model = '';

    protected $notifyMsg = "%s has commented your Post.";

    /**
     * CommentRepository constructor.
     * @param Comment $model
     */
    public function __construct(Comment $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->orderBy('id', 'DESC')->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return Comment|boolean false
     */
    public function create(array $data)
    {
        $return = ($this->model = $this->model->create($data))
        ? $this->model
        : false;

        // Notify Owner
        $this->notifyOwner(
            "\App\Notifications\CommentedPost",
            "\App\Models\Post",
            $data['post_id'],
            $this->notifyMsg
        );

        return $return;
    }

    /**
     * @param array $data
     * @return Comment|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Comment
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Comment
     */
    public function getModel()
    {
        return $this->model;
    }

    protected function notifyOwner($notifyClass, $postClass, $postId, $msg)
    {
        // Get Owner
        if (! $post = (new $postClass)->find($postId)) {
            return false;
        }
        $owner = $post->user;
        // Notify Owner
        $setting = $owner->setting;
        if ($setting && $setting->notify_on_comment_post) {
            $msg = sprintf($msg, auth()->user()->full_name, auth()->user()->email);
            $owner->notify(new $notifyClass($msg));
        }
        // save message in database
        helper()->saveMessage($owner->id, auth()->user()->id, $msg);
    }
}
