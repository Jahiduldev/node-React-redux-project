<?php

namespace App\Repositories\Apply\MySQL;

use App\Models\Apply;
use App\Repositories\Apply\ApplyRepositoryInterface;

class ApplyRepository implements ApplyRepositoryInterface
{

    protected $model = '';

    protected $notifyMsg = "%s has Applied to your Job Application.";

    /**
     * ApplyRepository constructor.
     * @param Apply $model
     */
    public function __construct(Apply $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @return mixed
     */
    public function getByJob($jobId, $perPage = 10)
    {
        $this->model = $this->model->where('job_id', $jobId)->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return Apply|boolean false
     */
    public function create(array $data)
    {
        $return = (helper()->applyUploadHandler($data) && $this->model = $this->model->create(array_merge($data, ['user_id' => \Auth::id()])))
        ? $this->model
        : false;


        // Notify Owner
        $this->notifyOwner(
            "\App\Notifications\AppliedJob",
            "\App\Models\Job",
            $data['job_id'],
            $this->notifyMsg
        );

        return $return;
    }

    /**
     * @param array $data
     * @return Apply|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Apply
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Apply
     */
    public function getModel()
    {
        return $this->model;
    }

    protected function notifyOwner($notifyClass, $jobClass, $jobId, $msg)
    {
        // Get Owner
        if (! $job = (new $jobClass)->find($jobId)) {
            return false;
        }
        $owner = $job->user;


        // Notify only if the user is Company (user)
        $setting = $owner->setting;
        if ($setting && $setting->notify_on_apply_job) {
            // Notify Owner
            $msg = sprintf($msg, auth()->user()->full_name, auth()->user()->email);
            if ($owner->role === $owner->rolesMap['Company']) {
                $owner->notify(new $notifyClass($msg));

            }
        }
        // save message in database
        helper()->saveMessage($owner->id, auth()->user()->id, $msg);
    }
}
