<?php

namespace App\Repositories\Experience;

interface ExperienceRepositoryInterface
{
    public function get();

    public function getByUser($id);

    public function find($id);

    public function create(array $data);

    public function update(array $data);

    public function delete();

    public function getModel();
}
