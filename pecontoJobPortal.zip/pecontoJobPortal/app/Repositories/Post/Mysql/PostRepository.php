<?php

namespace App\Repositories\Post\MySQL;

use App\Models\Post;
use App\Repositories\Post\PostRepositoryInterface;

class PostRepository implements PostRepositoryInterface
{

    protected $model = '';

    /**
     * PostRepository constructor.
     * @param Post $model
     */
    public function __construct(Post $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 5)
    {
        $this->model = $this->model->orderBy('id', 'DESC')->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return Post|boolean false
     */
    public function create(array $data)
    {
        return (helper()->postUploadHandler($data) && $this->model = $this->model->create($data))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return Post|boolean false
     */
    public function update(array $data)
    {
        return (helper()->postUploadHandler($data) && $this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Post
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Post
     */
    public function deleteImage()
    {
        $imageName = $this->model->image;
        $this->model->image = null;
        return (helper()->deletePostImage($imageName) && $this->model->save())
        ? $this->model
        : false;
    }

    /**
     * @return Post
     */
    public function getModel()
    {
        return $this->model;
    }

    public function findByCategory($category_id, $perPage = 10)
    {
        $this->model = $this->model->orderBy('id', 'DESC')->where('category_id', $category_id)->paginate($perPage);
        return $this->model;
    }
}
