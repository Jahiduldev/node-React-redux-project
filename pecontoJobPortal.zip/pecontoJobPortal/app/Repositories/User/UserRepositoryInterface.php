<?php

namespace App\Repositories\User;

interface UserRepositoryInterface
{
    public function get();
    
    public function getSavedJobs();

    public function find($id);
    
    public function search(array $filters, string $search);

    public function create(array $data);

    public function update(array $data);
    
    public function updateProfile(array $data);
    
    public function saveJob(int $jobId);
    
    public function unsaveJob(int $jobId);
    
    public function delete();

    public function deleteImage(string $photo);

    public function getModel();
}
