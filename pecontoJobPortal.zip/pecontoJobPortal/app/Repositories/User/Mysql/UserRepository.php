<?php

namespace App\Repositories\User\Mysql;

use App\Models\User;
use App\Models\Setting;
use App\Models\CompanyDetail;
use Illuminate\Support\Facades\DB;
use App\Repositories\User\UserRepositoryInterface;

class UserRepository implements UserRepositoryInterface
{
    protected $model = '';

    protected $companyModel = '';

    /**
     * ReplyRepository constructor.
     * @param User $model
     */
    public function __construct(User $model, CompanyDetail $companyModel, Setting $settings)
    {
        $this->model = $model;
        $this->companyModel = $companyModel;
        $this->settings = $settings;
    }

    /**
     * @return mixed
     */
    public function get()
    {
        $this->model = $this->model->get();
        return $this->model;
    }

    /**
     * @return mixed
     */
    public function getSavedJobs($perPage = 10)
    {
        $this->model = $this->model->savedJobs()->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function find($value)
    {
        if (is_array($value)) {
            $this->model = $this->model->where([$value])->first();
            return ($this->model) ? $this : null;
        }

        // value could be username or user_id
        $this->model = is_numeric($value) ? $this->model->find($value) : $this->model->where('username', $value)->first();
        return ($this->model)
            ? $this
            : null;
    }

    /**
     * search function
     *
     * @param string $name
     * @return mixed
     */
    public function search(array $filters, string $search)
    {
        $role = $search == 'companies' ? 'user' : 'instructor';
        return $this->getModel()->where('role', $role)->where('id', '!=', auth()->user()->id)
            ->paginate(request()->has('perPage') ? request('perPage') : 10)
            ->withQueryString();
    }

    /**
     * @param array $data
     * @return User|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->getModel()->create($data))
            ? $this->model
            : false;
    }

    /**
     * @param array $data
     * @return User|boolean false
     */
    public function firstOrCreate(array $data)
    {
        return ($this->model = $this->getModel()->firstOrCreate($data))
            ? $this->model
            : false;
    }

    /**
     * @param array $data
     * @return User|boolean false
     */
    public function update(array $data)
    {
        $upload = helper()->userUploadHandler($data, [
            'photo'       => $this->model->photo,
            'cover_photo' => $this->model->cover_photo,
        ]);

        $handleName = $this->handleName($data);

        $update = $this->model->update($data);

        if ($upload && $handleName && $update) {
            // only for instructors
            return $this->updateDetails($data) ? $this->model : false;
        }

        return false;
    }

    /**
     * @param array $data
     * @return User|boolean false
     */
    protected function updateDetails(array $data)
    {

        if ($this->model->role == $this->model->rolesMap['Company'] && isset($data['first_name']) && !$data['first_name']) {
            if (!$this->updateCompany($data)) {
                return false;
            }
        }

        // Update Fields of Interest
        if (
            isset($data['fields_of_interest']) &&
            !$this->model->fieldsOfInterests()->syncWithoutDetaching($data['fields_of_interest'])
        ) {
            return false;
        }

        // Update Settings
        if (!$this->updateSettings($data)) {
            return false;
        }

        return true;
    }

    protected function updateCompany(array $data)
    {
        if (
            !empty($data['name']) ||
            !empty($data['about']) ||
            !empty($data['website']) ||
            !empty($data['category_id']) ||
            !empty($data['user_role']) ||
            !empty($data['sub_category_id'])
        ) {
            $this->companyModel->updateOrCreate(
                ['user_id' => \auth()->user()->id],
                array_merge($data, ['user_id' => \auth()->user()->id])
            );
        }

        return true;
    }

    protected function updateSettings(array $data)
    {
        $settings = [];
        foreach ($data as $field => $value) {
            // In Case the User Role is Company/Instructor
            if (in_array($field, [
                'notify_on_like_post',
                'notify_on_comment_post',
            ])) {
                $settings[$field] = $value;
            }

            // In Case the User Role is Company
            if (
                $this->model->role == $this->model->rolesMap['Company'] &&
                $field === 'notify_on_apply_job'
            ) {
                $settings[$field] = $value;
            }
        }

        return ($this->settings->updateOrCreate(
            ['user_id' => auth()->user()->id],
            array_merge($settings, ['user_id' => auth()->user()->id])
        )) ? true : false;
    }

    protected function handleName(array $data)
    {
        if (isset($data['first_name']) && isset($data['last_name'])) {
            $data['username'] = str_replace(' ', '', $data['first_name'] . $data['last_name']) . "_" . time();
        }

        return true;
    }

    /**
     * @param array $data
     * @return User|boolean false
     */
    public function updateProfile(array $data)
    {
        return ($this->model->update($data))
            ? $this->model
            : false;
    }

    /**
     * @param int $jobId
     * @return User|boolean false
     */
    public function saveJob(int $jobId)
    {
        // Do nothing if is saved before
        foreach ($this->model->savedJobs as $savedJob) {
            if ($savedJob->id == $jobId) {
                return $this->model;
            }
        }

        $this->model->savedJobs()->attach($jobId);
        return $this->model;
    }

    /**
     * @param int $jobId
     * @return User|boolean false
     */
    public function unsaveJob(int $jobId)
    {
        // Do nothing if is not saved before
        foreach ($this->model->savedJobs as $savedJob) {
            if ($savedJob->id == $jobId) {
                return ($this->model->savedJobs()->detach($jobId))
                    ? $this->model
                    : false;
            }
        }

        return $this->model;
    }

    /**
     * @return User
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
            ? $model
            : false;
    }

    /**
     * @return User
     */
    public function deleteImage(string $photo)
    {
        $imageName = $this->model->$photo;
        $this->model->$photo = null;
        return (helper()->deleteUserImage($imageName, $photo) && $this->model->save())
            ? $this->model
            : false;
    }

    /**
     * @return User
     */
    public function getModel()
    {
        return $this->model ? $this->model : new User;
    }

    public function follow()
    {
        $admin = $this->model->find(request('user_id'));
        // follow
        $status = $admin->follows()->detach(auth()->user()->id);

        if (!$status) {
            // un follow
            $admin->follows()->attach(auth()->user()->id);

            return 2;
        }
        return 1;
    }

    public function followList()
    {
        $user_field_interests = DB::table('fields_of_interests')
            ->where('user_id', auth()->user()->id)
            ->pluck('category_id')
            ->toArray();

        return $this->model->with([
            'fieldsOfInterests' => function ($q) use ($user_field_interests) {
                $q->whereIn('category_id', $user_field_interests);
            }
        ])
            ->whereDoesntHave('follows', function ($q) {
                $q->where('follower_id', auth()->user()->id);
            })
            ->where('id', '!=', auth()->user()->id)
            // ->whereDoesntHave('followsReverse')
            ->where('role', '!=', auth()->user()->role)
            ->where('role', '!=', 'admin')
            ->take(5)
            ->orderBy('id')
            ->get();
    }
}
