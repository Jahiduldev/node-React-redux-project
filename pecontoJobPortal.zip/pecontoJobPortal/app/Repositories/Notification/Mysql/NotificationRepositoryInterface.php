<?php

namespace App\Repositories\Notification\Mysql;

interface NotificationRepositoryInterface
{
}
