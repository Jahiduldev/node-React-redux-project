<?php

namespace App\Repositories\Notification\Mysql;

use App\Models\NotificationMessage;
use App\Repositories\Notification\Mysql\NotificationRepositoryInterface;

class NotificationRepository implements NotificationRepositoryInterface
{
    protected $model = '';

    public function __construct(NotificationMessage $model)
    {
        $this->model = $model;
    }

    public function myNotifications()
    {
        return $this->model->where('owner_user_id', auth()->user()->id)->take(5)->latest()->get();
    }

    public function seenNotifications($ids)
    {
        return $this->model->whereIn('id', $ids)->update(['seen' => 1]);
    }
}
