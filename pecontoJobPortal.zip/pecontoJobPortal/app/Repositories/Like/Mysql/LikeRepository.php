<?php

namespace App\Repositories\Like\MySQL;

use App\Models\Like;
use App\Repositories\Like\LikeRepositoryInterface;

class LikeRepository implements LikeRepositoryInterface
{

    protected $model = '';

    protected $relatedTo = [
        'post_id',
        'comment_id',
        'reply_id',
    ];

    protected $relatedToMap = [
        'post_id'    => '\App\Models\Post',
        'comment_id' => '',
        'reply_id'   => '',
    ];

    protected $relatedToNotifyMap = [
        'post_id'    => '\App\Notifications\LikedPost',
        'comment_id' => '',
        'reply_id'   => '',
    ];

    protected $relatedToMsgMap = [
        'post_id'    => '%s has Liked your Post.',
        'comment_id' => '',
        'reply_id'   => '',
    ];

    /**
     * LikeRepository constructor.
     * @param Like $model
     */
    public function __construct(Like $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function like(array $data)
    {
        $data['user_id'] = \Auth::id();
        $relatedTo = $this->getRelatedTo($data);
        if ($relatedTo) {
            $like = $this->model->withTrashed()
            ->where([
                $relatedTo => $data[$relatedTo],
                'user_id'  => $data['user_id'],
            ])->first();

            // Like by create
            if (! $like || ! $like->count()) {
                $this->model->create($data);

                // Notify Owner
                $this->notifyOwner(
                    $this->relatedToNotifyMap[$relatedTo],
                    $data[$relatedTo],
                    $this->relatedToMap[$relatedTo],
                    $this->relatedToMsgMap[$relatedTo]
                );

                return true;
            }

            // Like by restore
            if ($like->deleted_at) {
                $like->restore();

                // For the sake of liked_at field to be correct
                $like->updated_at = now();
                $like->save();

                // Notify Owner
                $this->notifyOwner(
                    $this->relatedToNotifyMap[$relatedTo],
                    $data[$relatedTo],
                    $this->relatedToMap[$relatedTo],
                    $this->relatedToMsgMap[$relatedTo]
                );

                return true;
            }

            // Unlike
            if (! $like->deleted_at) {
                $like->delete();
                return false;
            }
        }

        return null;
    }

    /**
     * @return Like
     */
    public function getModel()
    {
        return $this->model;
    }

    protected function getRelatedTo($data)
    {
        if (! empty($data)) {
            foreach (array_keys($data) as $key) {
                $found = array_search($key, $this->relatedTo);
                if ($found !== false) {
                    return $this->relatedTo[$found];
                }
            }
        }

        return false;
    }

    protected function notifyOwner($notifyClass, $relatedTo, $relatedToClass, $msg)
    {
        if (empty($relatedToClass)) {
            return true;
        }

        // Get Owner
        if (! $relatedToObj = (new $relatedToClass)->find($relatedTo)) {
            return false;
        }
        $owner = $relatedToObj->user;

        // Notify Owner
        $setting = $owner->setting;
        if ($setting && $setting->notify_on_like_post) {
            $msg = sprintf($msg, auth()->user()->full_name, auth()->user()->email);
            $owner->notify(new $notifyClass($msg));
        }
        // save message in database
        helper()->saveMessage($owner->id, auth()->user()->id, $msg);
    }
}
