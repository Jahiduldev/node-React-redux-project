<?php

namespace App\Repositories\Like;

interface LikeRepositoryInterface
{
    public function like(array $data);
    
    public function getModel();
}
