<?php

namespace App\Repositories\Certificate;

interface CertificateRepositoryInterface
{
    public function get();

    public function getByUser($id);

    public function find($id);

    public function create(array $data);

    public function update(array $data);

    public function delete();

    public function getModel();
}
