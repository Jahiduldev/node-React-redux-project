<?php

namespace App\Repositories\WorkplacePolicy\MySQL;

use App\Models\WorkplacePolicy;
use App\Repositories\WorkplacePolicy\WorkplacePolicyRepositoryInterface;

class WorkplacePolicyRepository implements WorkplacePolicyRepositoryInterface
{

    protected $model = '';

    /**
     * WorkplacePolicyRepository constructor.
     * @param WorkplacePolicy $model
     */
    public function __construct(WorkplacePolicy $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return WorkplacePolicy|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->model->create($data))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return WorkplacePolicy|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return WorkplacePolicy
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return WorkplacePolicy
     */
    public function getModel()
    {
        return $this->model;
    }
}
