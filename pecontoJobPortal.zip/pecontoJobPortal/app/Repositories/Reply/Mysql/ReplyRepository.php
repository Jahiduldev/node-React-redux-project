<?php

namespace App\Repositories\Reply\MySQL;

use App\Models\Reply;
use App\Repositories\Reply\ReplyRepositoryInterface;

class ReplyRepository implements ReplyRepositoryInterface
{

    protected $model = '';

    /**
     * ReplyRepository constructor.
     * @param Reply $model
     */
    public function __construct(Reply $model)
    {
        $this->model = $model;
    }

    /**
     * @return mixed
     */
    public function get($perPage = 10)
    {
        $this->model = $this->model->paginate($perPage);
        return $this->model;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return ($this->model = $this->model->find($id))
        ? $this
        : null;
    }

    /**
     * @param array $data
     * @return Reply|boolean false
     */
    public function create(array $data)
    {
        return ($this->model = $this->model->create($data))
        ? $this->model
        : false;
    }

    /**
     * @param array $data
     * @return Reply|boolean false
     */
    public function update(array $data)
    {
        return ($this->model->update($data))
        ? $this->model
        : false;
    }

    /**
     * @return Reply
     */
    public function delete()
    {
        $model = $this->model;
        return ($this->model->delete())
        ? $model
        : false;
    }

    /**
     * @return Reply
     */
    public function getModel()
    {
        return $this->model;
    }
}
