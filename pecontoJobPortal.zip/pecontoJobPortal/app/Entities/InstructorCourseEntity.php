<?php

namespace App\Entities;

trait InstructorCourseEntity
{
    public function courses()
    {
        return $this->belongsTo('App\Models\Course', 'course_id');
    }
    public function currency()
    {
        return $this->belongsTo('App\Models\Currency', 'currency_id');
    }
}
