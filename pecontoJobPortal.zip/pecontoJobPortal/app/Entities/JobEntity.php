<?php

namespace App\Entities;

trait JobEntity
{
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }
    
    public function country()
    {
        return $this->belongsTo('App\Models\Country', 'country_id');
    }

    public function city()
    {
        return $this->belongsTo('App\Models\City', 'city_id');
    }

    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }

    public function sub_category()
    {
        return $this->belongsTo('App\Models\SubCategory', 'sub_category_id');
    }

    public function currency()
    {
        return $this->belongsTo('App\Models\Currency', 'currency_id');
    }

    public function savedUsers()
    {
        return $this->belongsToMany('App\Models\User', 'saved_jobs')->withTimestamps();
    }

    public function applies()
    {
        return $this->hasMany('App\Models\Apply', 'job_id');
    }
}
