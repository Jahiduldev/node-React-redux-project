<?php

namespace App\Entities;

trait LikeEntity
{
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function post()
    {
        return $this->belongsTo('App\Models\Post', 'post_id');
    }

    public function comment()
    {
        return $this->belongsTo('App\Models\Comment', 'comment_id');
    }

    public function reply()
    {
        return $this->belongsTo('App\Models\Reply', 'reply_id');
    }
}
