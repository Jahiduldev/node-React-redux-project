<?php

namespace App\Entities;

trait WorkplacePolicyEntity
{
    public function jobs()
    {
        return $this->hasMany('App\Models\Job', 'workplace_policy_id');
    }
}
