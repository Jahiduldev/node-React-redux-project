<?php

namespace App\Entities;

trait PostEntity
{
    public function comments()
    {
        return $this->hasMany('App\Models\Comment', 'post_id');
    }

    public function likes()
    {
        return $this->hasMany('App\Models\Like', 'post_id');
    }

    public function replies()
    {
        return $this->hasMany('App\Models\Reply', 'post_id');
    }

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }

    public function subCategory()
    {
        return $this->belongsTo('App\Models\SubCategory', 'sub_category_id');
    }
    
    /**
     * imageUrl function
     *
     * @return void
     */
    public function imageUrl()
    {
        $path = config('app.post_image_path') ? config('app.post_image_path') : '';

        return ! empty($this->image)
        ? asset($path.$this->image)
        : '';
    }
}
