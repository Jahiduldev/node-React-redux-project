<?php

namespace App\Entities;

trait EmploymentTypeEntity
{
    public function jobs()
    {
        return $this->hasMany('App\Models\Job', 'employment_type_id');
    }

    public function companyDetails()
    {
        return $this->hasMany('App\Models\CompanyDetail', 'employment_type_id');
    }
}
