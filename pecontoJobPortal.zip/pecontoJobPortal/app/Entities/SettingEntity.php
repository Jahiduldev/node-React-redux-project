<?php

namespace App\Entities;

trait SettingEntity
{
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }
}
