<?php

namespace App\Entities;

trait ReplyEntity
{
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function comment()
    {
        return $this->belongsTo('App\Models\Comment', 'comment_id');
    }
    
    public function likes()
    {
        return $this->hasMany('App\Models\Like', 'reply_id');
    }
}
