<?php

namespace App\Entities;

trait ContactUsEntity
{

}
