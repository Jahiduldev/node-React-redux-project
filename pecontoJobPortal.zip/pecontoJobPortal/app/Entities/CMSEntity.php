<?php

namespace App\Entities;

trait CMSEntity
{

}
