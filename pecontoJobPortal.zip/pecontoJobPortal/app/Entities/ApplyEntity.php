<?php

namespace App\Entities;

trait ApplyEntity
{
    public function job()
    {
        return $this->belongsTo('App\Models\Job', 'job_id');
    }

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }
    
    /**
     * resumeUrl function
     *
     * @return void
     */
    public function resumeUrl()
    {
        $path = config('app.apply_resume_path') ? config('app.apply_resume_path') : '';

        return ! empty($this->resume)
        ? asset($path.$this->resume)
        : '';
    }
}
