<?php

namespace App\Entities;

trait CountryEntity
{
    public function cities()
    {
        return $this->hasMany('App\Models\City', 'country_id');
    }
}
