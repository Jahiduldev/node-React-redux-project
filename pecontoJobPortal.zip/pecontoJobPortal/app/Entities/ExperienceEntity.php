<?php

namespace App\Entities;

trait ExperienceEntity
{
    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }
    public function country()
    {
        $this->belongsTo('App\Models\Country', 'country_id');
    }

    public function city()
    {
        $this->belongsTo('App\Models\City', 'city_id');
    }
}
