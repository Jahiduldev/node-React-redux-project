<?php

namespace App\Entities;

trait CompanyDetailEntity
{

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }


    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }

    public function subCategory()
    {
        return $this->belongsTo('App\Models\SubCategory', 'sub_category_id');
    }
}
