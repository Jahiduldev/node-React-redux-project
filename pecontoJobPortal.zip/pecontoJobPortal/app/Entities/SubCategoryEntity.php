<?php

namespace App\Entities;

trait SubCategoryEntity
{
    public function courses()
    {
        return $this->hasMany('App\Models\Course', 'sub_category_id');
    }

    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }

    public function companyDetails()
    {
        return $this->hasMany('App\Models\CompanyDetail', 'sub_category_id');
    }
}
