<?php

namespace App\Entities;

trait CurrencyEntity
{
    public function instructorCourses()
    {
        return $this->hasMany('App\Models\InstructorCourse', 'currency_id');
    }
}
