<?php

namespace App\Entities;

trait NotificationMessageEntity
{
    public function user()
    {
        return $this->belongsTo('App\Models\user', 'from_user_id');
    }

    public function owner()
    {
        return $this->belongsTo('App\Models\user', 'owner_user_id');
    }
}
