<?php

namespace App\Entities;

trait CategoryEntity
{
    public function subCategories()
    {
        return $this->hasMany('App\Models\SubCategory', 'category_id');
    }

    public function courses()
    {
        return $this->hasMany('App\Models\Course', 'category_id');
    }
    
    public function companyDetails()
    {
        return $this->hasMany('App\Models\CompanyDetail', 'category_id');
    }
    
    public function users()
    {
        return $this->belongsToMany('App\Models\User', 'fields_of_interests', 'category_id', 'user_id')->withTimestamps();
    }
}
