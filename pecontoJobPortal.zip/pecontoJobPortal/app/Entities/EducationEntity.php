<?php

namespace App\Entities;

trait EducationEntity
{
}
