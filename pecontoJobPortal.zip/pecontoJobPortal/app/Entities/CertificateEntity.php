<?php

namespace App\Entities;

trait CertificateEntity
{
    
}
