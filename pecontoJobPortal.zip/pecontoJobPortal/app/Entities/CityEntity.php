<?php

namespace App\Entities;

trait CityEntity
{
    public function country()
    {
        return $this->belongsTo('App\Models\Country', 'country_id');
    }
}
