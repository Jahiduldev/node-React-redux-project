<?php

namespace App\Entities;

trait UserEntity
{
    public function posts()
    {
        return $this->hasMany('App\Models\Post', 'user_id');
    }

    public function country()
    {
        return $this->belongsTo('App\Models\Country', 'country_id');
    }

    public function city()
    {
        return $this->belongsTo('App\Models\City', 'city_id');
    }


    public function comments()
    {
        return $this->hasMany('App\Models\Comment', 'user_id');
    }

    public function replies()
    {
        return $this->hasMany('App\Models\Reply', 'user_id');
    }

    public function likes()
    {
        return $this->hasMany('App\Models\Like', 'user_id');
    }

    public function companyDetail()
    {
        return $this->hasOne('App\Models\CompanyDetail', 'user_id');
    }

    public function fieldsOfInterests()
    {
        return $this->belongsToMany('App\Models\Category', 'fields_of_interests', 'user_id', 'category_id')->withTimestamps();
    }

    public function savedJobs()
    {
        return $this->belongsToMany('App\Models\Job', 'saved_jobs')->withTimestamps();
    }

    public function imageUrl($fieldName = '')
    {
        if (! $fieldName || ! array_key_exists($fieldName, $this->attributes)) {
            return false;
        }

        $path = config('app.user_' . $fieldName . '_path') ? config('app.user_' . $fieldName . '_path') : '';
        $defaultImagePath = config('app.default_user_' . $fieldName) ? config('app.default_user_' . $fieldName) : '';

        return ! empty($this->$fieldName)
        ? asset($path . $this->$fieldName)
        : asset($defaultImagePath);
    }

    public function experiences()
    {
        return $this->hasMany('App\Models\Experience', 'user_id');
    }

    public function educations()
    {
        return $this->hasMany('App\Models\Education', 'user_id');
    }

    public function certificates()
    {
        return $this->hasMany('App\Models\Certificate', 'user_id');
    }

    public function instructorCourses()
    {
        return $this->hasMany('App\Models\InstructorCourse', 'user_id');
    }

    public function applies()
    {
        return $this->hasMany('App\Models\Apply', 'user_id');
    }

    public function setting()
    {
        return $this->hasOne('App\Models\Setting', 'user_id');
    }

    public function getFullNameAttribute()
    {
        return $this->first_name . ' ' . $this->last_name;
    }

    public function follows()
    {
        return $this->belongsToMany('App\Models\User', 'user_follows', 'followed_id', 'follower_id');
    }

    public function followsReverse()
    {
        return $this->belongsToMany('App\Models\User', 'user_follows', 'follower_id', 'followed_id');
    }

    public function subCategory()
    {
        return $this->belongsTo('App\Models\SubCategory', 'sub_category_id');
    }
}
