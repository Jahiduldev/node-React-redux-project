<?php

use App\Models\NotificationMessage;

/**
 * helper function
 *
 * @return void
 * @SuppressWarnings(PHPMD)
 */
function helper()
{
    return new Helper;
}

/**
 * Helper class
 */
class Helper
{
    public function randomNumber($length = 5)
    {
        return random_int((int)('1'.str_repeat('0', $length-1)), (int)(str_repeat('9', $length)));
    }

    public function postUploadHandler(array &$data)
    {
        if (empty($data)) {
            return false;
        }

        // Upload Post Image
        $return = true;
        if (isset($data['image'])) {
            $imageName = $this->uploadPostImage($data['image']);
            $return = false;
            if ($imageName) {
                $return = true;
                $data['image'] = $imageName;
            }
        }

        return $return;
    }

    public function applyUploadHandler(array &$data)
    {
        if (empty($data)) {
            return false;
        }

        // Upload Apply Resume
        $return = true;
        if (isset($data['resume'])) {
            $resumeName = $this->uploadApplyResume($data['resume']);
            $return = false;
            if ($resumeName) {
                $return = true;
                $data['resume'] = $resumeName;
            }
        }

        return $return;
    }

    public function userUploadHandler(array &$data, $oldImages)
    {
        // Upload User Photo
        $return = true;
        if (isset($data['photo'])) {
            $imageName = $this->uploadUserPhoto($data['photo'], $oldImages['photo']);
            $return = false;
            if ($imageName) {
                $data['photo'] = $imageName;
                $return = true;
            }
        }

        // Upload Cover Photo
        if (isset($data['cover_photo'])) {
            $imageName = $this->uploadCoverPhoto($data['cover_photo'], $oldImages['cover_photo']);
            $return = false;
            if ($imageName) {
                $data['cover_photo'] = $imageName;
                $return = true;
            }
        }

        return $return;
    }

    public function uploadPostImage($image)
    {
        if (! empty($image)) {
            $path = config('app.post_image_path') ? config('app.post_image_path') : '';
            if ($this->checkOrCreateDir($path)) {
                return $this->uploadImage($image, $path);
            }
        }

        return false;
    }

    public function uploadApplyResume($resume)
    {
        if (! empty($resume)) {
            $path = config('app.apply_resume_path') ? config('app.apply_resume_path') : '';
            if ($this->checkOrCreateDir($path)) {
                return $this->uploadImage($resume, $path);
            }
        }

        return false;
    }

    public function uploadUserPhoto($photo, $oldImage)
    {
        if (! empty($photo)) {
            $path = config('app.user_photo_path') ? config('app.user_photo_path') : '';

            // Delete Old Image
            if ($oldImage) {
                $this->removeFile($path.$oldImage);
            }

            // Upload New Photo
            if ($this->checkOrCreateDir($path)) {
                return $this->uploadImage($photo, $path);
            }
        }

        return false;
    }

    public function uploadCoverPhoto($coverPhoto, $oldImage)
    {
        if (! empty($coverPhoto)) {
            $path = config('app.user_cover_photo_path') ? config('app.user_cover_photo_path') : '';

            // Delete Old Image
            if ($oldImage) {
                $this->removeFile($path.$oldImage);
            }

            // Upload New Photo
            if ($this->checkOrCreateDir($path)) {
                return $this->uploadImage($coverPhoto, $path);
            }
        }

        return false;
    }

    public function uploadImage($image, $path)
    {
        if (! empty($image) && ! empty($path)) {
            $imageName = time() .'_'. $this->randomNumber() .'_'. $image->getClientOriginalName();

            if ($image->move($path, $imageName)) {
                return $imageName;
            }
        }

        return false;
    }

    public function deletePostImage($imageName)
    {
        if ($imageName) {
            $path = config('app.post_image_path') ? config('app.post_image_path') : '';
            if ($path) {
                return $this->removeFile($path.$imageName);
            }

            return false;
        }

        return true;
    }

    public function deleteUserImage($imageName, $photo)
    {
        if ($imageName) {
            $path = config('app.user_'.$photo.'_path') ? config('app.user_'.$photo.'_path') : '';
            if ($path) {
                return $this->removeFile($path.$imageName);
            }

            return false;
        }

        return true;
    }

    /**
     * removeFile function
     *
     * @param string $file
     * @return void
     */
    public function removeFile(string $file)
    {
        return file_exists($file) ? unlink($file) : false;
    }

    /**
     * checkOrCreateDir function
     *
     * @param string $path
     * @return void
     */
    public function checkOrCreateDir(string $path)
    {

        if (empty($path)) {
            return false;
        }

        if (is_dir($path)) {
            return true;
        }

        // Create Directory
        $old = umask(0);
        if (mkdir($path, 0777, true)) {
            umask($old);

            // Check umask
            if ($old == umask()) {
                return true;
            }
        }

        return false;
    }

    public function getSqlWithBindings($query)
    {
        return vsprintf(str_replace('?', '%s', $query->toSql()), collect($query->getBindings())->map(function ($binding) {
            return is_numeric($binding) ? $binding : "'{$binding}'";
        })->toArray());
    }

    public function saveMessage($ownerId, $userId, $msg)
    {
        NotificationMessage::create([
            'owner_user_id' => $ownerId,
            'from_user_id'  => $userId,
            'message'       => $msg,
        ]);
    }
}
