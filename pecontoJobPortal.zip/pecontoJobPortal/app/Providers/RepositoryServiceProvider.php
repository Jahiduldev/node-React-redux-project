<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

// Mysql Repos

use App\Repositories\CMS\Mysql\CMSRepository;
use App\Repositories\Job\Mysql\JobRepository;
use App\Repositories\City\Mysql\CityRepository;
use App\Repositories\Like\Mysql\LikeRepository;
use App\Repositories\Post\Mysql\PostRepository;

use App\Repositories\User\Mysql\UserRepository;
use App\Repositories\CMS\CMSRepositoryInterface;
use App\Repositories\Job\JobRepositoryInterface;
use App\Repositories\Apply\Mysql\ApplyRepository;
use App\Repositories\Reply\Mysql\ReplyRepository;
use App\Repositories\City\CityRepositoryInterface;
use App\Repositories\Like\LikeRepositoryInterface;
use App\Repositories\Post\PostRepositoryInterface;
use App\Repositories\User\UserRepositoryInterface;
use App\Repositories\Course\Mysql\CourseRepository;
use App\Repositories\Apply\ApplyRepositoryInterface;
use App\Repositories\Reply\ReplyRepositoryInterface;
use App\Repositories\Comment\Mysql\CommentRepository;


// Interfaces
use App\Repositories\Country\Mysql\CountryRepository;
use App\Repositories\Course\CourseRepositoryInterface;
use App\Repositories\Category\Mysql\CategoryRepository;
use App\Repositories\Currency\Mysql\CurrencyRepository;
use App\Repositories\Comment\CommentRepositoryInterface;
use App\Repositories\Country\CountryRepositoryInterface;
use App\Repositories\ContactUs\Mysql\ContactUsRepository;
use App\Repositories\Education\Mysql\EducationRepository;
use App\Repositories\Category\CategoryRepositoryInterface;
use App\Repositories\Currency\CurrencyRepositoryInterface;
use App\Repositories\Experience\Mysql\ExperienceRepository;
use App\Repositories\ContactUs\ContactUsRepositoryInterface;
use App\Repositories\Education\EducationRepositoryInterface;
use App\Repositories\Certificate\Mysql\CertificateRepository;
use App\Repositories\SubCategory\Mysql\SubCategoryRepository;
use App\Repositories\Experience\ExperienceRepositoryInterface;
use App\Repositories\Notification\Mysql\NotificationRepository;
use App\Repositories\Certificate\CertificateRepositoryInterface;
use App\Repositories\SubCategory\SubCategoryRepositoryInterface;
use App\Repositories\EmploymentType\Mysql\EmploymentTypeRepository;
use App\Repositories\WorkplacePolicy\Mysql\WorkplacePolicyRepository;
use App\Repositories\EmploymentType\EmploymentTypeRepositoryInterface;
use App\Repositories\InstructorCourse\Mysql\InstructorCourseRepository;
use App\Repositories\Notification\Mysql\NotificationRepositoryInterface;
use App\Repositories\WorkplacePolicy\WorkplacePolicyRepositoryInterface;
use App\Repositories\InstructorCourse\InstructorCourseRepositoryInterface;

/**
 * RepositoryServiceProvider class
 * @SuppressWarnings(PHPMD)
 */
class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(PostRepositoryInterface::class, PostRepository::class);
        $this->app->bind(CommentRepositoryInterface::class, CommentRepository::class);
        $this->app->bind(LikeRepositoryInterface::class, LikeRepository::class);
        $this->app->bind(ReplyRepositoryInterface::class, ReplyRepository::class);
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(ExperienceRepositoryInterface::class, ExperienceRepository::class);
        $this->app->bind(EducationRepositoryInterface::class, EducationRepository::class);
        $this->app->bind(CertificateRepositoryInterface::class, CertificateRepository::class);
        $this->app->bind(InstructorCourseRepositoryInterface::class, InstructorCourseRepository::class);
        $this->app->bind(CourseRepositoryInterface::class, CourseRepository::class);
        $this->app->bind(JobRepositoryInterface::class, JobRepository::class);
        $this->app->bind(WorkplacePolicyRepositoryInterface::class, WorkplacePolicyRepository::class);
        $this->app->bind(EmploymentTypeRepositoryInterface::class, EmploymentTypeRepository::class);
        $this->app->bind(CategoryRepositoryInterface::class, CategoryRepository::class);
        $this->app->bind(SubCategoryRepositoryInterface::class, SubCategoryRepository::class);
        $this->app->bind(CurrencyRepositoryInterface::class, CurrencyRepository::class);
        $this->app->bind(CountryRepositoryInterface::class, CountryRepository::class);
        $this->app->bind(CityRepositoryInterface::class, CityRepository::class);
        $this->app->bind(ApplyRepositoryInterface::class, ApplyRepository::class);
        $this->app->bind(ContactUsRepositoryInterface::class, ContactUsRepository::class);
        $this->app->bind(NotificationRepositoryInterface::class, NotificationRepository::class);
        $this->app->bind(CMSRepositoryInterface::class, CMSRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
