<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LikeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function rules()
    {
        return [
            'post_id'    => [
                'sometimes',
                'exists:posts,id,deleted_at,NULL',
                function ($attribute, $value, $fail) {
                    $this->custom($attribute, $fail);
                },
            ],
            'comment_id' => [
                'sometimes',
                'exists:comments,id,deleted_at,NULL',
                function ($attribute, $value, $fail) {
                    $this->custom($attribute, $fail);
                },
            ],
            'reply_id'   => [
                'sometimes',
                'exists:replies,id,deleted_at,NULL',
                function ($attribute, $value, $fail) {
                    $this->custom($attribute, $fail);
                },
            ],
        ];
    }

    /**
     * custom function
     *
     * Its responsible to allow only one of three ids to be passed (post_id, comment_id, reply_id)
     *
     * @param string $attribute
     * @param [type] $fail
     * @return void
     */
    public function custom($attribute, $fail)
    {
        
        $relatedTo = [
            'post_id',
            'comment_id',
            'reply_id',
        ];
        
        unset($relatedTo[array_search($attribute, $relatedTo)]);
        if ($this->hasAny($relatedTo)) {
            $fail('The '.implode(', ', $relatedTo).' data should be removed.');
        }
    }
}
