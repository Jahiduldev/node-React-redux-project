<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class InstructorCourseRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id'      => 'required|exists:users,id,deleted_at,NULL',
            'course_id'    => 'required|exists:courses,id',
            'currency_id'  => 'required|exists:currencies,id,deleted_at,NULL',
            'price'        => 'required',
            'hours'        => 'required',
            'type'         => 'required',
            'details'      => 'required',
            'capacity'     => 'required',
            'fixed_amount' => 'required',
            'hourly_rate'  => 'required',
            'on_site'      => 'required',
            'online'       => 'required',
        ];
    }
}
