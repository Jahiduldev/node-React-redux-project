<?php

namespace App\Http\Requests\Job;

use Illuminate\Foundation\Http\FormRequest;

class UpdateJobRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'            => 'sometimes',
            'user_role'        => 'sometimes',
            'user_role_other'  => 'sometimes',
            'country_id'       => 'sometimes',
            'city_id'          => 'sometimes',
            'course_lang'      => 'sometimes',
            'course_type'      => 'sometimes',
            'category_id'      => 'sometimes',
            'sub_category_id'  => 'sometimes',
            'duration_type'    => 'sometimes',
            'duration'         => 'sometimes',
            'course_time_type' => 'sometimes',
            'course_time_from' => 'sometimes',
            'course_time_to'   => 'sometimes',
            'specific_date'    => 'sometimes',
            'course_date'      => 'sometimes',
            'course_start'     => 'sometimes',
            'description'      => 'sometimes',
            'fixed_amount'     => 'sometimes',
            'hourly_rate'      => 'sometimes',
            'currency_id'      => 'sometimes',
            'cv_submit'        => 'sometimes',
            'email_updates'    => 'sometimes',
        ];
    }
}
