<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class CertificateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'                  => 'required',
            'issuing_organization'  => 'sometimes',
            'credential_not_expire' => 'sometimes',
            'issue_date_month'      => 'sometimes',
            'issue_date_year'       => 'sometimes',
            'expiration_date_month' => 'sometimes',
            'expiration_date_year'  => 'sometimes',
            'credential_id'         => 'sometimes',
            'credential_url'        => 'sometimes',
            'user_id'               => 'required|exists:users,id,deleted_at,NULL',
        ];
    }
}
