<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class ExperienceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'                => 'sometimes',
            'employment_type'      => 'sometimes',
            'company_name'         => 'sometimes',
            'country_id'           => 'sometimes|exists:countries,id,deleted_at,NULL',
            'city_id'              => 'sometimes',
            'start_month'          => 'sometimes',
            'start_year'           => 'sometimes',
            'end_month'            => 'sometimes',
            'end_year'             => 'sometimes',
            'headline'             => 'sometimes',
            'industry'             => 'sometimes',
            'description'          => 'sometimes',
            'currently_working'    => 'sometimes',
            'end_current_position' => 'sometimes',
            'user_id'              => 'required|exists:users,id,deleted_at,NULL',
            'category_id'          => 'required|exists:categories,id,deleted_at,NULL',
        ];
    }
}
