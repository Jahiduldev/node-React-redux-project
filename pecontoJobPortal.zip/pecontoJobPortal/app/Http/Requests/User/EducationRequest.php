<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class EducationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'school'               => 'required',
            'degree'               => 'sometimes',
            'field_study'          => 'sometimes',
            'start_month'          => 'sometimes',
            'start_year'           => 'sometimes',
            'end_month'            => 'sometimes',
            'grade'                => 'sometimes',
            'activities_societies' => 'sometimes',
            'description'          => 'sometimes',
            'user_id'              => 'required|exists:users,id,deleted_at,NULL',
        ];
    }
}
