<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class StoreRoleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // Get User Roles
        $roles = isset((new \App\Models\User)->roles) ? (new \App\Models\User)->roles : [];
        
        // Get User Login Methods
        $loginMethods = isset((new \App\Models\User)->loginMethods) ? (new \App\Models\User)->loginMethods : [];
        
        return [
            'role'  => 'required|in:'. implode(',', $roles),
            'email' => 'required|exists:users,email',
        ];
    }
}
