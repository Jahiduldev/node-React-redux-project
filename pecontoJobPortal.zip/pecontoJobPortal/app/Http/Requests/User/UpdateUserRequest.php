<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'                   => 'sometimes',
            'first_name'             => 'sometimes',
            'last_name'              => 'sometimes',
            'about'                  => 'sometimes',
            'role'                   => 'sometimes',
            'email'                  => 'sometimes',
            'phone_number'           => 'sometimes',
            'address'                => 'sometimes',
            'zip_code'               => 'sometimes',
            'notify_on_like_post'    => 'sometimes',
            'notify_on_comment_post' => 'sometimes',
            'notify_on_apply_job'    => 'sometimes',
            'fields_of_interest.*'   => 'sometimes|distinct|exists:categories,id',
            'country_id'             => 'sometimes|exists:countries,id,deleted_at,NULL',
            'city_id'                => 'sometimes',
            'employment_type_id'     => 'sometimes|exists:employment_types,id,deleted_at,NULL',
            'category_id'            => 'sometimes|exists:categories,id,deleted_at,NULL',
            'sub_category_id'        => 'sometimes|exists:sub_categories,id',
            'photo'                  => 'sometimes|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'cover_photo'            => 'sometimes|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ];
    }
}
