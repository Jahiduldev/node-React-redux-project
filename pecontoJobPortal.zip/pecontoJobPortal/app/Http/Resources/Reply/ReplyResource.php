<?php

namespace App\Http\Resources\Reply;

use App\Http\Resources\User\UserResource;
use App\Http\Resources\Like\LikeCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class ReplyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'         => $this->id,
            'content'    => $this->content,
            'user'       => UserResource::make($this->user),
            'likes'      => new LikeCollection($this->likes),
            'has_liked'  => $this->hasLiked($this->likes),
            'replied_at' => $this->created_at->diffForHumans(),
        ];
    }
    
    public function hasLiked($likes)
    {
        $loggedInUserId = \Auth::id();
        foreach ($likes as $like) {
            if ($like->user_id == $loggedInUserId) {
                return true;
            }
        }

        return false;
    }
}
