<?php

namespace App\Http\Resources\Reply;

use Illuminate\Http\Resources\Json\ResourceCollection;

class ReplyCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'data'  => ReplyResource::collection($this->collection),
            'count' => $this->collection->count(),
        ];
    }
}
