<?php

namespace App\Http\Resources\Job;

use App\Http\Resources\Country\CountryResource;
use App\Http\Resources\City\CityResource;
use App\Http\Resources\User\UserResource;
use App\Http\Resources\Currency\CurrencyResource;
use App\Http\Resources\Category\CategoryResource;
use App\Http\Resources\Apply\ApplyCollection;
use App\Http\Resources\SubCategory\SubCategoryResource;
use Illuminate\Http\Resources\Json\JsonResource;

class JobResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'               => $this->id,
            'title'            => $this->title,
            'user_role'        => $this->user_role,
            'user_role_other'  => $this->user_role_other,
            'country_id'       => $this->country_id,
            'city_id'          => $this->city_id,
            'course_lang'      => $this->course_lang,
            'course_type'      => $this->course_type,
            'duration_type'    => $this->duration_type,
            'category_id'      => $this->category_id,
            'sub_category_id'  => $this->sub_category_id,
            'duration'         => $this->duration,
            'course_time_type' => $this->course_time_type,
            'course_time_from' => $this->course_time_from,
            'course_time_to'   => $this->course_time_to,
            'specific_date'    => $this->specific_date,
            'course_date'      => $this->course_date,
            'course_start'     => $this->course_start,
            'description'      => $this->description,
            'fixed_amount'     => $this->fixed_amount,
            'hourly_rate'      => $this->hourly_rate,
            'currency_id'      => $this->currency_id,
            'cv_submit'        => $this->cv_submit,
            'email_updates'    => $this->email_updates,
            'user'             => new UserResource($this->user),
            'city'             => new CityResource($this->city),
            'country'          => new CountryResource($this->country),
            'category'         => new CategoryResource($this->category),
            'sub_category'     => new SubCategoryResource($this->sub_category),
            'currency'         => new CurrencyResource($this->currency),
            'applies'          => new ApplyCollection($this->applies),
        ];
    }
}
