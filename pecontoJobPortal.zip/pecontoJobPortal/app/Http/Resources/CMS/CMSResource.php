<?php

namespace App\Http\Resources\CMS;

use Illuminate\Http\Resources\Json\JsonResource;

class CMSResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        // return parent::toArray($request);
        return [
            'id'          => $this->id,
            'page_type'   => $this->page_type,
            'title'       => $this->title,
            'description' => $this->description,
            'updated_at'  => $this->updated_at->format('Y-m-d')
        ];
    }
}
