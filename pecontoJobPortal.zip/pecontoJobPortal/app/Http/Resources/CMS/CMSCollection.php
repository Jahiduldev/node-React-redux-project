<?php

namespace App\Http\Resources\CMS;

use Illuminate\Http\Resources\Json\ResourceCollection;

class CMSCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'data'  => CMSResource::collection($this->collection),
            'count' => $this->collection->count(),
        ];
    }
}
