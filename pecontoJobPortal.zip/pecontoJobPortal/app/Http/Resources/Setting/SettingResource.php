<?php

namespace App\Http\Resources\Setting;

use Illuminate\Http\Resources\Json\JsonResource;

class SettingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [
            'id'                     => $this->id,
            'notify_on_like_post'    => $this->notify_on_like_post,
            'notify_on_comment_post' => $this->notify_on_comment_post,
        ];

        // In Case the User Role is Company
        if ($this->user->role === $this->user->rolesMap['Company']) {
            $data = array_merge($data, ['notify_on_apply_job' => $this->notify_on_apply_job]);
        }

        return $data;
    }
}
