<?php

namespace App\Http\Resources\Comment;

use App\Http\Resources\User\UserResource;
use App\Http\Resources\Post\PostResource;
use App\Http\Resources\Reply\ReplyCollection;
use App\Http\Resources\Like\LikeCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class CommentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
            'content'      => $this->content,
            'user'         => UserResource::make($this->user),
            'replies'      => new ReplyCollection($this->replies),
            'likes'        => new LikeCollection($this->likes),
            'has_liked'    => $this->hasLiked($this->likes),
            'commented_at' => $this->created_at->diffForHumans(),
        ];
    }

    public function hasLiked($likes)
    {
        $loggedInUserId = \Auth::id();
        foreach ($likes as $like) {
            if ($like->user_id == $loggedInUserId) {
                return true;
            }
        }

        return false;
    }
}
