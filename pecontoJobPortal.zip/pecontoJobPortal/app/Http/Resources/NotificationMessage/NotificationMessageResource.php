<?php

namespace App\Http\Resources\NotificationMessage;

use Illuminate\Http\Resources\Json\JsonResource;

class NotificationMessageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        // return parent::toArray($request);
        return [
            'id'         => $this->id,
            'message'    => str_replace('%s', '', $this->message),
            'owner_name' => $this->owner->full_name,
            'owner_id'   => $this->owner_user_id,
            'seen'       => $this->seen,
            'user_id'    => $this->user->id,
            'username'   => $this->user->username,
            'first_name' => $this->user->first_name,
            'last_name'  => $this->user->last_name,
            'full_name'  => $this->user->full_name,
            'photo'      => $this->user->imageUrl('photo'),
            'created_at' => $this->created_at->diffForHumans(),
        ];
    }
}
