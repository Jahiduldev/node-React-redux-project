<?php

namespace App\Http\Resources\SubCategory;

use App\Http\Resources\Course\CourseCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class SubCategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        // return parent::toArray($request);
        return [
            'id'          => $this->id,
            'name'        => $this->name,
            'label'       => $this->label,
            'category_id' => $this->category_id,
            'courses'     => new CourseCollection($this->courses),
            'category'    => $this->category->label
        ];
    }
}
