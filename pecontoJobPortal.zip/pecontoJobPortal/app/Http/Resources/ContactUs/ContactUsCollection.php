<?php

namespace App\Http\Resources\ContactUs;

use Illuminate\Http\Resources\Json\ResourceCollection;

class ContactUsCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data'  => ContactUsResource::collection($this->collection),
            'count' => $this->collection->count(),
        ];
    }
}
