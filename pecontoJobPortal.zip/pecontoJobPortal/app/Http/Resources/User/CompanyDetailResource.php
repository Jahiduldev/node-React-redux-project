<?php

namespace App\Http\Resources\User;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\City\CityResource;
use App\Http\Resources\Country\CountryResource;
use App\Http\Resources\Category\CategoryCollection;
use App\Http\Resources\Apply\ApplyCollection;
use App\Http\Resources\EmploymentType\EmploymentTypeResource;
use App\Http\Resources\Category\CategoryResource;
use App\Http\Resources\SubCategory\SubCategoryResource;

class CompanyDetailResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'             => $this->id,
            'name'           => $this->name,
            'website'        => $this->website,
            'about'          => $this->about,
            'employmentType' => new EmploymentTypeResource($this->employmentType),
            'category'       => new CategoryResource($this->category),
            'subCategory'    => new SubCategoryResource($this->subCategory),
        ];
    }
}
