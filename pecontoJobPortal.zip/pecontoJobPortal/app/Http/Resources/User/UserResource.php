<?php

namespace App\Http\Resources\User;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\City\CityResource;
use App\Http\Resources\Country\CountryResource;
use App\Http\Resources\Category\CategoryCollection;
use App\Http\Resources\Setting\SettingResource;
use App\Http\Resources\Apply\ApplyCollection;
use App\Http\Resources\SubCategory\SubCategoryResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'                 => $this->id,
            'first_name'         => $this->first_name,
            'username'           => $this->username,
            'last_name'          => $this->last_name,
            'full_name'          => $this->full_name,
            'about'              => $this->about,
            'email'              => $this->email,
            'website'            => $this->website,
            'phone_number'       => $this->phone_number,
            'address'            => $this->address,
            'city_id'            => $this->city_id,
            'country_id'         => $this->country_id,
            'zip_code'           => $this->zip_code,
            'photo'              => $this->imageUrl('photo'),
            'cover_photo'        => $this->imageUrl('cover_photo'),
            'company'            => $this->company,
            'headline'           => $this->headline,
            'follow'             => $this->follow($this->id),
            'following'          => $this->follows->count(),
            'role'               => $this->role,
            'created_at'         => date('d M Y H:i A', strtotime($this->created_at)),
            'email_verified_at'  => $this->email_verified_at,
            'experiences'        => new ExperienceCollection($this->experiences),
            'educations'         => new EducationCollection($this->educations),
            'certificates'       => new CertificateCollection($this->certificates),
            'instructorCourses'  => new InstructorCourseCollection($this->instructorCourses),
            'city'               => new CityResource($this->city),
            'country'            => new CountryResource($this->country),
            'sub_category'       => new SubCategoryResource($this->subCategory),
            'fields_of_interest' => new CategoryCollection($this->fieldsOfInterests),
            'company_details'    => new CompanyDetailResource($this->companyDetail),
            'settings'           => new SettingResource($this->setting),
        ];
    }
}
