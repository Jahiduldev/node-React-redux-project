<?php

namespace App\Http\Resources\User;

use App\Http\Resources\Course\CourseResource;
use App\Http\Resources\Currency\CurrencyResource;
use Illuminate\Http\Resources\Json\JsonResource;

class InstructorCourseResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
            'hours'        => $this->hours,
            'price'        => $this->price,
            'type'         => $this->type,
            'user_id'      => $this->user_id,
            'course_id'    => $this->course_id,
            'courses'      => new CourseResource($this->courses),
            'currency'     => new CurrencyResource($this->currency),
            'details'      => $this->details,
            'capacity'     => $this->capacity,
            'fixed_amount' => $this->fixed_amount == 0 ? false : true,
            'hourly_rate'  => $this->hourly_rate == 0 ? false : true,
            'on_site'      => $this->on_site == 0 ? false : true,
            'online'       => $this->online == 0 ? false : true,
        ];
    }
}
