<?php

namespace App\Http\Resources\User;

use Illuminate\Http\Resources\Json\ResourceCollection;

class EducationCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'data'  => EducationResource::collection($this->collection),
            'count' => $this->collection->count(),
        ];
    }
}
