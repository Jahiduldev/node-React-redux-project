<?php

namespace App\Http\Resources\Post;

use App\Http\Resources\User\UserResource;
use App\Http\Resources\Comment\CommentCollection;
use App\Http\Resources\Like\LikeCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        $comments = new CommentCollection($this->comments->sortByDesc('created_at'));
        return [
            'id'        => $this->id,
            'content'   => $this->content,
            'industry'  => $this->category->name,
            'category'  => $this->subCategory->name,
            'image'     => $this->imageUrl(),
            'video_url' => $this->video_url,
            'user'      => UserResource::make($this->user),
            'comments'  => $comments,
            'likes'     => new LikeCollection($this->likes),
            'has_liked' => $this->hasLiked($this->likes),
            'posted_at' => $this->created_at->diffForHumans(),
        ];
    }

    public function hasLiked($likes)
    {
        $loggedInUserId = \Auth::id();
        foreach ($likes as $like) {
            if ($like->user_id == $loggedInUserId) {
                return true;
            }
        }

        return false;
    }
}
