<?php

namespace App\Http\Resources\Apply;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\User\UserResource;

class ApplyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
            'cover_letter' => $this->cover_letter,
            'resume'       => $this->resumeUrl(),
            'applicant'    => UserResource::make($this->user),
        ];
    }
}
