<?php

namespace App\Http\Resources\Like;

use App\Http\Resources\User\UserResource;
use App\Http\Resources\Post\PostResource;
use App\Http\Resources\Comment\CommentResource;
use App\Http\Resources\Reply\ReplyResource;
use Illuminate\Http\Resources\Json\JsonResource;

class LikeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'id'       => $this->id,
            'user'     => UserResource::make($this->user),
            'liked_at' => $this->updated_at->diffForHumans(),
        ];
    }
}
