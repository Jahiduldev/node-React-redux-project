<?php

namespace App\Http\Resources\EmploymentType;

use Illuminate\Http\Resources\Json\ResourceCollection;

class EmploymentTypeCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     * @SuppressWarnings(PHPMD)
     */
    public function toArray($request)
    {
        return [
            'data'  => EmploymentTypeResource::collection($this->collection),
            'count' => $this->collection->count(),
        ];
    }
}
