<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\Reply\ReplyResource;
use App\Http\Resources\Reply\ReplyCollection;
use App\Http\Requests\Reply\StoreReplyRequest;
use App\Http\Requests\Reply\UpdateReplyRequest;
use App\Repositories\Reply\ReplyRepositoryInterface;

class ReplyController extends Controller
{
    /**
     * replyRepo variable
     *
     * @var object
     */
    protected $replyRepo;

    /**
     * ReplyController constructor.
     * @param ReplyRepositoryInterface $replyRepo
     */
    public function __construct(ReplyRepositoryInterface $replyRepo)
    {
        $this->replyRepo = $replyRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return ReplyCollection
     */
    public function index()
    {
        return new ReplyCollection($this->replyRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreReplyRequest $request
     * @return ReplyResource|\Illuminate\Http\Response
     */
    public function store(StoreReplyRequest $request)
    {
        $reply = $this->replyRepo->create($request->validated());
        if ($reply) {
            return ReplyResource::make($reply);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return ReplyResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $reply = $this->replyRepo->find($id);
        if ($reply) {
            return ReplyResource::make($reply->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateReplyRequest $request
     * @param  int  $id
     * @return ReplyResource|\Illuminate\Http\Response
     */

    public function update(UpdateReplyRequest $request, $id)
    {
        $reply = $this->replyRepo->find($id);
        if ($reply) {
            $reply = $reply->update($request->validated());
            if ($reply) {
                return ReplyResource::make($reply);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return ReplyResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $reply = $this->replyRepo->find($id);
        if ($reply) {
            $reply = $reply->delete();
            if ($reply) {
                return ReplyResource::make($reply);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
