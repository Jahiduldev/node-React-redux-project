<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\LikeRequest;
use App\Http\Resources\Like\LikeResource;
use App\Http\Resources\Like\LikeCollection;
use App\Repositories\Like\LikeRepositoryInterface;

class LikeController extends Controller
{
    /**
     * likeRepo variable
     *
     * @var object
     */
    protected $likeRepo;
    
    /**
     * LikeController constructor.
     * @param LikeRepositoryInterface $likeRepo
     */
    public function __construct(LikeRepositoryInterface $likeRepo)
    {
        $this->likeRepo = $likeRepo;
    }
    
    public function like(LikeRequest $request)
    {
        $like = $this->likeRepo->like($request->validated());
        if (in_array($like, [true, false])) {
            return response()->json([
                'hasLiked' => $like,
            ]);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }
}
