<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Models\NotificationMessage;
use App\Http\Controllers\Controller;
use App\Http\Requests\NotificationRequest;
use App\Repositories\Notification\Mysql\NotificationRepositoryInterface;
use App\Http\Resources\NotificationMessage\NotificationMessageCollection;

class NotificationMessageController extends Controller
{
    protected $notificationRepo;

    public function __construct(NotificationRepositoryInterface $notificationRepo)
    {
        $this->notificationRepo = $notificationRepo;
    }

    public function myNotifications()
    {
        return new NotificationMessageCollection($this->notificationRepo->myNotifications());
    }

    /**
     * Update the specified resources in storage.
     *
     * @param NotificationRequest $request
     */

    public function seenNotifications(NotificationRequest $request)
    {
        $ids = $request['ids'];
        if ($ids) {
            $notification = $this->notificationRepo->seenNotifications($ids);
            if ($notification) {
                return response()->json([
                    'message' => 'Notifications seen successfully'
                ], 200);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
