<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Apply\ApplyResource;
use App\Http\Resources\Apply\ApplyCollection;
use App\Http\Requests\Apply\StoreApplyRequest;
use App\Http\Requests\Apply\UpdateApplyRequest;
use App\Repositories\Apply\ApplyRepositoryInterface;
use App\Repositories\Job\JobRepositoryInterface;

class ApplyController extends Controller
{
    /**
     * applyRepo variable
     *
     * @var object
     */
    protected $applyRepo;
    
    /**
     * jobRepo variable
     *
     * @var object
     */
    protected $jobRepo;

    /**
     * ApplyController constructor.
     * @param ApplyRepositoryInterface $applyRepo
     * @param JobRepositoryInterface $jobRepo
     */
    public function __construct(ApplyRepositoryInterface $applyRepo, JobRepositoryInterface $jobRepo)
    {
        $this->applyRepo = $applyRepo;
        $this->jobRepo = $jobRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return ApplyCollection
     */
    public function index()
    {
        return new ApplyCollection($this->applyRepo->get());
    }

    /**
     * Display a listing of the resource.
     *
     * @return ApplyCollection
     */
    public function indexByJob($id)
    {
        if ($this->jobRepo->find($id)) {
            return new ApplyCollection($this->applyRepo->getByJob($id));
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreApplyRequest $request
     * @return ApplyResource|\Illuminate\Http\Response
     */
    public function store(StoreApplyRequest $request)
    {
        $apply = $this->applyRepo->create($request->validated());
        if ($apply) {
            return ApplyResource::make($apply);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return ApplyResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $apply = $this->applyRepo->find($id);
        if ($apply) {
            return ApplyResource::make($apply->getModel());
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param UpdateApplyRequest $request
     * @param  int  $id
     * @return ApplyResource|\Illuminate\Http\Response
     */
    public function update(UpdateApplyRequest $request, $id)
    {
        $apply = $this->applyRepo->find($id);
        if ($apply) {
            $apply = $apply->update($request->validated());
            if ($apply) {
                return ApplyResource::make($apply);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return ApplyResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $apply = $this->applyRepo->find($id);
        if ($apply) {
            $apply = $apply->delete();
            if ($apply) {
                return ApplyResource::make($apply);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
