<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\Post\PostResource;
use App\Http\Resources\Post\PostCollection;
use App\Http\Requests\Post\StorePostRequest;
use App\Http\Requests\Post\UpdatePostRequest;
use App\Repositories\Category\CategoryRepositoryInterface;
use App\Repositories\Post\PostRepositoryInterface;

class PostController extends Controller
{
    /**
     * postRepo variable
     *
     * @var object
     */
    protected $postRepo;
    protected $categoryRepo;

    /**
     * PostController constructor.
     * @param PostRepositoryInterface $postRepo
     */
    public function __construct(PostRepositoryInterface $postRepo, CategoryRepositoryInterface $categoryRepo)
    {
        $this->postRepo = $postRepo;
        $this->categoryRepo = $categoryRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return PostCollection
     */
    public function index()
    {
        return new PostCollection($this->postRepo->get());
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param StorePostRequest $request
     * @return PostResource|\Illuminate\Http\Response
     */
    public function store(StorePostRequest $request)
    {
        $post = $this->postRepo->create($request->validated());
        if ($post) {
            return PostResource::make($post);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return PostResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $post = $this->postRepo->find($id);
        if ($post) {
            return PostResource::make($post->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdatePostRequest $request
     * @param  int  $id
     * @return PostResource|\Illuminate\Http\Response
     */

    public function update(UpdatePostRequest $request, $id)
    {
        $post = $this->postRepo->find($id);
        if ($post) {
            $post = $post->update($request->validated());
            if ($post) {
                return PostResource::make($post);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return PostResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = $this->postRepo->find($id);
        if ($post) {
            $post = $post->delete();
            if ($post) {
                return PostResource::make($post);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @param  string  $photo
     * @return PostResource|\Illuminate\Http\Response
     */
    public function deleteImage($id)
    {
        $post = $this->postRepo->find($id);
        if ($post) {
            $post = $post->deleteImage();
            if ($post) {
                return PostResource::make($post);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    public function timeline($category_id)
    {
        // check category id
        $category = $this->categoryRepo->find($category_id);
        if ($category) {
            $posts = $this->postRepo->findByCategory($category_id);
            return new PostCollection($posts);
        }
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Invalid category id!'
        ], 404);
        // search
    }
}
