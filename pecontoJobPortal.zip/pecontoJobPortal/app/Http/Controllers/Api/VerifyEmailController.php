<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\VerifiesEmails;
use Illuminate\Auth\Access\AuthorizationException;

class VerifyEmailController extends Controller
{
    use VerifiesEmails;

    protected $redirectTo = "/home";

    public function __construct()
    {
        $this->middleware('signed')->only('verified');
        $this->middleware('throttle:6,1')->only('resend', 'verified');
    }

    public function verify(Request $request)
    {
        $user = User::find($request->route('id'));

        if ($user->hasVerifiedEmail()) {
            return redirect(env('APP_URL') . '/fields-of-interest');
        }

        if ($user->markEmailAsVerified()) {
            event(new Verified($user));
        }

        return redirect(env('APP_URL') . '/fields-of-interest');
    }
}
