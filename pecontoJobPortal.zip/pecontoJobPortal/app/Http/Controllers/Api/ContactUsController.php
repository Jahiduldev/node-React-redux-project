<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\ContactUs\ContactUsResource;
use App\Http\Resources\ContactUs\ContactUsCollection;
use App\Http\Requests\ContactUs\StoreContactUsRequest;
use App\Http\Requests\ContactUs\UpdateContactUsRequest;
use App\Repositories\ContactUs\ContactUsRepositoryInterface;

class ContactUsController extends Controller
{
    /**
     * contactusRepo variable
     *
     * @var object
     */
    protected $contactusRepo;

    /**
     * ApplyController constructor.
     * @param ContactUsRepositoryInterface $contactusRepo
     */
    public function __construct(ContactUsRepositoryInterface $contactusRepo)
    {
        $this->contactusRepo = $contactusRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return ContactUsCollection
     */
    public function index()
    {
        return new ContactUsCollection($this->contactusRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreContactUsRequest $request
     * @return ContactUsResource|\Illuminate\Http\Response
     */
    public function store(StoreContactUsRequest $request)
    {
        $contactus = $this->contactusRepo->create($request->validated());
        if ($contactus) {
            return ContactUsResource::make($contactus);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return ContactUsResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $contactus = $this->contactusRepo->find($id);
        if ($contactus) {
            return ContactUsResource::make($contactus->getModel());
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateContactUsRequest $request
     * @param  int  $id
     * @return ContactUsResource|\Illuminate\Http\Response
     */
    public function update(UpdateContactUsRequest $request, $id)
    {
        $contactus = $this->contactusRepo->find($id);
        if ($contactus) {
            $contactus = $contactus->update($request->validated());
            if ($contactus) {
                return ContactUsResource::make($contactus);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return ContactUsResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $contactus = $this->contactusRepo->find($id);
        if ($contactus) {
            $contactus = $contactus->delete();
            if ($contactus) {
                return ContactUsResource::make($contactus);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
