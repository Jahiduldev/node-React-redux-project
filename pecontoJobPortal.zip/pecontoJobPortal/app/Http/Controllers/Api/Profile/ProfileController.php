<?php

namespace App\Http\Controllers\Api\Profile;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpdateUserRequest;
use App\Http\Resources\User\UserResource;
use App\Repositories\User\UserRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ProfileController extends Controller
{
    /**
     * userRepo variable
     *
     * @var object
     */
    protected $userRepo;

    /**
     * ReplyController constructor.
     * @param UserRepositoryInterface $userRepo
     */
    public function __construct(UserRepositoryInterface $userRepo)
    {
        $this->userRepo = $userRepo;
    }

    public function index(Request $request)
    {
        return new UserResource($request->user());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return UserResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = $this->userRepo->find($id);
        request()->request->add(['username' => $id]);
        if ($user) {
            return UserResource::make($user->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    public function update(UpdateUserRequest $request)
    {

        $id = \Auth::id();
        $user = $this->userRepo->find($id);
        if ($user) {
            $user = $user->update($request->validated());
            if ($user) {
                return UserResource::make($user);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @param  string  $photo
     * @return PostResource|\Illuminate\Http\Response
     */
    public function deleteImage($photo)
    {
        $id = \Auth::id();
        $user = $this->userRepo->find($id);
        if ($user) {
            $user = $user->deleteImage($photo);
            if ($user) {
                return UserResource::make($user);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
