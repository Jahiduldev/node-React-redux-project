<?php

namespace App\Http\Controllers\Api\Profile;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\EducationRequest;
use App\Http\Resources\User\EducationResource;
use App\Http\Resources\User\EducationCollection;
use App\Repositories\Education\EducationRepositoryInterface;

class EducationController extends Controller
{
    /**
     * educationRepo variable
     *
     * @var object
     */
    protected $educationRepo;

    /**
     * EducationController constructor.
     * @param EducationRepositoryInterface $educationRepo
     */
    public function __construct(EducationRepositoryInterface $educationRepo)
    {
        $this->educationRepo = $educationRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return EducationCollection
     */
    public function index()
    {
        return new EducationCollection($this->educationRepo->getByUser(\Auth::id()));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param EducationRequest $request
     * @return EducationResource|\Illuminate\Http\Response
     */
    public function store(EducationRequest $request)
    {
        $education = $this->educationRepo->create($request->validated());
        if ($education) {
            return EducationResource::make($education);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return EducationResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $education = $this->educationRepo->find($id);
        if ($education) {
            return EducationResource::make($education->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param EducationRequest $request
     * @param  int  $id
     * @return EducationResource|\Illuminate\Http\Response
     */

    public function update(EducationRequest $request, $id)
    {
        $education = $this->educationRepo->find($id);
        if ($education) {
            $education = $education->update($request->validated());
            if ($education) {
                return EducationResource::make($education);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return EducationResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $experience = $this->educationRepo->find($id);
        if ($experience) {
            $experience = $experience->delete();
            if ($experience) {
                return EducationResource::make($experience);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
