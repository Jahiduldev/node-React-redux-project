<?php

namespace App\Http\Controllers\Api\Profile;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\ExperienceRequest;
use App\Http\Resources\User\ExperienceResource;
use App\Http\Resources\User\ExperienceCollection;
use App\Repositories\Experience\ExperienceRepositoryInterface;

class ExperienceController extends Controller
{
    /**
     * experienceRepo variable
     *
     * @var object
     */
    protected $experienceRepo;

    /**
     * ExperienceController constructor.
     * @param ExperienceRepositoryInterface $experienceRepo
     */
    public function __construct(ExperienceRepositoryInterface $experienceRepo)
    {
        $this->experienceRepo = $experienceRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return ExperienceCollection
     */
    public function index()
    {
        return new ExperienceCollection($this->experienceRepo->getByUser(\Auth::id()));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param ExperienceRequest $request
     * @return ExperienceResource|\Illuminate\Http\Response
     */
    public function store(ExperienceRequest $request)
    {
        $experience = $this->experienceRepo->create($request->validated());
        if ($experience) {
            return ExperienceResource::make($experience);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return ExperienceResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $experience = $this->experienceRepo->find($id);
        if ($experience) {
            return ExperienceResource::make($experience->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param ExperienceRequest $request
     * @param  int  $id
     * @return ExperienceResource|\Illuminate\Http\Response
     */

    public function update(ExperienceRequest $request, $id)
    {
        $experience = $this->experienceRepo->find($id);
        if ($experience) {
            $experience = $experience->update($request->validated());
            if ($experience) {
                return ExperienceResource::make($experience);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return ExperienceResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $experience = $this->experienceRepo->find($id);
        if ($experience) {
            $experience = $experience->delete();
            if ($experience) {
                return ExperienceResource::make($experience);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
