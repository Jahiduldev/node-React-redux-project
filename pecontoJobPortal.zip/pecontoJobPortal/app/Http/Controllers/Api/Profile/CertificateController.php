<?php

namespace App\Http\Controllers\Api\Profile;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\CertificateRequest;
use App\Http\Resources\User\CertificateResource;
use App\Http\Resources\User\CertificateCollection;
use App\Repositories\Certificate\CertificateRepositoryInterface;

class CertificateController extends Controller
{
    /**
     * certificateRepository variable
     *
     * @var object
     */
    protected $certificateRepo;

    /**
     * CertificateController constructor.
     * @param CertificateRepositoryInterface $certificateRepo
     */
    public function __construct(CertificateRepositoryInterface $certificateRepo)
    {
        $this->certificateRepository = $certificateRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return CertificateCollection
     */
    public function index()
    {
        return new CertificateCollection($this->certificateRepository->getByUser(\Auth::id()));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param CertificateRequest $request
     * @return CertificateResource|\Illuminate\Http\Response
     */
    public function store(CertificateRequest $request)
    {
        $certificate = $this->certificateRepository->create($request->validated());
        if ($certificate) {
            return CertificateResource::make($certificate);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CertificateResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $certificate = $this->certificateRepository->find($id);
        if ($certificate) {
            return CertificateResource::make($certificate->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param CertificateRequest $request
     * @param  int  $id
     * @return CertificateResource|\Illuminate\Http\Response
     */

    public function update(CertificateRequest $request, $id)
    {
        $certificate = $this->certificateRepository->find($id);
        if ($certificate) {
            $certificate = $certificate->update($request->validated());
            if ($certificate) {
                return CertificateResource::make($certificate);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CertificateResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $certificate = $this->certificateRepository->find($id);
        if ($certificate) {
            $certificate = $certificate->delete();
            if ($certificate) {
                return CertificateResource::make($certificate);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
