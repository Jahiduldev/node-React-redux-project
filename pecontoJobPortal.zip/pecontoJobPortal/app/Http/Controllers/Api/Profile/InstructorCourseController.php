<?php

namespace App\Http\Controllers\Api\Profile;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\InstructorCourseRequest;
use App\Http\Resources\User\InstructorCourseResource;
use App\Http\Resources\User\InstructorCourseCollection;
use App\Repositories\InstructorCourse\InstructorCourseRepositoryInterface;

class InstructorCourseController extends Controller
{
    /**
     * instructorCourseRepo variable
     *
     * @var object
     */
    protected $instructorCourseRepo;

    /**
     * $instructorCourseController constructor.
     * @param InstructorCourseRepositoryInterface $instructorCourseRepo
     */
    public function __construct(InstructorCourseRepositoryInterface $instructorCourseRepo)
    {
        $this->instructorCourseRepository = $instructorCourseRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return InstructorCourseCollection
     */
    public function index()
    {
        return new InstructorCourseCollection($this->instructorCourseRepository->getByUser(\Auth::id()));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param InstructorCourseRequest $request
     * @return InstructorCourseResource|\Illuminate\Http\Response
     */
    public function store(InstructorCourseRequest $request)
    {
        $instructorCourse = $this->instructorCourseRepository->create($request->validated());
        if ($instructorCourse) {
            return InstructorCourseResource::make($instructorCourse);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return InstructorCourseResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $instructorCourse = $this->instructorCourseRepository->find($id);
        if ($instructorCourse) {
            return InstructorCourseResource::make($instructorCourse->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param InstructorCourseRequest $request
     * @param  int  $id
     * @return InstructorCourseResource|\Illuminate\Http\Response
     */

    public function update(InstructorCourseRequest $request, $id)
    {
        $instructorCourse = $this->instructorCourseRepository->find($id);
        if ($instructorCourse) {
            $instructorCourse = $instructorCourse->update($request->validated());
            if ($instructorCourse) {
                return InstructorCourseResource::make($instructorCourse);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return InstructorCourseResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $instructorCourse = $this->instructorCourseRepository->find($id);
        if ($instructorCourse) {
            $instructorCourse = $instructorCourse->delete();
            if ($instructorCourse) {
                return InstructorCourseResource::make($instructorCourse);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
