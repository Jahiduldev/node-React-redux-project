<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\Job\JobResource;
use App\Http\Resources\Job\JobCollection;
use App\Http\Requests\Job\StoreJobRequest;
use App\Http\Requests\Job\UpdateJobRequest;
use App\Repositories\Job\JobRepositoryInterface;

class JobController extends Controller
{
    /**
     * jobRepo variable
     *
     * @var object
     */
    protected $jobRepo;

    /**
     * jobController constructor.
     * @param JobRepositoryInterface $jobRepo
     */
    public function __construct(JobRepositoryInterface $jobRepo)
    {
        $this->jobRepo = $jobRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return JobCollection
     */
    public function index()
    {
        return new JobCollection($this->jobRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreJobRequest $request
     * @return JobResource|\Illuminate\Http\Response
     */
    public function store(StoreJobRequest $request)
    {
        $job = $this->jobRepo->create($request->validated());
        if ($job) {
            return JobResource::make($job);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return JobResource|\Illuminate\Http\Response
     */
    public function show($id = null)
    {
        $job = $this->jobRepo->find($id);

        if ($job) {
            return JobResource::make($job->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    public function filter()
    {
        $job = $this->jobRepo->filter();
        if ($job) {
            return new JobCollection($job);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateJobRequest $request
     * @param  int  $id
     * @return JobResource|\Illuminate\Http\Response
     */

    public function update(UpdateJobRequest $request, $id)
    {
        $job = $this->jobRepo->find($id);
        if ($job) {
            $job = $job->update($request->validated());
            if ($job) {
                return JobResource::make($job);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return JobResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $job = $this->jobRepo->find($id);
        if ($job) {
            $job = $job->delete();
            if ($job) {
                return JobResource::make($job);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * search function
     *
     * @param string $key
     * @return void
     */
    public function search(string $key)
    {
        $jobs = $this->jobRepo->search($key);
        if ($jobs) {
            return new JobCollection($jobs);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }
}
