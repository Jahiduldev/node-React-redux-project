<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Country\StoreCountryRequest;
use App\Http\Requests\Country\UpdateCountryRequest;
use App\Http\Resources\Country\CountryCollection;
use App\Http\Resources\Country\CountryResource;
use App\Repositories\Country\CountryRepositoryInterface;
use Illuminate\Http\Response;

class CountryController extends Controller
{
    /**
     *  countryRepo variable
     *
     * @var object
     */
    protected $countryRepo;

    /**
     * CountryController constructor.
     * @param CountryRepositoryInterface $countryRepo
     */
    public function __construct(CountryRepositoryInterface $countryRepo)
    {
        $this->countryRepo = $countryRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return CountryCollection
     */
    public function index()
    {
        return new CountryCollection($this->countryRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreCountryRequest $request
     * @return CountryResource|\Illuminate\Http\Response
     */
    public function store(StoreCountryRequest $request)
    {
        $country = $this->countryRepo->create($request->validated());
        if ($country) {
            return CountryResource::make($country);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support',
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CountryResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $country = $this->countryRepo->find($id);
        if ($country) {
            return CountryResource::make($country->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateCountryRequest $request
     * @param  int  $id
     * @return CountryResource|\Illuminate\Http\Response
     */

    public function update(UpdateCountryRequest $request, $id)
    {
        $country = $this->countryRepo->find($id);
        if ($country) {
            $country = $country->update($request->validated());
            if ($country) {
                return CountryResource::make($country);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CountryResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $country = $this->countryRepo->find($id);
        if ($country) {
            $country = $country->delete();
            if ($country) {
                return CountryResource::make($country);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
