<?php
namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CourseRequest;
use App\Http\Resources\Course\CourseCollection;
use App\Http\Resources\Course\CourseResource;
use App\Repositories\Course\CourseRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class CourseController extends Controller
{
    /**
     * courseRepo variable
     *
     * @var object
     */
    protected $courseRepo;

    /**
     * PostController constructor.
     * @param CourseRepositoryInterface $courseRepo
     */
    public function __construct(CourseRepositoryInterface $courseRepo)
    {
        $this->courseRepo = $courseRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return CourseCollection
     */
    public function index()
    {
        return new CourseCollection($this->courseRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param CourseRequest $request
     * @return CourseResource|\Illuminate\Http\Response
     */
    public function store(CourseRequest $request)
    {
        $course = $this->courseRepo->create($request->validated());
        if ($course) {
            return CourseResource::make($course);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support',
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CourseResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $course = $this->courseRepo->find($id);
        if ($course) {
            return CourseResource::make($course->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param CourseRequest $request
     * @param  int  $id
     * @return CourseResource|\Illuminate\Http\Response
     */

    public function update(CourseRequest $request, $id)
    {
        $course = $this->courseRepo->find($id);
        if ($course) {
            $course = $course->update($request->validated());
            if ($course) {
                return CourseResource::make($course);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CourseResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $course = $this->courseRepo->find($id);
        if ($course) {
            $course = $course->delete();
            if ($course) {
                return CourseResource::make($course);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
