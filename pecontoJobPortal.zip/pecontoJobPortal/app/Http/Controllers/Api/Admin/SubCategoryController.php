<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\SubCategoryRequest;
use App\Http\Resources\SubCategory\SubCategoryResource;
use App\Http\Resources\SubCategory\SubCategoryCollection;
use App\Repositories\SubCategory\SubCategoryRepositoryInterface;

class SubCategoryController extends Controller
{
    /**
     *  categoryRepo variable
     *
     * @var object
     */
    protected $subCategoryRepo;

    /**
     * categoryController constructor.
     * @param SubCategoryRepositoryInterface $subCategoryRepo
     */
    public function __construct(SubCategoryRepositoryInterface $subCategoryRepo)
    {
        $this->subCategoryRepo = $subCategoryRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return SubCategoryCollection
     */
    public function index()
    {
        return new SubCategoryCollection($this->subCategoryRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param SubCategoryRequest $request
     * @return SubCategoryResource|\Illuminate\Http\Response
     */
    public function store(SubCategoryRequest $request)
    {
        $subCategory = $this->subCategoryRepo->create($request->validated());
        if ($subCategory) {
            return SubCategoryResource::make($subCategory);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support',
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return SubCategoryResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $subCategory = $this->subCategoryRepo->find($id);
        if ($subCategory) {
            return SubCategoryResource::make($subCategory->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param SubCategoryRequest $request
     * @param  int  $id
     * @return SubCategoryResource|\Illuminate\Http\Response
     */

    public function update(SubCategoryRequest $request, $id)
    {
        $subCategory = $this->subCategoryRepo->find($id);
        if ($subCategory) {
            $subCategory = $subCategory->update($request->validated());
            if ($subCategory) {
                return SubCategoryResource::make($subCategory);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return SubCategoryResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $subCategory = $this->subCategoryRepo->find($id);
        if ($subCategory) {
            $subCategory = $subCategory->delete();
            if ($subCategory) {
                return SubCategoryResource::make($subCategory);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
