<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\Currency\CurrencyResource;
use App\Http\Resources\Currency\CurrencyCollection;
use App\Http\Requests\Currency\StoreCurrencyRequest;
use App\Http\Requests\Currency\UpdateCurrencyRequest;
use App\Repositories\Currency\CurrencyRepositoryInterface;

class CurrencyController extends Controller
{
    /**
     *  currencyRepo variable
     *
     * @var object
     */
    protected $currencyRepo;

    /**
     * currencyController constructor.
     * @param CurrencyRepositoryInterface $currencyRepo
     */
    public function __construct(CurrencyRepositoryInterface $currencyRepo)
    {
        $this->currencyRepo = $currencyRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return CurrencyCollection
     */
    public function index()
    {
        return new CurrencyCollection($this->currencyRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreCurrencyRequest $request
     * @return CurrencyResource|\Illuminate\Http\Response
     */
    public function store(StoreCurrencyRequest $request)
    {
        $currency = $this->currencyRepo->create($request->validated());
        if ($currency) {
            return CurrencyResource::make($currency);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support',
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CurrencyResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $currency = $this->currencyRepo->find($id);
        if ($currency) {
            return CurrencyResource::make($currency->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateCurrencyRequest $request
     * @param  int  $id
     * @return CurrencyResource|\Illuminate\Http\Response
     */

    public function update(UpdateCurrencyRequest $request, $id)
    {
        $currency = $this->currencyRepo->find($id);
        if ($currency) {
            $currency = $currency->update($request->validated());
            if ($currency) {
                return CurrencyResource::make($currency);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CurrencyResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $currency = $this->currencyRepo->find($id);
        if ($currency) {
            $currency = $currency->delete();
            if ($currency) {
                return CurrencyResource::make($currency);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
