<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\City\StoreCityRequest;
use App\Http\Requests\City\UpdateCityRequest;
use App\Http\Resources\City\CityCollection;
use App\Http\Resources\City\CityResource;
use App\Repositories\City\CityRepositoryInterface;
use Illuminate\Http\Response;

class CityController extends Controller
{
    /**
     *  categoryRepo variable
     *
     * @var object
     */
    protected $cityRepo;

    /**
     * categoryController constructor.
     * @param CityRepositoryInterface $cityRepo
     */
    public function __construct(CityRepositoryInterface $cityRepo)
    {
        $this->cityRepo = $cityRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return CityCollection
     */
    public function index()
    {
        return new CityCollection($this->cityRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreCityRequest $request
     * @return CityResource|\Illuminate\Http\Response
     */
    public function store(StoreCityRequest $request)
    {
        $city = $this->cityRepo->create($request->validated());
        if ($city) {
            return CityResource::make($city);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support',
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CityResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $city = $this->cityRepo->find($id);
        if ($city) {
            return CityResource::make($city->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateCityRequest $request
     * @param  int  $id
     * @return CityResource|\Illuminate\Http\Response
     */

    public function update(UpdateCityRequest $request, $id)
    {
        $city = $this->cityRepo->find($id);
        if ($city) {
            $city = $city->update($request->validated());
            if ($city) {
                return CityResource::make($city);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CityResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $city = $this->cityRepo->find($id);
        if ($city) {
            $city = $city->delete();
            if ($city) {
                return CityResource::make($city);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support',
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!',
        ], 404);
    }
}
