<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\AdminRequest;
use App\Http\Resources\User\UserCollection;
use App\Http\Resources\User\UserResource;
use App\Repositories\User\UserRepositoryInterface;

class AdminController extends Controller
{
    // Admin controller for users ,admins and instructors

    /**
     * userRepository variable
     *
     * @var object
     */
    protected $userRepository;

    /**
     * AdminController constructor.
     * @param UserRepositoryInterface $userRepository
     */
    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return UserCollection
     */
    public function index()
    {
        return new UserCollection($this->userRepository->get());
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param AdminRequest $request
     * @return UserResource|\Illuminate\Http\Response
     */
    public function store(AdminRequest $request)
    {
        $admin = $this->userRepository->create($request->validated());
        if ($admin) {
            return UserResource::make($admin);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return UserResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $admin = $this->userRepository->find($id);
        if ($admin) {
            return UserResource::make($admin->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param AdminRequest $request
     * @param  int  $id
     * @return UserResource|\Illuminate\Http\Response
     */

    public function update(AdminRequest $request, $id)
    {
        $admin = $this->userRepository->find($id);
        if ($admin) {
            $admin = $admin->update($request->validated());
            if ($admin) {
                return UserResource::make($admin);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return UserResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $admin = $this->userRepository->find($id);
        if ($admin) {
            $admin = $admin->delete();
            if ($admin) {
                return UserResource::make($admin);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    public function follow()
    {
        if (request()->has('user_id') && ! empty(request('user_id'))) {
            $admin = $this->userRepository->find(request('user_id'));
            if ($admin) {
                $status = $admin->follow();

                return response()->json([
                    'message' => ($status == 2) ? 'Unfollow!' : 'Follow!',
                    'status'  => $status
                ], 200);
            }
            return response()->json([
                'code'    => Response::HTTP_NOT_FOUND,
                'status'  => false,
                'message' => 'Not Found!'
            ], 404);
        }
    }

    public function followList()
    {
        return new UserCollection($this->userRepository->followList());
    }
}
