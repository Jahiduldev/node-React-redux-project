<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\WorkplacePolicy\WorkplacePolicyResource;
use App\Http\Resources\WorkplacePolicy\WorkplacePolicyCollection;
use App\Http\Requests\WorkplacePolicy\StoreWorkplacePolicyRequest;
use App\Http\Requests\WorkplacePolicy\UpdateWorkplacePolicyRequest;
use App\Repositories\WorkplacePolicy\WorkplacePolicyRepositoryInterface;

class WorkplacePolicyController extends Controller
{
    /**
     *  workplacePolicyRepo variable
     *
     * @var object
     */
    protected $workplacePolicyRepo;

    /**
     * workplacePolicyController constructor.
     * @param WorkplacePolicyRepositoryInterface $workplacePolicyRepo
     */
    public function __construct(WorkplacePolicyRepositoryInterface $workplacePolicyRepo)
    {
        $this->workplacePolicyRepo = $workplacePolicyRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return WorkplacePolicyCollection
     */
    public function index()
    {
        return new WorkplacePolicyCollection($this->workplacePolicyRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreWorkplacePolicyRequest $request
     * @return WorkplacePolicyResource|\Illuminate\Http\Response
     */
    public function store(StoreWorkplacePolicyRequest $request)
    {
        $workplacePolicy = $this->workplacePolicyRepo->create($request->validated());
        if ($workplacePolicy) {
            return WorkplacePolicyResource::make($workplacePolicy);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return WorkplacePolicyResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $workplacePolicy = $this->workplacePolicyRepo->find($id);
        if ($workplacePolicy) {
            return WorkplacePolicyResource::make($workplacePolicy->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateWorkplacePolicyRequest $request
     * @param  int  $id
     * @return WorkplacePolicyResource|\Illuminate\Http\Response
     */

    public function update(UpdateWorkplacePolicyRequest $request, $id)
    {
        $workplacePolicy = $this->workplacePolicyRepo->find($id);
        if ($workplacePolicy) {
            $workplacePolicy = $workplacePolicy->update($request->validated());
            if ($workplacePolicy) {
                return WorkplacePolicyResource::make($workplacePolicy);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return WorkplacePolicyResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $workplacePolicy = $this->workplacePolicyRepo->find($id);
        if ($workplacePolicy) {
            $workplacePolicy = $workplacePolicy->delete();
            if ($workplacePolicy) {
                return WorkplacePolicyResource::make($workplacePolicy);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
