<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\EmploymentType\EmploymentTypeResource;
use App\Http\Resources\EmploymentType\EmploymentTypeCollection;
use App\Http\Requests\EmploymentType\StoreEmploymentTypeRequest;
use App\Http\Requests\EmploymentType\UpdateEmploymentTypeRequest;
use App\Repositories\EmploymentType\EmploymentTypeRepositoryInterface;

class EmploymentTypeController extends Controller
{
    /**
     *  employmentTypeRepo variable
     *
     * @var object
     */
    protected $employmentTypeRepo;

    /**
     * employmentTypeController constructor.
     * @param EmploymentTypeRepositoryInterface $employmentTypeRepo
     */
    public function __construct(EmploymentTypeRepositoryInterface $employmentTypeRepo)
    {
        $this->employmentTypeRepo = $employmentTypeRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return EmploymentTypeCollection
     */
    public function index()
    {
        return new EmploymentTypeCollection($this->employmentTypeRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreEmploymentTypeRequest $request
     * @return EmploymentTypeResource|\Illuminate\Http\Response
     */
    public function store(StoreEmploymentTypeRequest $request)
    {
        $employmentType = $this->employmentTypeRepo->create($request->validated());
        if ($employmentType) {
            return EmploymentTypeResource::make($employmentType);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return EmploymentTypeResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $employmentType = $this->employmentTypeRepo->find($id);
        if ($employmentType) {
            return EmploymentTypeResource::make($employmentType->getModel());
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateEmploymentTypeRequest $request
     * @param  int  $id
     * @return EmploymentTypeResource|\Illuminate\Http\Response
     */

    public function update(UpdateEmploymentTypeRequest $request, $id)
    {
        $employmentType = $this->employmentTypeRepo->find($id);
        if ($employmentType) {
            $employmentType = $employmentType->update($request->validated());
            if ($employmentType) {
                return EmploymentTypeResource::make($employmentType);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return EmploymentTypeResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employmentType = $this->employmentTypeRepo->find($id);
        if ($employmentType) {
            $employmentType = $employmentType->delete();
            if ($employmentType) {
                return EmploymentTypeResource::make($employmentType);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
