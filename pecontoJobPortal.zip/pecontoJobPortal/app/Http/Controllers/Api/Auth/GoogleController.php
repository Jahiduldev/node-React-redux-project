<?php

namespace App\Http\Controllers\Api\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use Laravel\Socialite\Facades\Socialite;
use App\Http\Resources\User\UserResource;
use App\Repositories\User\UserRepositoryInterface;

class GoogleController extends Controller
{

    /**
     * userRepo variable
     *
     * @var object
     */
    protected $userRepo;

    /**
     * ReplyController constructor.
     * @param UserRepositoryInterface $userRepo
     */
    public function __construct(UserRepositoryInterface $userRepo)
    {
        $this->userRepo = $userRepo;
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function redirect()
    {
        // Set Role to Cookie
        $expire = time() + (60 * 60); // One Minute
        setcookie('role', request('role'), $expire, "/");


        if ($redirectUrl = Socialite::driver('google')->stateless()->redirect()->getTargetUrl()) {
            return response()->json([
                'redirectUrl' => $redirectUrl
            ]);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function callback(Request $request)
    {
        try {
            $user = Socialite::driver('google')->stateless()->user();
            $foundUser = $this->userRepo->find(['google_id', '=', $user->id]);
            if ($foundUser) {
                $foundUser = $foundUser->getModel();

                $token = auth()->login($foundUser);
                if (! $token) {
                    return response()->json([
                        'errors' => [
                            'email' => ['Sorry we couldn\'t sign you in with those details.']
                        ]
                    ], 422);
                }

                return (new UserResource($request->user()))
                    ->additional([
                        'meta' => [
                            'token' => $token
                        ]
                    ]);
            }

            // Store the new user
            $defaultRole = 'user';
            $newUser = User::where('email', $user->email,)->first();
            if(!$newUser)
            $newUser = $this->userRepo->firstOrCreate([
                'email'      => $user->email,
                'username'   => $this->generateUsername($user->name),
                'first_name' => $user->user['given_name'],
                'last_name'  => $user->user['family_name'],
                'role'       => isset($_COOKIE['role']) ? $_COOKIE['role'] : $defaultRole,
                'google_id'  => $user->id,
            ]);

            // Try to Login
            if (! $token = auth()->login($newUser)) {
                return response()->json([
                    'errors' => [
                        'email' => ['Sorry we couldn\'t sign you in with those details.']
                    ]
                ], 422);
            }

            return (new UserResource($newUser))
                ->additional([
                    'meta' => [
                        'token' => $token
                    ]
                ]);
        } catch (Exception $e) {
            dd($e->getMessage()); // TODO: Should Be replaced with Exception Handling Class (Default/Custom)
        }
    }

    public function generateUsername(string $name)
    {
        return str_replace(" ", "", $name) ."_". time();
    }
}
