<?php

namespace App\Http\Controllers\Api\Auth;

use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Repositories\User\UserRepositoryInterface;
use App\Http\Resources\Job\JobResource;
use App\Http\Resources\Job\JobCollection;
use App\Repositories\Job\JobRepositoryInterface;

class SavedJobController extends Controller
{
    /**
     * userRepo variable
     * jobRepo variable
     * currentUser variable
     *
     * @var object
     */
    protected $userRepo;
    protected $jobRepo;
    protected $currentUser;

    /**
     * ReplyController constructor.
     * @param UserRepositoryInterface $userRepo
     * @param JobRepositoryInterface $jobRepo
     */
    public function __construct(UserRepositoryInterface $userRepo, JobRepositoryInterface $jobRepo)
    {
        $this->userRepo = $userRepo;
        $this->jobRepo = $jobRepo;

        $loggedInUser = \Auth::id();
        $this->currentUser = $this->userRepo->find($loggedInUser);
    }

    
    /**
     * Display a listing of the resource.
     *
     * @return JobCollection
     */
    public function savedJobs()
    {
        if ($this->currentUser) {
            return new JobCollection($this->currentUser->getSavedJobs());
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    
    /**
     * Attach a Job To a User.
     *
     * @return JobResource
     */
    public function saveJob(int $jobId)
    {
        $job = $this->jobRepo->find($jobId);
        if ($job && $this->currentUser) {
            if ($this->currentUser->saveJob($jobId)) {
                return new JobResource($job->getModel());
            }
            
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
    
    /**
     * Detach a Job From a User.
     *
     * @return JobResource
     */
    public function unsaveJob(int $jobId)
    {
        $job = $this->jobRepo->find($jobId);
        if ($job && $this->currentUser) {
            if ($this->currentUser->unsaveJob($jobId)) {
                return new JobResource($job->getModel());
            }
            
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
