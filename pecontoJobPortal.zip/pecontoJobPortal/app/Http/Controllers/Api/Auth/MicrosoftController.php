<?php

namespace App\Http\Controllers\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\User\UserResource;
use League\OAuth2\Client\Provider\GenericProvider;
use League\OAuth2\Client\Provider\Exception\IdentityProviderException;
use Microsoft\Graph\Graph;
use Microsoft\Graph\Model;
use App\Repositories\User\UserRepositoryInterface;
    
class MicrosoftController extends Controller
{

    /**
     * userRepo variable
     *
     * @var object
     */
    protected $userRepo;

    /**
     * ReplyController constructor.
     * @param UserRepositoryInterface $userRepo
     */
    public function __construct(UserRepositoryInterface $userRepo)
    {
        $this->userRepo = $userRepo;
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function redirect()
    {
        // Set Role to Cookie
        $expire = time() + (60 * 60); // One Minute
        setcookie('role', request('role'), $expire, "/");

        // Initialize the OAuth client
        $oauthClient = new GenericProvider([
            'clientId'                => config('services.microsoft.appId'),
            'clientSecret'            => config('services.microsoft.appSecret'),
            'redirectUri'             => config('services.microsoft.redirectUri'),
            'urlAuthorize'            => config('services.microsoft.authority').config('services.microsoft.authorizeEndpoint'),
            'urlAccessToken'          => config('services.microsoft.authority').config('services.microsoft.tokenEndpoint'),
            'urlResourceOwnerDetails' => '',
            'scopes'                  => config('services.microsoft.scopes')
        ]);

        // Redirect to ADD signin page
        $redirectUrl = $oauthClient->getAuthorizationUrl();
        
        // Set OAuth State
        setcookie('oauthState', $oauthClient->getState(), $expire, "/");

        if ($redirectUrl) {
            return response()->json([
                'redirectUrl' => $redirectUrl,
                'state'       => $oauthClient->getState(),
            ]);
        }

        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }
        
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function callback(Request $request)
    {
        // Authorization code should be in the "code" query param
        $authCode = $request->query('code');
        $providedState = $request->query('state');
        $expectedState = $_COOKIE['oauthState'];

        // Remove Cookie
        unset($_COOKIE['oauthState']);
        setcookie('oauthState', null, -1, '/');

        // Validate state
        if (! isset($expectedState)) {
            // If there is no expected state in the session,
            // do nothing and redirect to the home page.
            return redirect('/');
        }
        
        if (! isset($providedState) || $expectedState != $providedState) {
            return redirect('/')
                ->with('error', 'Invalid auth state')
                ->with('errorDetail', 'The provided auth state did not match the expected value');
        }
        
        if (isset($authCode)) {
            // Initialize the OAuth client
            $oauthClient = new GenericProvider([
                'clientId'                => config('services.microsoft.appId'),
                'clientSecret'            => config('services.microsoft.appSecret'),
                'redirectUri'             => config('services.microsoft.redirectUri'),
                'urlAuthorize'            => config('services.microsoft.authority').config('services.microsoft.authorizeEndpoint'),
                'urlAccessToken'          => config('services.microsoft.authority').config('services.microsoft.tokenEndpoint'),
                'urlResourceOwnerDetails' => '',
                'scopes'                  => config('services.microsoft.scopes')
            ]);

            try {
                // Make the token request
                $accessToken = $oauthClient->getAccessToken('authorization_code', [
                    'code' => $authCode
                ]);
                
                $graph = new Graph();
                $graph->setAccessToken($accessToken->getToken());

                // TODO: Try to get Microsoft photo
                $microsoftRequest = $graph->createRequest('GET', '/me?$select=profilePhoto,displayName,mail,mailboxSettings,userPrincipalName')->execute();
               
                return ($return = $this->microsoftAccountHandler(array_merge(['accessToken' => $accessToken], $microsoftRequest->getBody())))
                ? $return
                : response()->json([
                    'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                    'message' => 'Sorry we couldn\'t handle your Request please contact support'
                ], 500);
            } catch (IdentityProviderException $e) {
                return response()->json([
                    'code'        => Response::HTTP_INTERNAL_SERVER_ERROR,
                    'message'     => 'Error requesting access token',
                    'errorDetail' => json_encode($e->getResponseBody())
                ], 500);
            }
        }

        return response()->json([
            'code'        => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message'     => $request->query('error'),
            'errorDetail' => $request->query('error_description')
        ], 500);
    }

    private function microsoftAccountHandler($mcirosoftAccount)
    {
        if (empty($mcirosoftAccount)) {
            false;
        }
        
        // Check if User Exists
        $foundUser = $this->userRepo->find(['microsoft_id', '=', $mcirosoftAccount['id']]);
        if ($foundUser) {
            $foundUser = $foundUser->getModel();

            // Try to Login
            $token = auth()->login($foundUser);
            if (! $token) {
                return response()->json([
                    'errors' => [
                        'email' => ['Sorry we couldn\'t sign you in with those details.']
                    ]
                ], 422);
            }
    
            return (new UserResource($foundUser))
                ->additional([
                    'meta' => [
                        'token' => $token
                    ]
                ]);
        }

        // Create New User
        $defaultRole = 'user';
        $newUser = $this->userRepo->firstOrCreate([
            'username'     => $this->generateUsername($mcirosoftAccount['displayName']),
            'first_name'   => $mcirosoftAccount['givenName'],
            'last_name'    => $mcirosoftAccount['surname'],
            'email'        => $mcirosoftAccount['userPrincipalName'],
            'microsoft_id' => $mcirosoftAccount['id'],
            'password'     => \Hash::make(config('services.microsoft.password')),
            'role'         => isset($_COOKIE['role']) ? $_COOKIE['role'] : $defaultRole,
        ]);
        
        // Try to Login
        if (! $token = auth()->login($newUser)) {
            return response()->json([
                'errors' => [
                    'email' => ['Sorry we couldn\'t sign you in with those details.']
                ]
            ], 422);
        }

        return (new UserResource($newUser))
            ->additional([
                'meta' => [
                    'token' => $token
                ]
            ]);
    }

    
    public function generateUsername(string $name)
    {
        return str_replace(" ", "", $name) ."_". time();
    }
}
