<?php

namespace App\Http\Controllers\Api\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\User\UserResource;
use App\Repositories\User\UserRepositoryInterface;
use App\Http\Requests\User\StoreUserRequest;

class RegisterController extends Controller
{
    /**
     * userRepo variable
     *
     * @var object
     */
    protected $userRepo;

    /**
     * ReplyController constructor.
     * @param UserRepositoryInterface $userRepo
     */
    public function __construct(UserRepositoryInterface $userRepo)
    {
        $this->userRepo = $userRepo;
    }

    public function __invoke(StoreUserRequest $request)
    {
        $this->userRepo->create([
            'email'      => $request->email,
            'username'   => $this->generateUsername($request->first_name),
            'first_name' => $request->first_name,
            'last_name'  => $request->last_name,
            'role'       => $request->role,
            'google_id'  => $request->google_id,
            'password'   => bcrypt($request->password),
        ]);

        $token = auth()->attempt($request->only(['email', 'password']));
        if (! $token) {
            return abort(401);
        }

        return (new UserResource($request->user()))->additional(['meta' => ['token' => $token]]);
    }

    private function generateUsername(string $name)
    {
        return str_replace(" ", "_", $name) ."_". time();
    }
}
