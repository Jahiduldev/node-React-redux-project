<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Http\Resources\Comment\CommentResource;
use App\Http\Resources\Comment\CommentCollection;
use App\Http\Requests\Comment\StoreCommentRequest;
use App\Http\Requests\Comment\UpdateCommentRequest;
use App\Repositories\Comment\CommentRepositoryInterface;

class CommentController extends Controller
{
    /**
     * commentRepo variable
     *
     * @var object
     */
    protected $commentRepo;

    /**
     * CommentController constructor.
     * @param CommentRepositoryInterface $commentRepo
     */
    public function __construct(CommentRepositoryInterface $commentRepo)
    {
        $this->commentRepo = $commentRepo;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return CommentCollection
     */
    public function index()
    {
        return new CommentCollection($this->commentRepo->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreCommentRequest $request
     * @return CommentResource|\Illuminate\Http\Response
     */
    public function store(StoreCommentRequest $request)
    {
        $comment = $this->commentRepo->create($request->validated());
        if ($comment) {
            return CommentResource::make($comment);
        }
        
        return response()->json([
            'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
            'message' => 'Sorry we couldn\'t handle your Request please contact support'
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return CommentResource|\Illuminate\Http\Response
     */
    public function show($id)
    {
        $comment = $this->commentRepo->find($id);
        if ($comment) {
            return CommentResource::make($comment->getModel());
        }
        
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateCommentRequest $request
     * @param  int  $id
     * @return CommentResource|\Illuminate\Http\Response
     */
    public function update(UpdateCommentRequest $request, $id)
    {
        $comment = $this->commentRepo->find($id);
        if ($comment) {
            $comment = $comment->update($request->validated());
            if ($comment) {
                return CommentResource::make($comment);
            }

            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }
            
        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return CommentResource|\Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $comment = $this->commentRepo->find($id);
        if ($comment) {
            $comment = $comment->delete();
            if ($comment) {
                return CommentResource::make($comment);
            }
        
            return response()->json([
                'code'    => Response::HTTP_INTERNAL_SERVER_ERROR,
                'message' => 'Sorry we couldn\'t handle your Request please contact support'
            ], 500);
        }

        return response()->json([
            'code'    => Response::HTTP_NOT_FOUND,
            'message' => 'Not Found!'
        ], 404);
    }
}
