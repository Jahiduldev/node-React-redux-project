<?php

namespace App\Models;

use App\Entities\SettingEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Setting extends Model
{
    use SettingEntity, SoftDeletes;

    protected $fillable = [
        'user_id',
        'notify_on_like_post',
        'notify_on_comment_post',
        'notify_on_apply_job',
    ];
}
