<?php

namespace App\Models;

use App\Entities\CountryEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Country extends Model
{
    use CountryEntity, SoftDeletes;

    protected $fillable = [
        'name',
        'lable',
    ];
}
