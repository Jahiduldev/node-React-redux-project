<?php

namespace App\Models;

use App\Entities\ApplyEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Apply extends Model
{
    use ApplyEntity, SoftDeletes;

    protected $fillable = [
        'cover_letter',
        'resume',
        'user_id',
        'job_id',
    ];
}
