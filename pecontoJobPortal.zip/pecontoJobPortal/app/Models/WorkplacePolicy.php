<?php

namespace App\Models;

use App\Entities\WorkplacePolicyEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkplacePolicy extends Model
{
    use WorkplacePolicyEntity, SoftDeletes;
    
    protected $fillable = [
        'name',
        'label',
        'description',
    ];
}
