<?php

namespace App\Models;

use App\Entities\ReplyEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Reply extends Model
{
    use ReplyEntity, SoftDeletes;

    protected $fillable = [
        'content',
        'comment_id',
        'user_id',
    ];
}
