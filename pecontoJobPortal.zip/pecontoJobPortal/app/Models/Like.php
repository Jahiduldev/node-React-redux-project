<?php

namespace App\Models;

use App\Entities\LikeEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Like extends Model
{
    use LikeEntity, SoftDeletes;

    protected $fillable = [
        'post_id',
        'comment_id',
        'reply_id',
        'user_id',
    ];
}
