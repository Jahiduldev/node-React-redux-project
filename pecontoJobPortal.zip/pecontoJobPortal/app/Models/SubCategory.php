<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Entities\SubCategoryEntity;
use Illuminate\Database\Eloquent\SoftDeletes;

class SubCategory extends Model
{
    use SubCategoryEntity;

    protected $fillable = [
        'name',
        'label',
        'category_id'
    ];
}
