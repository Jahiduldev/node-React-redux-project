<?php

namespace App\Models;

use App\Entities\EducationEntity;
use Illuminate\Database\Eloquent\Model;

class Education extends Model
{
    use EducationEntity;

    protected $fillable = [
        'school', 'degree', 'field_study', 'start_month', 'start_year', 'end_month', 'grade', 'activities_societies', 'description', 'user_id'
    ];
}
