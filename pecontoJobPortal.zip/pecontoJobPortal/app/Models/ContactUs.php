<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Entities\ContactUsEntity;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContactUs extends Model
{
    use ContactUsEntity, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'subject',
        'content',
    ];
}
