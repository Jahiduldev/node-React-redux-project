<?php

namespace App\Models;

use App\Entities\CourseEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Course extends Model
{
    use CourseEntity, SoftDeletes;

    protected $fillable = ['name', 'label', 'sub_category_id', 'category_id'];
}
