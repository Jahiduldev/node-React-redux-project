<?php

namespace App\Models;

use App\Entities\UserEntity;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Notifications\ResetPassword as ResetPasswordNotification;

class User extends Authenticatable implements JWTSubject, MustVerifyEmail
{
    use Notifiable, UserEntity, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username', 'first_name', 'last_name', 'email', 'password', 'phone_number', 'address', 'role','sub_category_id','website',
        'country_id', 'city_id', 'zip_code', 'total_experience', 'photo', 'cover_photo', 'about', 'google_id', 'microsoft_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public $roles = [
        'user',
        'instructor'
    ];

    public $rolesMap = [
        'Company'    => 'user',
        'Instructor' => 'instructor'
    ];

    public $loginMethods = [
        'google'    => 'google_id',
        'microsoft' => 'microsoft_id'
    ];

    protected $searchMap = [
        'instructors' => 'searchInstructors',
        'companies'   => 'searchCompanies'
    ];

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }


    public function scopeFilter($query, array $filters, string $search)
    {
        (array_key_exists($search, $this->searchMap))
        ? $this->{$this->searchMap[$search]}($query, $filters)
        : false;
    }

    public function searchCompanies(&$query, array $filters)
    {
        $query->when($filters['name'] ?? false, fn ($query, $name) =>
            $query->whereHas('companyDetail', fn ($query) =>
                $query->where('name', 'like', '%'. trim($name) .'%')));

        $query->when($filters['industry'] ?? false, fn ($query, $category) =>
            $query->whereHas('companyDetail.category', fn ($query) =>
                $query->where('name', 'like', '%'. trim($category) .'%')));

        $query->when($filters['location'] ?? false, fn ($query, $location) =>
            $query->whereHas('country', fn ($query) =>
                $query->where('name', 'like', '%'. trim($location) .'%')));
    }

    public function searchInstructors(&$query, array $filters)
    {
        $query->when($filters['name'] ?? false, fn ($query, $name) =>
            $query->where(function ($q) use ($name) {
                $q->whereHas('experiences', function ($q) use ($name) {
                    $q->where('title', 'LIKE', '%' . $name . '%')
                        ->orWhere('headline', 'LIKE', '%' . $name . '%');
                })
                ->orWhereHas('certificates', function ($q) use ($name) {
                    $q->where('name', 'LIKE', '%' . $name . '%');
                })
                ->orWhereHas('country', function ($q) use ($name) {
                    $q->where('name', 'LIKE', '%' . $name . '%');
                })
                ->orWhereHas('city', function ($q) use ($name) {
                    $q->where('name', 'LIKE', '%' . $name . '%');
                })
                ->orWhereHas('instructorCourses', function ($q) use ($name) {
                    $q->whereHas('courses', function ($q) use ($name) {
                        $q->where('name', 'LIKE', '%' . $name . '%');
                    });
                })
                ->orWhere('first_name', 'LIKE', '%' . $name . '%')
                ->orWhere('last_name', 'LIKE', '%' . $name . '%')
                ->orderby('first_name');
            }));

        $query->when($filters['industry'] ?? false, fn ($query, $category) =>
            $query->whereHas('experiences.category', fn ($query) =>
                $query->where('name', 'like', '%'. trim($category) .'%')));

        $query->when($filters['location'] ?? false, fn ($query, $location) =>
            $query->whereHas('country', fn ($query) =>
                $query->where('name', 'like', '%'. trim($location) .'%')));
    }

    public function follow($id)
    {
        // return true;
        $user = self::where('username', request('username'))->first();

        $id = ! empty($user) ? $user->id : $id;

        if (! empty(DB::table('user_follows')->where('follower_id', auth()->user()->id)->where('followed_id', $id)->first())) {
            return true;
        }

        return false;
    }
}
