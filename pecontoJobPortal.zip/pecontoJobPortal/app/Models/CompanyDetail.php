<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Entities\CompanyDetailEntity;
use Illuminate\Database\Eloquent\SoftDeletes;

class CompanyDetail extends Model
{
    use CompanyDetailEntity, SoftDeletes;

    protected $guarded = [];
}
