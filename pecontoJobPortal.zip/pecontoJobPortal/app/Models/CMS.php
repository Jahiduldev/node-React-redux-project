<?php

namespace App\Models;

use App\Entities\CMSEntity;
use Illuminate\Database\Eloquent\Model;

class CMS extends Model
{
    use CMSEntity;

    protected $fillable = [
        'page_type',
        'title',
        'description'
    ];
}
