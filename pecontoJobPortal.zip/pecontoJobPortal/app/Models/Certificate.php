<?php

namespace App\Models;

use App\Entities\CertificateEntity;
use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    use CertificateEntity;

    protected $fillable = [
        'name', 'issuing_organization', 'credential_not_expire', 'issue_date_month', 'issue_date_year', 'expiration_date_month', 'expiration_date_year', 'credential_id', 'credential_url', 'user_id'
    ];
}
