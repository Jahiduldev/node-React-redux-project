<?php

namespace App\Models;

use App\Entities\JobEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Job extends Model
{
    use JobEntity, SoftDeletes;

    protected $fillable = [
        'title',
        'user_role',
        'user_role_other',
        'country_id',
        'city_id',
        'course_lang',
        'course_type',
        'category_id',
        'sub_category_id',
        'duration_type',
        'duration',
        'course_time_type',
        'course_time_from',
        'course_time_to',
        'specific_date',
        'course_date',
        'course_start',
        'description',
        'fixed_amount',
        'hourly_rate',
        'currency_id',
        'cv_submit',
        'email_updates',
        'brief',
        'user_id',
    ];
}
