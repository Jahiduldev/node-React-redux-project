<?php

namespace App\Models;

use App\Entities\CategoryEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use CategoryEntity, SoftDeletes;

    protected $fillable = [
        'name',
        'label',
    ];
}
