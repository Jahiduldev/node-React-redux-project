<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Entities\CityEntity;

class City extends Model
{
    use CityEntity;

    protected $fillable = [
        'name',
        'label',
        'country_id'
    ];
}
