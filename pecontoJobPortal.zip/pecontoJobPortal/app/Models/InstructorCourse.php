<?php

namespace App\Models;

use App\Entities\InstructorCourseEntity;
use Illuminate\Database\Eloquent\Model;

class InstructorCourse extends Model
{
    use InstructorCourseEntity;

    public $table = 'instructor_courses';

    protected $guarded = [];
}
