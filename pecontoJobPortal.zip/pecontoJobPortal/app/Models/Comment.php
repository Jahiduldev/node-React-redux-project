<?php

namespace App\Models;

use App\Entities\CommentEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Comment extends Model
{
    use CommentEntity, SoftDeletes;
    
    protected $fillable = [
        'content',
        'post_id',
        'user_id',
    ];
}
