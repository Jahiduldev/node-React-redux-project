<?php

namespace App\Models;

use App\Entities\NotificationMessageEntity;
use Illuminate\Database\Eloquent\Model;

class NotificationMessage extends Model
{
    use NotificationMessageEntity;
    
    public $table = "notification_messages";
    protected $guarded = [];
}
