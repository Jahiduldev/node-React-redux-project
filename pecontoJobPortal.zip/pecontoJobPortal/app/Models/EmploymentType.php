<?php

namespace App\Models;

use App\Entities\EmploymentTypeEntity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmploymentType extends Model
{
    use EmploymentTypeEntity, SoftDeletes;
    
    protected $fillable = [
        'name',
        'label',
    ];
}
