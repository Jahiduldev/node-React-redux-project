<?php

use Illuminate\Database\Seeder;
use App\Repositories\EmploymentType\EmploymentTypeRepositoryInterface;

class EmploymentTypeSeeder extends Seeder
{
    /**
     * employmentTypeRepository variable
     *
     * @var object
     */
    protected $employmentTypeRepository;

    protected $data = [
        [
            'name'  => 'full_time',
            'label' => 'Full-time',
        ],
        [
            'name'  => 'part_time',
            'label' => 'Part-time',
        ],
        [
            'name'  => 'contract',
            'label' => 'Contract',
        ],
        [
            'name'  => 'temporary',
            'label' => 'Temporary',
        ],
        [
            'name'  => 'volunteer',
            'label' => 'Volunteer',
        ],
        [
            'name'  => 'internship',
            'label' => 'Internship',
        ],
    ];
    
    /**
     * EmploymentTypeSeeder constructor.
     * @param EmploymentTypeRepositoryInterface $employmentTypeRepository
     */
    public function __construct(EmploymentTypeRepositoryInterface $employmentTypeRepository)
    {
        $this->employmentTypeRepository = $employmentTypeRepository;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->data as $model) {
            $this->employmentTypeRepository->create($model);
        }
    }
}
