<?php

use App\Models\City;
use Illuminate\Database\Seeder;

class CitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        City::insert([
            ['name' => 'cairo', 'label' => 'Cairo', 'country_id' => 1],
            ['name' => 'giza', 'label' => 'Giza', 'country_id' => 1],
            ['name' => 'alexandria', 'label' => 'Alexandria', 'country_id' => 1],
            ['name' => 'riyadh', 'label' => 'Riyadh', 'country_id' => 2],
            ['name' => 'jeddah', 'label' => 'Jeddah', 'country_id' => 2],
            ['name' => 'makkah', 'label' => 'Makkah', 'country_id' => 2],
            ['name' => 'dubai', 'label' => 'Dubai', 'country_id' => 3],
            ['name' => 'abu dhabi', 'label' => 'Abu Dhabi', 'country_id' => 3],
            ['name' => 'sharjah', 'label' => 'Sharjah', 'country_id' => 3],
        ]);
    }
}
