<?php

use App\Models\Course;
use Illuminate\Database\Seeder;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Course::insert([
            ['name' => 'PMP Certification Training ', 'label' => 'PMP Certification Training ', 'sub_category_id' => 1, 'category_id' => 1],
            ['name' => 'Consumer Demand', 'label' => 'Consumer Demand', 'sub_category_id' => 2, 'category_id' => 1],
            ['name' => 'Behavior of Buyers and Sellers & Product Pricing', 'label' => 'Behavior of Buyers and Sellers & Product Pricing', 'sub_category_id' => 2, 'category_id' => 1],
            ['name' => 'Fundamentals of Java Programming', 'label' => 'Fundamentals of Java Programming', 'sub_category_id' => 3, 'category_id' => 2],
            ['name' => 'Html & CSS', 'label' => 'Html & CSS', 'sub_category_id' => 3, 'category_id' => 2],
            ['name' => 'Swift 4 Development', 'label' => 'Swift 4 Development', 'sub_category_id' => 4, 'category_id' => 2],
            ['name' => 'Algorthims & Data Structures', 'label' => 'Algorthims & Data Structures', 'sub_category_id' => 5, 'category_id' => 2],
            ['name' => 'Certified Information Systems Security Professional (CISSP)', 'label' => 'Certified Information Systems Security Professional (CISSP)', 'sub_category_id' => 6, 'category_id' => 3],
            ['name' => 'Certified in Risk and Information Systems Control (CRISC)
            ', 'label' => 'Certified in Risk and Information Systems Control (CRISC)', 'sub_category_id' => 7, 'category_id' => 3,
            ],
        ]);
    }
}
