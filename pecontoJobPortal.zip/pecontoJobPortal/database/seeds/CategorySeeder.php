<?php

use Illuminate\Database\Seeder;
use App\Repositories\Category\CategoryRepositoryInterface;

class CategorySeeder extends Seeder
{
    /**
     * CategoryRepository variable
     *
     * @var object
     */
    protected $categoryRepository;

    protected $data = [
        ['name' => 'business' ,'label' => 'Business'],
        ['name' => 'programming' ,'label' => 'Programming'],
        ['name' => 'it' ,'label' => 'IT'],
    ];

    /**
     * CategorySeeder constructor.
     * @param CategoryRepositoryInterface $categoryRepository
     */
    public function __construct(CategoryRepositoryInterface $categoryRepository)
    {
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->data as $model) {
            $this->categoryRepository->create($model);
        }
    }
}
