<?php

use Illuminate\Database\Seeder;
use App\Repositories\Currency\CurrencyRepositoryInterface;

class CurrencySeeder extends Seeder
{
    /**
     * CurrencyRepository variable
     *
     * @var object
     */
    protected $currencyRepository;

    protected $data = [
        [
            'name'  => 'usd',
            'label' => 'USD',
        ],
        [
            'name'  => 'eur',
            'label' => 'EUR',
        ],
        [
            'name'  => 'egp',
            'label' => 'EGP',
        ],
        [
            'name'  => 'sar',
            'label' => 'SAR',
        ],
        [
            'name'  => 'aed',
            'label' => 'AED',
        ],
        [
            'name'  => 'kwd',
            'label' => 'KWD',
        ],
    ];

    /**
     * CurrencySeeder constructor.
     * @param CurrencyRepositoryInterface $currencyRepository
     */
    public function __construct(CurrencyRepositoryInterface $currencyRepository)
    {
        $this->currencyRepository = $currencyRepository;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->data as $model) {
            $this->currencyRepository->create($model);
        }
    }
}
