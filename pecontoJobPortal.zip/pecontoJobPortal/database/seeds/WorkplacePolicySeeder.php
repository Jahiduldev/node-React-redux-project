<?php

use Illuminate\Database\Seeder;
use App\Repositories\WorkplacePolicy\WorkplacePolicyRepositoryInterface;

class WorkplacePolicySeeder extends Seeder
{
    /**
     * workplacePolicyRepository variable
     *
     * @var object
     */
    protected $workplacePolicyRepository;

    protected $data = [
        [
            'name'        => 'on_site',
            'label'       => 'On-site',
            'description' => 'Employees come to work in-person',
        ],
        [
            'name'        => 'hybrid',
            'label'       => 'Hybrid',
            'description' => 'Employees work on-site and off-site',
        ],
        [
            'name'        => 'remote',
            'label'       => 'Remote',
            'description' => 'Employees work off-site',
        ],
    ];

    /**
     * WorkplacePolicySeeder constructor.
     * @param WorkplacePolicyRepositoryInterface $workplacePolicyRepository
     */
    public function __construct(WorkplacePolicyRepositoryInterface $workplacePolicyRepository)
    {
        $this->workplacePolicyRepository = $workplacePolicyRepository;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        foreach ($this->data as $model) {
            $this->workplacePolicyRepository->create($model);
        }
    }
}
