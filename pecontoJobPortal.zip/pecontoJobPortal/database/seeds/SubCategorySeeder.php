<?php

use App\Models\SubCategory;
use Illuminate\Database\Seeder;

class SubCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SubCategory::insert([
            ['name' => 'Fundamentals of finance and accounting', 'label' => 'Fundamentals of Finance and Accounting', 'category_id' => 1],
            ['name' => 'business Intensive', 'label' => 'Business Intensive', 'category_id' => 1],
            ['name' => 'Web Development', 'label' => 'Web Development', 'category_id' => 2],
            ['name' => 'Mobile Development', 'label' => 'Mobile Development', 'category_id' => 2],
            ['name' => 'Computer Science Fundamentals', 'label' => 'Computer Science Fundamentals', 'category_id' => 2],
            ['name' => 'Networking', 'label' => 'Networking', 'category_id' => 3],
            ['name' => 'Cybersecurity', 'label' => 'Cybersecurity', 'category_id' => 3],
        ]);
    }
}
