<?php

use Illuminate\Database\Seeder;
use App\Repositories\Country\CountryRepositoryInterface;

class CountrySeeder extends Seeder
{
    /**
     * countryRepository variable
     *
     * @var object
     */
    protected $countryRepository;

    protected $data = [
        ['name' => 'egypt' ,'label' => 'Egypt'],
        ['name' => 'saudi arabia' ,'label' => 'Saudi Arabia'],
        ['name' => 'united arab emirates' ,'label' => 'United Arab Emirates'],
    ];

    /**
     * CountrySeeder constructor.
     * @param CountryRepositoryInterface $CountryRepository
     */
    public function __construct(CountryRepositoryInterface $countryRepository)
    {
        $this->countryRepository = $countryRepository;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->data as $model) {
            $this->countryRepository->create($model);
        }
    }
}
