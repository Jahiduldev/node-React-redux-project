<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('jobs', function (Blueprint $table) {
            $table->dropColumn('company');
            $table->dropColumn('location');
            $table->dropForeign('jobs_employment_type_id_foreign');
            $table->dropColumn('employment_type_id');
            $table->dropForeign('jobs_workplace_policy_id_foreign');
            $table->dropColumn('workplace_policy_id');

            $table->enum('user_role',['hiring_manager', 'recruiter', 'talent_asquisitions', 'assistant', 'office_manager', 'hr', 'owner', 'other'])->default('recruiter');
            $table->string('user_role_other')->nullable();
            $table->string('course_lang');
            $table->enum('course_type', ['online', 'onsite'])->default('online');
            $table->enum('duration_type', ['days', 'hours'])->default('hours');
            $table->integer('duration');
            $table->enum('course_time_type', ['morning', 'evening', 'fullday'])->default('morning');
            $table->time('course_time_from');
            $table->time('course_time_to');
            $table->enum('specific_date', ['yes', 'no'])->default('yes');
            $table->date('course_date')->nullable();
            $table->string('course_start')->nullable();
            $table->unsignedBigInteger('country_id');
            $table->unsignedBigInteger('city_id');
            $table->longText('description');
            $table->integer('fixed_amount')->nullable();
            $table->integer('hourly_rate')->nullable();
            $table->enum('cv_submit', ['yes', 'no', 'optional']);
            $table->string('email_updates');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('jobs', function (Blueprint $table) {
            $table->string('company');
            $table->string('location');
            $table->unsignedBigInteger('employment_type_id');
            $table->foreign('employment_type_id')->references('id')->on('employment_types')->onDelete('cascade')->onUpdate('cascade');
            $table->unsignedBigInteger('workplace_policy_id');
            $table->foreign('workplace_policy_id')->references('id')->on('workplace_policies')->onDelete('cascade')->onUpdate('cascade');

            $table->dropColumn('country_id');
            $table->dropColumn('city_id');
            $table->dropColumn('user_role');
            $table->dropColumn('user_role_other');
            $table->dropColumn('course_lang');
            $table->dropColumn('course_type');
            $table->dropColumn('duration_type');
            $table->dropColumn('durarion');
            $table->dropColumn('course_time_type');
            $table->dropColumn('course_time_from');
            $table->dropColumn('course_time_to');
            $table->dropColumn('specific_date');
            $table->dropColumn('course_date');
            $table->dropColumn('course_start');
            $table->dropColumn('description');
            $table->dropColumn('fixed_amount');
            $table->dropColumn('hourly_rate');
            $table->dropColumn('cv_submit');
            $table->dropColumn('email_updates');

        });

    }
}
