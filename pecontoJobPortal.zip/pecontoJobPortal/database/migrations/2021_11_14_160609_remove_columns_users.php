<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RemoveColumnsUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('education');
            $table->dropColumn('courses');
            $table->dropColumn('online_courses');
            $table->dropColumn('work_experience');
            $table->dropColumn('certifications');
            $table->dropColumn('headline');
            $table->dropColumn('total_experience');
            $table->enum('role',['user','instructor'])->default('user');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->text('education')->nullable();
            $table->text('education')->nullable();
            $table->text('courses')->nullable();
            $table->text('online_courses')->nullable();
            $table->text('work_experience')->nullable();
            $table->text('certifications')->nullable();
            $table->text('headline')->nullable();
            $table->string('total_experience')->nullable();
            $table->dropColumn('role');

        });
    }
}
