<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsTableInstructorCourses extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('instructor_courses', function (Blueprint $table) {
            $table->text('details')->nullable();
            $table->tinyInteger('capacity')->nullable();
            $table->boolean('fixed_amount')->default(false);
            $table->boolean('hourly_rate')->default(false);
            $table->boolean('on_site')->default(false);
            $table->boolean('online')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('instructor_courses', function (Blueprint $table) {
            $table->dropColumn('details');
            $table->dropColumn('capacity');
            $table->dropColumn('fixed_amount');
            $table->dropColumn('hourly_rate');
            $table->dropColumn('on_site');
            $table->dropColumn('online');
        });
    }
}
