<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('company')->nullable();
            $table->text('headline')->nullable();
            $table->text('education')->nullable();
            $table->text('courses')->nullable();
            $table->text('online_courses')->nullable();
            $table->text('work_experience')->nullable();
            $table->text('certifications')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('company');
            $table->dropColumn('education');
            $table->dropColumn('courses');
            $table->dropColumn('online_courses');
            $table->dropColumn('work_experience');
            $table->dropColumn('headline');
            $table->dropColumn('certifications');
        });
    }
}
