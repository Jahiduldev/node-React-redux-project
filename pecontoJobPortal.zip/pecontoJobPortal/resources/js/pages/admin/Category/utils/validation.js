import * as Yup from 'yup';

export const VALIDATIONSHEMA = Yup.object({
  name: Yup.string().required(),
  label: Yup.string().required()
});
