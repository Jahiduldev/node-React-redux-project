import * as Yup from 'yup';

export const VALIDATIONSHEMA = Yup.object({
  title: Yup.string().required(),
  description: Yup.string().required()
});
