import React, { useEffect, useState } from 'react';
import { Formik } from 'formik';
import { VALIDATIONSHEMA } from '../utils/validation';
import { useDispatch, useSelector } from 'react-redux';
import { editTerms, getTerms } from '../../../../store/reducer/termsSlice';
import Card from '../../../../components/UI/Card';
import BasicBreadcrumbs from '../../../../components/UI/BasicBreadcrubs';
import TermsForm from '../components/Form/TermsForm';
import SimpleSnackbar from '../../../../components/UI/Snackbar';

const EditTerms = () => {
  const dispatch = useDispatch();
  const {fetched} = useSelector(state => state.terms);
  const [openSnackBar, setOpenSnackBar] = useState(false);

  useEffect(() => {
    dispatch(getTerms({id: '2'}));
  }, []);

  const INITIALVALUES = fetched ? {
    title: fetched.title,
    description: fetched.description,
    _method: 'PUT'
  } : {};

  return (
    <div className='w-full bg-gray-200'>
      <div className='container p-2 mx-auto flex flex-col items-start justify-start md:w-3/5 sm:w-full'>
        <BasicBreadcrumbs active='Edit' url='/admin/cms/terms/2' back='CMS' />
        <h3 className='text-2xl font-semibold my-6'>Edit Terms of Use</h3>
        <Card className='bg-white w-full'>
          {fetched && <Formik
            initialValues = {INITIALVALUES}
            validationSchema = {VALIDATIONSHEMA}
            onSubmit={(values, { setSubmitting }) => {
              setSubmitting(true);
              const successCallback = () => {
                setSubmitting(false);
                dispatch(getTerms({id: '2'}));
                setOpenSnackBar(true);
              };
              const failedCallback = () => {
                setSubmitting(false);
              };
              dispatch(editTerms({ id: '2', values, successCallback, failedCallback }));
            }}>
            {formik => (
              <TermsForm fetched={fetched} values={formik.values}/>
            )}
          </Formik>}
        </Card>
      </div>
      {openSnackBar && <SimpleSnackbar message='Updated successfully' open={openSnackBar} handleClose={() => setOpenSnackBar(false)} />}
    </div>
  );
};

export default EditTerms;
