import * as Yup from 'yup';

export const VALIDATIONSHEMA = Yup.object({
  email: Yup.string().email(),
  phone_number: Yup.string(),
  address: Yup.string(),
  website: Yup.string()
});
