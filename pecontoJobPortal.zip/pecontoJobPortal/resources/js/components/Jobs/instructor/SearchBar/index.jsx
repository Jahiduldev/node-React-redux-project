import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { getToken } from '../../../../utils/auth';
import Button from '../../../UI/Button';
import TextError from '../../../UI/TextError';
import Card from '../../../UI/Card';

const SearchJob = () => {
  const token = getToken();
  const [result, setResult] = useState();
  const [name, setName] = useState('');

  const history = useHistory();

  const search = (e) => {
    const name = e.target.value;
    setName(name);
    name !== ''
      ? axios.get(`/api/jobs/search/${name}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }}).then(res => setResult(res.data.data))
      : setResult(false);
  };

  const handleJobClick = (id) => {
    history.push(`/job/show/${id}`);
    setResult(false);
    setName('');
  };

  const handleClick = () => {
    history.push({
      pathname: `/jobs/${name}`,
      state: {title: name}
    });
    setResult(false);
    setName('');
  };

  return (
    <div className="ml-12 relative">
      <input className='bg-gray-200 w-64 h-10 rounded-3xl p-4' type='text' value={name} placeholder="search for jobs here..." onChange={search} />
      {result && <Card className='absolute top-6 z-20 bg-white' style={{width: '400px'}}>
        {result.length === 0
          ? <TextError>No Result Found</TextError>
          : <div className='flec flex-col justify-center items-center w-100'>
            {result.map(job => (
              <div className='flex justify-start items-center p-2 mb-2 hover:bg-gray-200 rounded-2xl cursor-pointer w-full' key={job.id} onClick={() => handleJobClick(job.id)}>
                <h3 className='ml-4 text-sm text-blue-600 font-semibold'>{job.title}</h3>
                <div className="flex flex-row justify-start items-center text-sm">
                  <p className='text-xs font-light italic text-gray-600 ml-5'>{job.country ? job.country.label : null} ({job.course_type || null})</p>
                </div>
              </div>
            ))}
            <div className='w-100 border-b border-gray-300'></div>
            <Button onClick={handleClick} className='text-blue-500 border border-blue-500 rounded-full hover:border-blue-700 hover:bg-blue-200 hover:text-blue-700 hover:border-5 mt-5 mx-auto'>See All Result</Button>
          </div>}
      </Card>}
    </div>
  );
};

export default SearchJob;
