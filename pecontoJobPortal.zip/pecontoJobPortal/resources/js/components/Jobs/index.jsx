/* eslint-disable react/prop-types */
import React from 'react';
import {MdOutlineModeEdit} from 'react-icons/md';
import Card from '../UI/Card';
import { useAuth } from '../../context/auth';
import { useHistory } from 'react-router-dom';

const Jobs = ({jobs}) => {
  const {currentUser} = useAuth();
  const history = useHistory();

  const handleJobClick = (id) => history.push(`/job/show/${id}`);
  const filterdJobs = jobs.filter(job => job.user.id === currentUser.id);

  return (
    <Card className='w-full flex-col justify-start items-start bg-white'>
      {filterdJobs.map(job => (
        <div key={job.id} className="flex flex-row justify-between items-start my-2 w-full border-b border-gray-200 py-4 group">
          <div className="flex flex-col justify-start items-start ml-20">
            <h6 onClick={() => handleJobClick(job.id)} className="text-xl font-semibold text-blue-600 cursor-pointer hover:underline">{job.title}</h6>
            <div className="flex flex-row justify-start items-center text-sm">
              <p>{job.country ? job.country.label : null} {job.city ? job.city.label : null} ({job.course_type || null})</p>
            </div>
            <div className="flex flex-row justify-start items-center text-sm text-gray-700">
              <p>Course Language: <span className='font-semibold'>{job.course_lang || null}</span></p>
            </div>
            <div className="flex flex-row justify-start items-center text-sm text-blue-700">
              {job.fixed_amount && <p>Course Budget: <span className='font-semibold'>{job.fixed_amount}</span> fixed amount</p>}
              {job.hourly_rate && <p>Course Budget: <span className='font-semibold'>{job.hourly_rate}</span> per hour</p>}
            </div>
          </div>
          {job.user.id === currentUser.id && <button onClick={() => history.push(`/job/${job.id}`)} className="ml-2 p-3 hover:bg-gray-200 rounded-full">
            <MdOutlineModeEdit className="w-5 h-5"/>
          </button>}
        </div>
      ))}
    </Card>
  );
};

export default Jobs;
