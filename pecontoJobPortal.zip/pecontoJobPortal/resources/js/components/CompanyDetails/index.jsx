/* eslint-disable react/prop-types */
import React, { Fragment, useState } from 'react';
import {MdOutlineModeEdit} from 'react-icons/md';
import {AiOutlinePhone, AiOutlineLink, AiOutlineHome, AiOutlineMail, AiOutlineUser} from 'react-icons/ai';
import Modal from '../UI/Modal';
import ContactInfoEdit from './Edit';

const ContactInfo = ({userInfo, onClose, fetch, fetchInfo, setUserId, isCurrentUser}) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const handleShowEditModal = () => {
    setShowEditModal(true);
  };
  return (
    <Fragment>
      <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
        <div className="relative w-1/3 mx-auto max-w-3xl ">
          <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
            <div className="flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t">
              <h3 className="text-2xl">
                {userInfo.first_name} {userInfo.last_name}
              </h3>
              <button
                className="p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none"
                onClick={onClose}
              >
                <span className="bg-transparent text-black opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none">
                  ×
                </span>
              </button>
            </div>
            {/* body */}
            <div className="relative p-6 flex-auto">
              <div className="flex flex-row justify-between items-center">
                <h5 className="text-xl">Contact Info</h5>
                {isCurrentUser && <button onClick={handleShowEditModal} className="ml-2 p-3 hover:bg-gray-200 rounded-full">
                  <MdOutlineModeEdit className="w-5 h-5"/>
                </button>}
              </div>
              <div className="flex flex-col justify-start items-start">
                {userInfo.profile_url && <div className="flex flex-row justify-start items-start my-2">
                  <AiOutlineUser className="w-5 h-5 mt-1 mr-4"/>
                  <div className="flex flex-col justify-start items-start">
                    <h6 className="text-lg font-semibold">Your Profile</h6>
                    <p>{userInfo.profile_url}</p>
                  </div>
                </div>}

                {userInfo.website && <div className="flex flex-row justify-start items-start my-2">
                  <AiOutlineLink className="w-5 h-5 mt-1 mr-4"/>
                  <div className="flex flex-col justify-start items-start">
                    <h6 className="text-lg font-semibold">Website</h6>
                    <p>{userInfo.website}</p>
                  </div>
                </div>}

                {userInfo.phone_number && <div className="flex flex-row justify-start items-start my-2">
                  <AiOutlinePhone className="w-5 h-5 mt-1 mr-4"/>
                  <div className="flex flex-col justify-start items-start">
                    <h6 className="text-lg font-semibold">Phone number</h6>
                    <p>{userInfo.phone_number}</p>
                  </div>
                </div>}

                {userInfo.email && <div className="flex flex-row justify-start items-start my-2">
                  <AiOutlineMail className="w-5 h-5 mt-1 mr-4"/>
                  <div className="flex flex-col justify-start items-start">
                    <h6 className="text-lg font-semibold">Email</h6>
                    <p>{userInfo.email}</p>
                  </div>
                </div>}

                {userInfo.address && <div className="flex flex-row justify-start items-start my-2">
                  <AiOutlineHome className="w-5 h-5 mt-1 mr-4"/>
                  <div className="flex flex-col justify-start items-start">
                    <h6 className="text-lg font-semibold">Address</h6>
                    <p><span>{userInfo.country && `${userInfo.country.label},`}</span> <span>{userInfo.city && `${userInfo.city.label},`}</span> {userInfo.address}</p>
                  </div>
                </div>}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="opacity-75 fixed inset-0 z-40 bg-black"></div>
      {showEditModal && <Modal title="Edit Contact info" onClose={() => setShowEditModal(false)}><ContactInfoEdit fetch={fetch} fetchInfo={fetchInfo} setUserId={setUserId} userId={userInfo.id} onClose={() => setShowEditModal(false)} userInfo={userInfo}/></Modal>}
    </Fragment>
  );
};

export default ContactInfo;
