import * as Yup from 'yup';

export const VALIDATIONSHEMA = Yup.object({
  name: Yup.string(),
  user_role: Yup.string(),
  category_id: Yup.string(),
  sub_category_id: Yup.string(),
  about: Yup.string()
});
