/* eslint-disable react/prop-types */
/* eslint-disable standard/array-bracket-even-spacing */
import React, {useEffect, useState} from 'react';
import Check from '../UI/Check';
import axios from 'axios';
import { getToken } from '../../utils/auth';
import Button from '../UI/Button';
import ArrowNext from '../UI/Icons/ArrowNext';

function FieldsOfInterest ({onClose}) {
  const [fieldOfInterests, setFieldOfInterests] = useState(null);
  const [selected, setSelected] = useState([]);

  const token = getToken();

  useEffect(() => {
    axios.get(`/api/categories`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }}).then(res => {
      setFieldOfInterests(res.data.data);
    });
  }, []);

  const isSelected = (field) => {
    return selected.find(selectedItem => selectedItem === field);
  };

  const toggleSelect = (field) => {
    if (isSelected(field)) {
      if (selected.indexOf(field) > -1) {
        setSelected(selected => {
          selected.splice(selected.indexOf(field), 1);
          return selected;
        });
      }
    } else {
      setSelected(selected => [...selected, field]);
    }
  };

  const handleClick = () => {
    onClose();
  };

  return (
    <div>
      <div className='flex flex-col justify-center items-center mb-16'>
        <h1 className='text-4xl text-primary font-body font-semibold' >Fields of Interest</h1>
        <p className='text-lg text-primary font-normal opacity-75' >Select what you&apos;d like to improve and have a training in.</p>
      </div>

      <div className='flex justify-center items-start gap-y-5 gap-x-4 flex-wrap'>
        {fieldOfInterests && fieldOfInterests.map(field => (
          <Check field={field} key={field.id} toggleSelect={toggleSelect} />
        ))}
      </div>

      <Button className='text-primary border-2  mx-auto hover:border-primary hover:font-bold' onClick={handleClick}> <ArrowNext/> Next</Button>
    </div>
  );
}

export default FieldsOfInterest;
