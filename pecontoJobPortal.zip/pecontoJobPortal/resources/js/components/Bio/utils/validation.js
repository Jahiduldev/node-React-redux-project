import * as Yup from 'yup';

export const VALIDATIONSHEMA = Yup.object({
  about: Yup.string()
});
