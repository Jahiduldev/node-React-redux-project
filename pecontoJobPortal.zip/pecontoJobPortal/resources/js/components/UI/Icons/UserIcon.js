import React from 'react';

const UserIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><rect width="24" height="24" fill="#0f4975" opacity="0"/><g transform="translate(-3.25 -3.75)"><path d="M13.711,3.75a5.461,5.461,0,1,0,5.461,5.461A5.461,5.461,0,0,0,13.711,3.75Z" transform="translate(1.826)" fill="#0f4975"/><path d="M9.711,13.25A5.461,5.461,0,0,0,4.25,18.711v1.731a2.238,2.238,0,0,0,1.878,2.209,58.394,58.394,0,0,0,18.819,0,2.238,2.238,0,0,0,1.878-2.209V18.711a5.461,5.461,0,0,0-5.461-5.461h-.5a2.552,2.552,0,0,0-.791.126l-1.261.412a10.56,10.56,0,0,1-6.555,0L11,13.376a2.552,2.552,0,0,0-.791-.126Z" transform="translate(0 4.336)" fill="#0f4975"/></g></svg>
  );
};

export default UserIcon;
