import React from 'react';

const ArrowBack = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><rect width="24" height="24" fill="#24a0dc" opacity="0"/><path d="M10.251,1.867a.965.965,0,0,1,0-1.34.906.906,0,0,1,1.305,0L16.48,5.58a.965.965,0,0,1,0,1.34l-4.923,5.053a.906.906,0,0,1-1.305,0,.965.965,0,0,1,0-1.34L13.6,7.2H1.673a.948.948,0,0,1,0-1.895H13.6Z" transform="translate(20.75 18.25) rotate(180)" fill="#0f4975"/></svg>
  );
};

export default ArrowBack;
