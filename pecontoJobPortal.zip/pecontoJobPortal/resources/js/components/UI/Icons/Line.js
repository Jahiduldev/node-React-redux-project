import React from 'react';

const Line = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="150" height="1" viewBox="0 0 150 1"><path d="M0,0H150" transform="translate(0 0.5)" fill="none" stroke="rgba(15,73,117,0.2)" strokeWidth="1"/></svg>
  );
};

export default Line;
