import React from 'react';

const OptionIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><rect width="24" height="24" fill="#fff" opacity="0"/><path d="M12.361,5.25A1.111,1.111,0,1,1,11.25,6.361,1.111,1.111,0,0,1,12.361,5.25Zm0,8.889A1.111,1.111,0,1,1,11.25,15.25,1.111,1.111,0,0,1,12.361,14.139Zm0,8.889a1.111,1.111,0,1,1-1.111,1.111A1.111,1.111,0,0,1,12.361,23.028Z" transform="translate(-2.75 23.973) rotate(-90)" fill="#0f4975" stroke="#0f4975" strokeWidth="2"/></svg>
  );
};

export default OptionIcon;
