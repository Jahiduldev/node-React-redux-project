import React from 'react';

// eslint-disable-next-line react/prop-types
const Card = ({className, children, ...restProps}) => {
  return (
    <div className={'flex rounded-lg py-3 px-6 shadow-lg h-auto ' + className} {...restProps}>{children}</div>);
};

export default Card;
