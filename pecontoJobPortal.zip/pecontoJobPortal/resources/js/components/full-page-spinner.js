import React from 'react';

function FullPageSpinner () {
  return (
    <div className="p-2">loading</div>
  );
}

export default FullPageSpinner;
