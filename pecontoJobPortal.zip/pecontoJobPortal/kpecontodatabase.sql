-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: peconto
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applies`
--

DROP TABLE IF EXISTS `applies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `resume` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_letter` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned DEFAULT NULL,
  `job_id` bigint unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `applies_user_id_foreign` (`user_id`),
  KEY `applies_job_id_foreign` (`job_id`),
  CONSTRAINT `applies_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `applies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applies`
--

LOCK TABLES `applies` WRITE;
/*!40000 ALTER TABLE `applies` DISABLE KEYS */;
INSERT INTO `applies` VALUES (3,'1647954268_39605_word count.pdf','Consequatur Qui ape',47,4,NULL,'2022-03-22 13:04:28','2022-03-22 13:04:28'),(4,'1647954421_34608_word count.pdf','Titl11',47,4,NULL,'2022-03-22 13:07:01','2022-03-22 13:07:01'),(5,'1647958585_95163_word count.pdf','test',47,4,NULL,'2022-03-22 14:16:25','2022-03-22 14:16:25'),(6,'1647962755_47438_word count.pdf','letter',47,5,NULL,'2022-03-22 15:25:55','2022-03-22 15:25:55'),(7,'1648049953_44537_Untitled document.docx','title',47,4,NULL,'2022-03-23 15:39:13','2022-03-23 15:39:13'),(8,'1648049976_50763_Untitled document.docx','letter',47,5,NULL,'2022-03-23 15:39:36','2022-03-23 15:39:36'),(9,'1648050155_27804_Untitled document.docx','letter title',47,5,NULL,'2022-03-23 15:42:35','2022-03-23 15:42:35'),(10,'1648054880_18880_abdelrahman resume.pdf','abdelrahman',5,4,NULL,'2022-03-23 17:01:20','2022-03-23 17:01:20'),(11,'1648134469_63520_Test Account Credentials.pdf','doc',33,5,NULL,'2022-03-24 15:07:49','2022-03-24 15:07:49'),(12,'1648134483_68510_Test Account Credentials.pdf','doc',33,5,NULL,'2022-03-24 15:08:03','2022-03-24 15:08:03'),(13,'1648134598_63269_AdminPanel-2022-02-01.pdf','eee',33,5,NULL,'2022-03-24 15:09:58','2022-03-24 15:09:58'),(14,'1648563315_39852_abdelrahman resume.pdf','test111',5,4,NULL,'2022-03-29 14:15:15','2022-03-29 14:15:15'),(15,'1648563384_76967_word count.pdf','letter11',47,5,NULL,'2022-03-29 14:16:24','2022-03-29 14:16:24'),(16,'1648563572_16030_abdelrahman resume.pdf','test',53,4,NULL,'2022-03-29 14:19:32','2022-03-29 14:19:32'),(17,'1648564148_54797_word count.pdf','111',15,4,NULL,'2022-03-29 14:29:08','2022-03-29 14:29:08'),(18,'1648564202_97103_Untitled document.docx','2222',15,4,NULL,'2022-03-29 14:30:02','2022-03-29 14:30:02'),(19,'1648564297_30162_1648564148_54797_word count.pdf','test',15,4,NULL,'2022-03-29 14:31:37','2022-03-29 14:31:37'),(20,'1648564353_80975_abdelrahman resume.pdf','abdelrahman cv',53,4,NULL,'2022-03-29 14:32:33','2022-03-29 14:32:33'),(21,'1648564554_77817_Wael Ahmed Mohammedtest 2021.docx','test apply 1',15,5,NULL,'2022-03-29 14:35:54','2022-03-29 14:35:54'),(22,'1648564765_59964_Wael Ahmed Mohammedtest 2021.pdf','test apply 2',15,4,NULL,'2022-03-29 14:39:25','2022-03-29 14:39:25'),(23,'1649012283_54171_Wael Ahmed Mohammedtest 2021.pdf','test apply',15,6,NULL,'2022-04-03 18:58:03','2022-04-03 18:58:03'),(24,'1649012300_24787_Wael Ahmed Mohammedtest 2021.docx','test apply',15,6,NULL,'2022-04-03 18:58:20','2022-04-03 18:58:20'),(25,'1649420143_46489_HR-recuriment interview questions.docx','tesy',15,9,NULL,'2022-04-08 12:15:43','2022-04-08 12:15:43'),(26,'1649590148_29355_Linkedin redesign ui kit.pdf','Ex nobis hic duis es',53,10,NULL,'2022-04-10 11:29:08','2022-04-10 11:29:08'),(27,'1653490889_26625_abdelrahman resume.pdf',NULL,55,6,NULL,'2022-05-25 15:01:29','2022-05-25 15:01:29'),(28,'1653850791_49483_Wael Ahmed Mohammedtest 2021.pdf','e',15,6,NULL,'2022-05-29 18:59:51','2022-05-29 18:59:51'),(29,'1655139548_86104_اثممخ.pdf','test applying',55,13,NULL,'2022-06-13 16:59:08','2022-06-13 16:59:08'),(30,'1672775243_70536_renew NIAM certeficate in F5LB v1.0.docx',NULL,93,16,NULL,'2023-01-03 19:47:23','2023-01-03 19:47:23'),(31,'1675501672_20458_سيستم ادارة عيادة عبر الموقع الإلكتروني.docx','test',104,10,NULL,'2023-02-04 09:07:52','2023-02-04 09:07:52');
/*!40000 ALTER TABLE `applies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_m_s`
--

DROP TABLE IF EXISTS `c_m_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_m_s` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `page_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_m_s`
--

LOCK TABLES `c_m_s` WRITE;
/*!40000 ALTER TABLE `c_m_s` DISABLE KEYS */;
INSERT INTO `c_m_s` VALUES (1,'privacy','Privacy Policy','<p>Peconto <span style=\"color: rgba(0, 0, 0, 0.9);\">mission is to connect the world’s Trainee with their Trainer to allow them to be more productive and successful. </span></p>',NULL,'2022-06-30 10:53:10'),(2,'terms','Terms of Use','<p>Term of use under reveiew once finished will be published </p>',NULL,'2022-06-30 12:08:39');
/*!40000 ALTER TABLE `c_m_s` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'business','Business',NULL,'2022-03-15 11:59:20','2022-10-01 19:33:17'),(2,'programming','Programming',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(3,'it','IT',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(4,'Rhonda','Officiis neque quo r','2022-06-05 12:45:01','2022-06-05 12:44:51','2022-06-05 12:45:01'),(5,'design','Design',NULL,'2022-06-06 16:28:34','2022-06-06 16:28:34'),(6,'Lee Harrington','Modi at et commodi q','2022-06-23 18:57:36','2022-06-22 20:59:32','2022-06-23 18:57:36'),(7,'James Lancaster','Nam repudiandae prae','2022-06-23 18:57:46','2022-06-23 18:57:43','2022-06-23 18:57:46'),(8,'Odysseus','Nihil fugit volupta','2022-06-23 19:10:15','2022-06-23 19:10:06','2022-06-23 19:10:15'),(9,'Telecommunication','Telecommunication',NULL,'2022-06-23 19:15:53','2022-07-01 19:44:29'),(10,'Finance & Accounting','Finance & Accounting',NULL,'2022-06-25 17:05:58','2022-06-25 17:05:58'),(11,'pharmacology','pharmacology',NULL,'2022-09-17 17:41:26','2022-09-17 17:41:26');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issuing_organization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credential_not_expire` tinyint(1) DEFAULT NULL,
  `issue_date_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue_date_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration_date_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration_date_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credential_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `certificates_user_id_foreign` (`user_id`),
  CONSTRAINT `certificates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES (1,'Barrett Garza','Lewis Alston LLC',0,'Oct','1977','Dec','2002',NULL,'Eum architecto ipsum@test.com',1,'2022-03-15 12:03:38','2022-03-15 12:03:38'),(2,'Kasimir Galloway','Harris Avery Associates',0,'May','2013','Feb','1986',NULL,'http://www.google.com',5,'2022-03-15 12:10:16','2022-03-15 12:10:16'),(4,'CCSI','Cisco',0,'Sept','2007','Nov','2022',NULL,NULL,15,'2022-03-16 20:00:57','2022-03-16 20:00:57'),(6,'Sandra Holloway','Camacho and Bowers Associates',0,'June','1972','Mar','2004',NULL,'https://mail.goo.com',33,'2022-03-17 15:46:55','2022-03-17 15:46:55'),(7,'Savannah Fry','Clemons Miles Plc',0,'Sept','1993','May','2013',NULL,'sddf.com',41,'2022-03-17 19:04:29','2022-03-17 19:04:29'),(8,'CISSP','ISC 2',0,'Jan','2010','Nov','2013',NULL,NULL,51,'2022-03-20 16:34:23','2022-03-20 16:34:23'),(9,'Python','pythona',0,'Jan','2018','Aug','2020',NULL,NULL,73,'2022-11-30 18:56:36','2022-11-30 18:56:36'),(10,'CISM','ISACA',0,'Nov','2022','Nov','2023',NULL,NULL,110,'2023-03-01 16:18:12','2023-03-01 16:18:12');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cities_country_id_foreign` (`country_id`),
  CONSTRAINT `cities_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'cairo','Cairo',1,NULL,NULL),(2,'giza','Giza',1,NULL,NULL),(3,'alexandria','Alexandria',1,NULL,NULL),(4,'riyadh','Riyadh',2,NULL,NULL),(5,'jeddah','Jeddah',2,NULL,NULL),(6,'makkah','Makkah',2,NULL,NULL),(7,'dubai','Dubai',3,NULL,NULL),(8,'abu dhabi','Abu Dhabi',3,NULL,NULL),(9,'sharjah','Sharjah',3,NULL,NULL);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_post_id_foreign` (`post_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'Comment',1,7,'2022-03-15 15:38:01','2022-03-15 15:38:01',NULL),(3,'Hi start',3,17,'2022-03-16 20:06:41','2022-03-16 20:06:41',NULL),(10,'test',10,41,'2022-03-17 19:50:40','2022-03-17 19:50:40',NULL),(11,'test again',10,41,'2022-03-17 19:53:33','2022-03-17 19:53:33',NULL),(12,'Hi wael test notefication',10,15,'2022-03-21 20:29:31','2022-03-21 20:29:31',NULL),(13,'comment',11,45,'2022-03-27 13:35:40','2022-03-27 13:35:40',NULL),(14,'comment',13,45,'2022-03-27 13:39:38','2022-03-27 13:39:38',NULL),(15,'yes wAEL HOW ARE YOU',14,15,'2022-03-27 17:52:50','2022-03-27 17:52:50',NULL),(16,'hI sTAT',3,17,'2022-03-27 17:53:46','2022-03-27 17:53:46',NULL),(17,'testy notefication for instructor',3,49,'2022-03-27 18:01:00','2022-03-27 18:01:00',NULL),(18,'hi wael',14,49,'2022-05-28 18:30:41','2022-05-28 18:30:41',NULL),(19,'hi wael',14,49,'2022-05-28 18:30:43','2022-05-28 18:30:43',NULL),(20,'When',15,15,'2022-05-29 19:04:20','2022-05-29 19:04:20',NULL),(21,'when',15,17,'2022-05-29 19:05:25','2022-05-29 19:05:25',NULL),(22,'I hope it work fine now',17,15,'2022-06-30 15:43:30','2022-06-30 15:43:30',NULL),(23,'I hope it work fine now',17,15,'2022-06-30 15:43:34','2022-06-30 15:43:34',NULL),(24,'I hope it work fine now',17,15,'2022-06-30 15:43:37','2022-06-30 15:43:37',NULL),(25,'I hope it work fine now',17,15,'2022-06-30 15:43:39','2022-06-30 15:43:39',NULL),(26,'I hope it work fine now',17,15,'2022-06-30 15:43:39','2022-06-30 15:43:39',NULL),(27,'I hope it work fine now',17,15,'2022-06-30 15:43:40','2022-06-30 15:43:40',NULL),(28,'I hope it work fine now',17,15,'2022-06-30 15:43:40','2022-06-30 15:43:40',NULL),(29,'I hope it work fine now',17,15,'2022-06-30 15:43:40','2022-06-30 15:43:40',NULL),(30,'I hope it work fine now',17,15,'2022-06-30 15:43:42','2022-06-30 15:43:42',NULL),(31,'test comment',16,17,'2022-07-01 19:39:28','2022-07-01 19:39:28',NULL),(32,'test comment',16,17,'2022-07-01 19:39:31','2022-07-01 19:39:31',NULL),(33,'test comment',16,17,'2022-07-01 19:39:33','2022-07-01 19:39:33',NULL),(34,'test comment',16,17,'2022-07-01 19:39:35','2022-07-01 19:39:35',NULL),(35,'test comment',16,17,'2022-07-01 19:39:39','2022-07-01 19:39:39',NULL),(36,'test comment',18,55,'2022-07-01 19:46:00','2022-07-01 19:46:00',NULL),(37,'test comment',18,55,'2022-07-01 19:46:02','2022-07-01 19:46:02',NULL),(38,'test comment',17,5,'2022-07-03 14:41:42','2022-07-03 14:41:47','2022-07-03 14:41:47'),(39,'nice',19,17,'2022-07-03 17:24:16','2022-07-03 17:24:16',NULL),(40,'test',18,17,'2022-07-03 20:43:43','2022-07-03 20:43:57','2022-07-03 20:43:57'),(41,'test comment',15,5,'2022-07-04 12:00:13','2022-07-04 12:00:20','2022-07-04 12:00:20'),(42,'test',17,25,'2022-07-04 13:56:03','2022-07-04 13:56:03',NULL),(43,'test coment',20,25,'2022-07-04 13:57:24','2022-07-04 13:57:24',NULL),(44,'test comment',19,25,'2022-07-04 16:14:56','2022-07-04 16:15:03','2022-07-04 16:15:03'),(45,'test deleet',18,17,'2022-07-04 22:28:13','2022-07-04 22:28:13',NULL),(46,'comment for wael',19,60,'2022-10-01 19:19:16','2022-10-01 19:19:16',NULL),(47,'test comment to see the notification',21,58,'2022-10-10 10:21:53','2022-10-10 10:21:53',NULL);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_details`
--

DROP TABLE IF EXISTS `company_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `sub_category_id` bigint unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_role` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'owner',
  PRIMARY KEY (`id`),
  KEY `company_details_user_id_foreign` (`user_id`),
  KEY `company_details_category_id_foreign` (`category_id`),
  KEY `company_details_sub_category_id_foreign` (`sub_category_id`),
  CONSTRAINT `company_details_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `company_details_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `company_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_details`
--

LOCK TABLES `company_details` WRITE;
/*!40000 ALTER TABLE `company_details` DISABLE KEYS */;
INSERT INTO `company_details` VALUES (2,'Irma Rodgers','Et omnis aperiam ull Et omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ull',NULL,25,2,4,NULL,'2022-03-17 14:16:20','2022-03-17 14:16:20','owner');
/*!40000 ALTER TABLE `company_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_us` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` VALUES (1,'Hakeem Foreman','fasobyc@mailinator.com','Quaerat culpa doloru','Cumque vel accusanti',NULL,'2022-03-15 12:13:13','2022-03-15 12:13:13'),(2,'Griffin Navarro','watyloryx@mailinator.com','Qui qui quidem molli','Dolore sunt corpori',NULL,'2022-03-15 12:15:11','2022-03-15 12:15:11'),(3,'Judah Barlow','teqi@mailinator.com','Voluptas a accusamus','Incidunt velit ull',NULL,'2022-03-15 12:20:35','2022-03-15 12:20:35'),(4,'Deborah Mendez','zymohuny@mailinator.com','Dolorem natus sint m','Rerum aute ipsam lab',NULL,'2022-03-15 12:21:12','2022-03-15 12:21:12'),(5,'Dillon Baxter','sonel@mailinator.com','Iure et quasi suscip','Impedit explicabo',NULL,'2022-03-15 15:42:09','2022-03-15 15:42:09'),(6,'Wael','wsadani@hotmail.com','test','test',NULL,'2022-10-03 00:23:58','2022-10-03 00:23:58'),(7,'Wael','wsadani@gmail.com','test coment to suppourt','test coment to suppourt',NULL,'2022-10-15 13:09:54','2022-10-15 13:09:54');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'egypt','Egypt',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(2,'saudi arabia','Saudi Arabia',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(3,'united arab emirates','United Arab Emirates',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_category_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_sub_category_id_foreign` (`sub_category_id`),
  KEY `courses_category_id_foreign` (`category_id`),
  CONSTRAINT `courses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `courses_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'PMP Certification Training ','PMP Certification Training ',1,NULL,NULL,NULL,1),(2,'Consumer Demand','Consumer Demand',2,NULL,NULL,NULL,1),(3,'Behavior of Buyers and Sellers & Product Pricing','Behavior of Buyers and Sellers & Product Pricing',2,NULL,NULL,NULL,1),(4,'Fundamentals of Java Programming','Fundamentals of Java Programming',3,NULL,NULL,NULL,2),(5,'Html & CSS','Html & CSS',3,NULL,NULL,NULL,2),(6,'Swift 4 Development','Swift 4 Development',4,NULL,NULL,NULL,2),(7,'Algorthims & Data Structures','Algorthims & Data Structures',5,NULL,NULL,NULL,2),(8,'Certified Information Systems Security Professional (CISSP)','Certified Information Systems Security Professional (CISSP)',6,NULL,NULL,NULL,3),(9,'Certified in Risk and Information Systems Control (CRISC)\n            ','Certified in Risk and Information Systems Control (CRISC)',7,NULL,NULL,NULL,3);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'usd','USD',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(2,'eur','EUR',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(3,'egp','EGP',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(4,'sar','SAR',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(5,'aed','AED',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(6,'kwd','KWD',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_study` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activities_societies` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `education_user_id_foreign` (`user_id`),
  CONSTRAINT `education_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` VALUES (1,'Voluptatem Quam mag','Animi in dolor non',NULL,'Feb','2010','Oct',NULL,NULL,NULL,1,'2022-03-15 12:03:27','2022-03-15 12:03:27'),(2,'Culpa eaque aperiam','Provident pariatur',NULL,'Dec','2015','Mar',NULL,NULL,NULL,5,'2022-03-15 12:07:39','2022-03-15 12:07:39'),(4,'King Abd Al aziz university','Master cybersecurity',NULL,'Apr','2005','Dec',NULL,NULL,NULL,15,'2022-03-16 20:00:16','2022-03-16 20:00:16'),(6,'Dolore a voluptatem','Accusantium et aut a',NULL,'Dec','1988','Sept',NULL,NULL,NULL,33,'2022-03-17 15:46:26','2022-03-17 15:46:26'),(7,'Consectetur in volu','Adipisci sed perfere',NULL,'Mar','1977','Dec',NULL,NULL,NULL,41,'2022-03-17 19:04:20','2022-03-17 19:04:20'),(8,'Ain Shams university','Computer and system Dept',NULL,'Sept','2019','Oct',NULL,NULL,NULL,51,'2022-03-20 16:33:32','2022-03-20 16:33:32'),(9,'mis','GRADE 5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,73,'2022-11-30 18:55:44','2022-11-30 18:55:44'),(10,'Cairo','BSC',NULL,'Nov','2005','Nov',NULL,NULL,NULL,110,'2023-03-01 16:17:43','2023-03-01 16:17:43');
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employment_types`
--

DROP TABLE IF EXISTS `employment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employment_types`
--

LOCK TABLES `employment_types` WRITE;
/*!40000 ALTER TABLE `employment_types` DISABLE KEYS */;
INSERT INTO `employment_types` VALUES (1,'full_time','Full-time',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(2,'part_time','Part-time',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(3,'contract','Contract',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(4,'temporary','Temporary',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(5,'volunteer','Volunteer',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(6,'internship','Internship',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20');
/*!40000 ALTER TABLE `employment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experiences`
--

DROP TABLE IF EXISTS `experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experiences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_type` enum('full-time','part-time','self-employed','freelance','contract','interneship','seasonal','apprenticeship') COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `currently_working` tinyint(1) NOT NULL DEFAULT '0',
  `end_current_position` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `country_id` bigint unsigned NOT NULL,
  `city_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `experiences_user_id_foreign` (`user_id`),
  KEY `experiences_category_id_foreign` (`category_id`),
  KEY `experiences_country_id_foreign` (`country_id`),
  KEY `experiences_city_id_foreign` (`city_id`),
  CONSTRAINT `experiences_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `experiences_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `experiences_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `experiences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experiences`
--

LOCK TABLES `experiences` WRITE;
/*!40000 ALTER TABLE `experiences` DISABLE KEYS */;
INSERT INTO `experiences` VALUES (1,'Cupidatat rerum ad i','part-time','Fry Kirby LLC','Dec','2005',NULL,NULL,NULL,'Sunt fugiat pariatu',1,0,1,'2022-03-15 12:03:09','2022-03-15 12:03:09',1,2,4),(2,'Aut voluptatum magna','self-employed','Hunter Glover Co','Jan','2021',NULL,NULL,NULL,'Eius occaecat veniam',1,0,5,'2022-03-15 12:07:36','2022-03-15 12:07:36',3,1,2),(5,'Velit ut aut ration','interneship','Hull Dejesus Traders','July','2011',NULL,NULL,NULL,'Quo mollit qui ipsum',1,0,33,'2022-03-17 15:46:18','2022-03-17 15:46:18',1,2,5),(7,'Quia est in molestia','self-employed','Gregory Shaffer Associates','May','2012',NULL,NULL,NULL,'Non omnis eius nulla',1,0,41,'2022-03-17 19:04:17','2022-03-17 19:04:17',2,2,4),(8,'cyber security consultant','full-time','Innovative Solutions SA','July','2013',NULL,NULL,NULL,NULL,1,0,51,'2022-03-20 16:32:06','2022-03-20 16:32:06',3,2,4),(9,'PYTHON INSTRUCTOR','full-time','PYTHONA','Jan','2020',NULL,NULL,NULL,NULL,1,0,73,'2022-11-30 18:55:26','2022-11-30 18:55:26',2,3,7),(10,'IT','self-employed','Peconto','June','2007','Oct','2023',NULL,'IT',0,0,110,'2023-03-01 16:17:17','2023-03-01 16:17:17',3,1,1);
/*!40000 ALTER TABLE `experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields_of_interests`
--

DROP TABLE IF EXISTS `fields_of_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields_of_interests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fields_of_interests_user_id_foreign` (`user_id`),
  KEY `fields_of_interests_category_id_foreign` (`category_id`),
  CONSTRAINT `fields_of_interests_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fields_of_interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields_of_interests`
--

LOCK TABLES `fields_of_interests` WRITE;
/*!40000 ALTER TABLE `fields_of_interests` DISABLE KEYS */;
INSERT INTO `fields_of_interests` VALUES (1,1,1,NULL,'2022-03-15 12:00:53','2022-03-15 12:00:53'),(2,1,2,NULL,'2022-03-15 12:00:53','2022-03-15 12:00:53'),(3,5,1,NULL,'2022-03-15 12:06:52','2022-03-15 12:06:52'),(4,5,2,NULL,'2022-03-15 12:06:52','2022-03-15 12:06:52'),(5,11,1,NULL,'2022-03-15 15:40:38','2022-03-15 15:40:38'),(6,11,2,NULL,'2022-03-15 15:40:38','2022-03-15 15:40:38'),(7,11,3,NULL,'2022-03-15 15:40:38','2022-03-15 15:40:38'),(11,15,3,NULL,'2022-03-16 19:46:42','2022-03-16 19:46:42'),(17,25,1,NULL,'2022-03-17 14:11:51','2022-03-17 14:11:51'),(18,25,2,NULL,'2022-03-17 14:11:51','2022-03-17 14:11:51'),(25,33,1,NULL,'2022-03-17 15:44:47','2022-03-17 15:44:47'),(26,33,2,NULL,'2022-03-17 15:44:47','2022-03-17 15:44:47'),(36,41,1,NULL,'2022-03-17 19:03:13','2022-03-17 19:03:13'),(37,41,2,NULL,'2022-03-17 19:03:13','2022-03-17 19:03:13'),(38,41,3,NULL,'2022-03-17 19:03:13','2022-03-17 19:03:13'),(42,47,2,NULL,'2022-03-17 19:31:53','2022-03-17 19:31:53'),(43,47,1,NULL,'2022-03-17 19:31:53','2022-03-17 19:31:53'),(44,45,2,NULL,'2022-03-17 19:36:12','2022-03-17 19:36:12'),(45,45,1,NULL,'2022-03-17 19:36:12','2022-03-17 19:36:12'),(46,49,3,NULL,'2022-03-20 15:10:13','2022-03-20 15:10:13'),(47,49,2,NULL,'2022-03-20 15:10:13','2022-03-20 15:10:13'),(48,49,1,NULL,'2022-03-20 15:10:13','2022-03-20 15:10:13'),(49,51,3,NULL,'2022-03-20 16:28:26','2022-03-20 16:28:26'),(50,51,2,NULL,'2022-03-20 16:28:26','2022-03-20 16:28:26'),(51,51,1,NULL,'2022-03-20 16:28:26','2022-03-20 16:28:26'),(52,17,3,NULL,'2022-03-21 20:21:11','2022-03-21 20:21:11'),(53,17,2,NULL,'2022-03-21 20:21:11','2022-03-21 20:21:11'),(54,17,1,NULL,'2022-03-21 20:21:11','2022-03-21 20:21:11'),(55,57,2,NULL,'2022-09-25 18:16:44','2022-09-25 18:16:44'),(56,57,3,NULL,'2022-09-25 18:16:44','2022-09-25 18:16:44'),(57,60,1,NULL,'2022-09-26 19:36:26','2022-09-26 19:36:26'),(58,60,2,NULL,'2022-09-26 19:36:26','2022-09-26 19:36:26'),(59,60,3,NULL,'2022-09-26 19:36:26','2022-09-26 19:36:26'),(60,60,5,NULL,'2022-09-26 19:36:26','2022-09-26 19:36:26'),(61,62,1,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(62,62,2,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(63,62,3,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(64,62,5,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(65,62,9,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(66,62,10,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(67,62,11,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53'),(68,67,2,NULL,'2022-11-03 10:24:35','2022-11-03 10:24:35'),(69,68,1,NULL,'2022-11-04 07:04:22','2022-11-04 07:04:22'),(70,68,5,NULL,'2022-11-04 07:04:22','2022-11-04 07:04:22'),(71,70,5,NULL,'2022-11-07 07:40:24','2022-11-07 07:40:24'),(72,70,9,NULL,'2022-11-07 07:40:24','2022-11-07 07:40:24'),(73,70,2,NULL,'2022-11-07 07:40:24','2022-11-07 07:40:24'),(74,70,3,NULL,'2022-11-07 07:40:24','2022-11-07 07:40:24'),(75,73,2,NULL,'2022-11-30 18:50:46','2022-11-30 18:50:46'),(76,79,1,NULL,'2022-12-12 20:53:21','2022-12-12 20:53:21'),(77,79,9,NULL,'2022-12-12 20:53:21','2022-12-12 20:53:21'),(78,79,10,NULL,'2022-12-12 20:53:21','2022-12-12 20:53:21'),(79,80,9,NULL,'2022-12-12 21:50:45','2022-12-12 21:50:45'),(80,80,2,NULL,'2022-12-12 21:50:45','2022-12-12 21:50:45'),(81,81,1,NULL,'2022-12-12 21:59:36','2022-12-12 21:59:36'),(82,81,9,NULL,'2022-12-12 21:59:36','2022-12-12 21:59:36'),(83,81,2,NULL,'2022-12-12 21:59:36','2022-12-12 21:59:36'),(84,83,1,NULL,'2022-12-13 08:31:18','2022-12-13 08:31:18'),(85,83,3,NULL,'2022-12-13 08:31:18','2022-12-13 08:31:18'),(86,91,3,NULL,'2023-01-03 19:23:42','2023-01-03 19:23:42'),(87,93,3,NULL,'2023-01-03 19:46:25','2023-01-03 19:46:25'),(88,94,3,NULL,'2023-01-11 19:54:47','2023-01-11 19:54:47'),(89,95,2,NULL,'2023-01-25 19:58:15','2023-01-25 19:58:15'),(90,95,3,NULL,'2023-01-25 19:58:15','2023-01-25 19:58:15'),(91,96,3,NULL,'2023-01-28 13:30:21','2023-01-28 13:30:21'),(92,98,1,NULL,'2023-01-30 00:31:27','2023-01-30 00:31:27'),(93,98,3,NULL,'2023-01-30 00:31:27','2023-01-30 00:31:27'),(94,100,1,NULL,'2023-01-30 11:17:41','2023-01-30 11:17:41'),(95,102,1,NULL,'2023-01-31 11:09:26','2023-01-31 11:09:26'),(96,103,2,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(97,103,1,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(98,103,3,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(99,103,5,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(100,103,9,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(101,103,11,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(102,103,10,NULL,'2023-02-02 19:54:29','2023-02-02 19:54:29'),(103,97,5,NULL,'2023-02-04 18:41:49','2023-02-04 18:41:49'),(104,105,2,NULL,'2023-02-11 13:30:10','2023-02-11 13:30:10'),(105,105,9,NULL,'2023-02-11 13:30:10','2023-02-11 13:30:10'),(106,105,3,NULL,'2023-02-11 13:30:10','2023-02-11 13:30:10'),(107,107,5,NULL,'2023-03-01 06:33:54','2023-03-01 06:33:54'),(108,110,3,NULL,'2023-03-01 16:14:49','2023-03-01 16:14:49'),(109,113,2,NULL,'2023-03-05 04:14:26','2023-03-05 04:14:26'),(110,113,5,NULL,'2023-03-05 04:14:26','2023-03-05 04:14:26');
/*!40000 ALTER TABLE `fields_of_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor_courses`
--

DROP TABLE IF EXISTS `instructor_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hours` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('face','online','both') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'face',
  `user_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_id` bigint unsigned NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `capacity` tinyint DEFAULT NULL,
  `fixed_amount` tinyint(1) NOT NULL DEFAULT '0',
  `hourly_rate` tinyint(1) NOT NULL DEFAULT '0',
  `on_site` tinyint(1) NOT NULL DEFAULT '0',
  `online` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `instructor_courses_user_id_foreign` (`user_id`),
  KEY `instructor_courses_course_id_foreign` (`course_id`),
  CONSTRAINT `instructor_courses_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `instructor_courses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_courses`
--

LOCK TABLES `instructor_courses` WRITE;
/*!40000 ALTER TABLE `instructor_courses` DISABLE KEYS */;
INSERT INTO `instructor_courses` VALUES (1,'Cupiditate ex eiusmo','350','online',1,7,'2022-03-15 12:04:08','2022-03-15 12:04:08',3,'Duis nulla quis labo',56,1,0,1,1),(2,'Ea aspernatur et rer','116','online',5,4,'2022-03-15 12:10:34','2022-03-15 12:10:34',1,'Molestias doloremque',24,0,1,1,1),(4,'8','100','online',15,9,'2022-03-16 20:02:44','2022-03-16 20:02:44',1,'can provide risk',6,1,0,1,0),(6,'Vero quae debitis ve','648','online',33,4,'2022-03-17 15:47:10','2022-03-17 15:47:10',1,'Quis quaerat labore',63,1,0,0,1),(7,'Consequatur ad est','205','online',41,1,'2022-03-17 19:04:44','2022-03-17 19:04:44',2,'Possimus soluta qui',57,1,1,1,1),(8,'20','200','online',73,4,'2022-11-30 18:57:54','2022-11-30 18:57:54',2,'tes',15,1,0,1,1);
/*!40000 ALTER TABLE `instructor_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_role` enum('hiring_manager','recruiter','talent_asquisitions','assistant','office_manager','hr','owner','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'recruiter',
  `user_role_other` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_lang` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_type` enum('online','onsite') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'online',
  `duration_type` enum('days','hours') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hours',
  `duration` int NOT NULL,
  `course_time_type` enum('morning','evening','fullday') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'morning',
  `specific_date` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `course_date` date DEFAULT NULL,
  `course_start` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` bigint unsigned NOT NULL,
  `city_id` bigint unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fixed_amount` int DEFAULT NULL,
  `hourly_rate` int DEFAULT NULL,
  `cv_submit` enum('yes','no','optional') COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_updates` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL DEFAULT '1',
  `sub_category_id` bigint unsigned NOT NULL DEFAULT '1',
  `currency_id` bigint unsigned NOT NULL DEFAULT '1',
  `brief` text COLLATE utf8mb4_unicode_ci,
  `course_time_from` time DEFAULT NULL,
  `course_time_to` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_user_id_foreign` (`user_id`),
  KEY `jobs_category_id_foreign` (`category_id`),
  KEY `jobs_sub_category_id_foreign` (`sub_category_id`),
  KEY `jobs_currency_id_foreign` (`currency_id`),
  CONSTRAINT `jobs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jobs_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jobs_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (4,'Cyber Security Instructor',49,NULL,'2022-03-20 16:21:57','2022-03-20 16:21:57','recruiter',NULL,'arabic','onsite','days',5,'evening','no',NULL,'5weeks',3,7,'<p>Cyber security instructor needed for evening class 6:00 PM to 9:00 PM 5 days </p><p><br></p><p>Day 1  intro to CTF </p><p>Day 2 Web Security </p><p>Day 3 Encryption </p><p>Day 4 Forensic </p><p>Day 5 Data security </p><p><br></p><p>interested Candaties send email to learn@gmail.com  </p>',NULL,3000,'yes','wsadani@hotmail.com',3,7,5,NULL,NULL,NULL),(5,'Magnam labore dolore',45,NULL,'2022-03-22 15:24:28','2022-03-22 15:24:28','owner',NULL,'arabic','online','hours',78,'morning','no',NULL,NULL,3,8,'<p>Dolore aut non aut i.</p>',NULL,71,'yes','hagerhussien@bakerysoft.net',1,2,2,NULL,NULL,NULL),(6,'Business Analyze instructor needed in KSA',17,NULL,'2022-04-01 10:18:46','2022-04-01 10:18:46','recruiter',NULL,'english','onsite','days',5,'morning','no','2022-04-03',NULL,2,5,'<p>the course will be :</p><p>how Plan and establish stratigic plan</p><p>how delevire percise functional</p>',3000,NULL,'yes','wsadani@gmail.com',1,2,1,NULL,NULL,NULL),(7,'Cupiditate in aperia',45,NULL,'2022-04-03 12:14:24','2022-04-03 12:14:24','office_manager',NULL,'arabic','online','days',3,'morning','no','2022-04-15',NULL,2,6,'<p>Asperiores a omnis q.</p>',NULL,22,'optional','hagerhussien@bakerysoft.net',1,1,1,NULL,NULL,NULL),(8,'test request',17,NULL,'2022-04-03 19:02:45','2022-04-03 19:02:45','hiring_manager',NULL,'arabic','onsite','days',34,'morning','no',NULL,'3weeks',1,2,'<p>test request </p>',NULL,20,'yes','wsadani@gmail.com',2,3,1,NULL,NULL,NULL),(9,'Business and Finance Instructor',17,NULL,'2022-04-08 12:11:47','2022-04-08 12:11:47','owner',NULL,'english','onsite','days',365,'morning','no',NULL,'8weeks',2,4,'<p><span style=\"color: rgb(32, 33, 36);\">The Business and Finance Instructor will be responsible for assisting in the continuous updating of the curriculum and teaching students in the Institute various concepts of Business and Finance as it relates to various industries including printing, packaging and plastics. The instructor will be teaching the diploma programs for Financial Analyst, Supply Chain Specialist, Administrative Assistant, and Retail Sales. The instructor will also assist in the practical training components of students program. Activities and operations include working with other Institute staff to identify areas of the field- specific knowledge that require improvement within the student body, participating in the development of curriculum, coordinating with other Instructors to integrate curricula, and teaching classes with up to 25 students for up to 20 hours per week. The Instructor reports to the Director of Academics.</span></p><p><br></p><p><span style=\"color: rgb(32, 33, 36);\">Essential Job Functions</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Teach up to 20 hours of in class instruction per week.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Maintain positive rapport with all students and create a positive learning environment to adequately communicate lessons.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Enforce the student management and disciplinary policies of the Institute.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Act as an advisor outside of class to support students that require additional training or assistance.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Perform clerical duties, as required, relating to textbooks, instructional supplies, student reports and records, attendance reports, etc.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Participate in curriculum development and planning with other Business Instructors and the Director of Academics.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Utilize technology when teaching including interactive whiteboards and projectors.</span></p><p><br></p><p><span style=\"color: rgb(32, 33, 36);\">Required Skills</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Highly organized and dependable.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Excellent computer aptitude and experience with basic teaching technology including interactive whiteboards, projectors, the</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Microsoft Office Suite (Word, Excel, etc.), and student information systems.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Ability to communicate clearly and concisely both in written and oral form in English and Arabic.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Strong collaborative skills, high energy, excellent follow-up skills, and highly effective relationship building skills are required.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Proven ability to work in a culturally diverse context.</span></p><p><span style=\"color: rgb(32, 33, 36);\">• Prior teaching experience in Saudi Arabia or the GCC is preferred</span></p>',0,NULL,'yes','wsadani@gmail.com',1,1,1,NULL,'03:10:00','17:10:00'),(10,'Quia veniam in rati',25,NULL,'2022-04-10 11:27:02','2022-04-10 11:27:02','hr',NULL,'german','online','days',45,'fullday','no',NULL,'2weeks',1,2,'<p>Ex saepe culpa, repr.</p>',NULL,67,'yes','abdofifa15@gmail.com',2,3,6,NULL,'19:31:00','13:50:00'),(11,'Web designer',49,NULL,'2022-06-06 16:35:15','2022-06-06 16:35:15','hr',NULL,'arabic','online','days',20,'morning','no',NULL,NULL,1,1,'<p>need 3 year web designer wh o kno wthe following </p><p><br></p><p>1-illustartor </p><p>2-</p>',NULL,NULL,'yes','wsadani@hotmail.com',5,8,1,NULL,NULL,NULL),(12,'test',17,NULL,'2022-06-13 16:53:29','2022-06-13 16:53:29','recruiter',NULL,'english','online','days',12,'evening','no',NULL,NULL,1,1,'<p>test request for designer&nbsp;</p>',NULL,NULL,'yes','wsadani@gmail.com',5,8,1,NULL,NULL,NULL),(13,'test request web designer',17,NULL,'2022-06-13 16:57:36','2022-06-13 16:57:36','assistant',NULL,'spanish','onsite','hours',30,'morning','no',NULL,'1week',2,5,'<p>test request web designer&nbsp;</p>',500,NULL,'yes','wsadani@gmail.com',5,8,1,NULL,NULL,NULL),(14,'test designer 2',17,NULL,'2022-06-17 13:54:25','2022-06-17 13:54:25','recruiter',NULL,'english','onsite','days',20,'morning','no',NULL,'5weeks',3,9,'<p>test designer 2</p>',NULL,NULL,'yes','wsadani@gmail.com',5,8,1,NULL,NULL,NULL),(15,'VMWARE instructor nodded',17,NULL,'2022-10-03 00:22:16','2022-10-03 00:22:16','talent_asquisitions',NULL,'english','onsite','days',3,'morning','no','2022-10-09',NULL,1,1,'<p>Course name:&nbsp;Veeam Availability Suite v11: Configuration and Management</p><p>Duration: 3 Days</p><p>Expected Start Date: We need to start as soon as we can as morning class</p><p>Location: Egypt</p><p><br></p><p>If anyone interested, please send you updated word doc format resume ASAP for the next proces</p>',NULL,NULL,'yes','wsadani@gmail.com',3,6,1,NULL,NULL,NULL),(16,'BMC Atrium Orchestrator 7.5',91,NULL,'2023-01-03 19:33:40','2023-01-03 19:33:40','hr',NULL,'english','onsite','days',5,'morning','no','2023-01-05',NULL,2,4,'<p>BMC Atrium Orchestrator 7.5</p>',5000,NULL,'yes','wsadani@hotmail.com',3,16,4,NULL,'09:00:00','17:00:00'),(17,'ISO 27001 Foundation Training',91,NULL,'2023-03-25 21:20:13','2023-03-25 21:20:13','hiring_manager',NULL,'english','online','hours',40,'morning','no',NULL,'6weeks',1,1,'<p>Need an Instructor to provide </p><ul><li>Understand The Requirements Of ISO/IEC 27001, Its Clauses, And How Each One Actually Works In The Real World</li><li><br></li><li>Understand Information Security Controls And How They Can And Should Work In Any Organization</li><li><br></li><li>Understand Information Security Concepts And Principles From The Perspective Of ISO 27001</li><li><br></li><li>How To Conduct, Consult, And Participate In Information Security Audits</li><li><br></li><li>How You Can Demonstrate Leadership And Commitment In Relation To ISO 27001 And Your Organization’s ISMS</li><li><br></li><li>Gain An Exact Understanding Of All The Requirements For Information Security Controls According To The ISO/IEC 27001 Standard</li><li><br></li><li>How You Can Meaningfully Participate In The Implementation Of An Information Security Management Systems (ISMS) In A Variety Of Types And Sizes Of Organizations</li><li><br></li><li>Understand All Of The Requirements Necessary For An Organization To Successfully Obtain ISO/IEC 27001 Certification</li></ul><p><br></p>',NULL,NULL,'yes','wsadani@hotmail.com',3,7,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned DEFAULT NULL,
  `comment_id` bigint unsigned DEFAULT NULL,
  `reply_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `likes_post_id_foreign` (`post_id`),
  KEY `likes_comment_id_foreign` (`comment_id`),
  KEY `likes_reply_id_foreign` (`reply_id`),
  KEY `likes_user_id_foreign` (`user_id`),
  CONSTRAINT `likes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `likes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `likes_reply_id_foreign` FOREIGN KEY (`reply_id`) REFERENCES `replies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (1,1,NULL,NULL,5,'2022-03-15 12:10:50','2022-03-15 12:10:50',NULL),(2,1,NULL,NULL,7,'2022-03-15 15:37:56','2022-03-15 15:37:56',NULL),(4,3,NULL,NULL,17,'2022-03-16 20:06:32','2022-03-16 20:06:32',NULL),(11,10,NULL,NULL,41,'2022-03-17 19:50:33','2022-03-17 19:54:06',NULL),(12,10,NULL,NULL,51,'2022-03-20 16:41:47','2022-03-20 16:41:47',NULL),(13,10,NULL,NULL,15,'2022-03-21 20:29:17','2022-03-21 20:29:17',NULL),(14,11,NULL,NULL,45,'2022-03-27 13:35:30','2022-03-27 13:35:30',NULL),(15,13,NULL,NULL,45,'2022-03-27 13:39:28','2022-03-27 13:39:28',NULL),(16,14,NULL,NULL,15,'2022-03-27 17:52:07','2022-03-27 17:52:07',NULL),(17,14,NULL,NULL,49,'2022-03-27 18:00:38','2022-03-27 18:00:38',NULL),(18,3,NULL,NULL,49,'2022-03-27 18:00:45','2022-03-27 18:00:45',NULL),(19,14,NULL,NULL,41,'2022-05-12 07:51:23','2022-05-12 07:51:23',NULL),(20,15,NULL,NULL,15,'2022-05-29 19:04:09','2022-05-29 19:04:09',NULL),(21,15,NULL,NULL,17,'2022-05-29 19:05:16','2022-05-29 19:05:16',NULL),(22,16,NULL,NULL,55,'2022-06-25 23:30:30','2022-06-25 23:30:30',NULL),(23,17,NULL,NULL,15,'2022-06-30 15:43:17','2022-06-30 15:43:17',NULL),(24,18,NULL,NULL,55,'2022-07-01 19:45:44','2022-07-01 19:45:44',NULL),(25,19,NULL,NULL,17,'2022-07-03 17:24:08','2022-07-03 17:24:08',NULL),(26,19,NULL,NULL,60,'2022-10-01 19:19:29','2022-10-01 19:19:29',NULL),(27,21,NULL,NULL,58,'2022-10-10 10:21:32','2022-10-10 10:21:32',NULL),(28,18,NULL,NULL,60,'2022-10-15 13:09:06','2022-10-15 13:09:06',NULL),(29,18,NULL,NULL,94,'2023-01-11 19:55:46','2023-01-11 19:55:46',NULL),(30,17,NULL,NULL,94,'2023-01-11 19:55:50','2023-01-11 19:55:50',NULL),(31,16,NULL,NULL,94,'2023-01-11 19:55:55','2023-01-11 19:55:55',NULL);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2021_11_10_175747_create_posts_table',1),(4,'2021_11_10_175756_create_comments_table',1),(5,'2021_11_10_180553_create_replies_table',1),(6,'2021_11_10_180554_create_likes_table',1),(7,'2021_11_10_222607_add_soft_delete_comments_table',1),(8,'2021_11_10_222724_add_soft_delete_posts_table',1),(9,'2021_11_10_222747_add_soft_delete_replies_table',1),(10,'2021_11_10_222807_add_soft_delete_likes_table',1),(11,'2021_11_10_222941_add_soft_delete_users_table',1),(12,'2021_11_13_120809_add_columns_users',1),(13,'2021_11_13_142933_add_column_users',1),(14,'2021_11_14_160139_create_experiences_table',1),(15,'2021_11_14_160150_create_education_table',1),(16,'2021_11_14_160609_remove_columns_users',1),(17,'2021_11_14_200326_create_certificates_table',1),(18,'2021_11_14_211006_create_categories_table',1),(19,'2021_11_14_211007_create_sub_categories_table',1),(20,'2021_11_14_211008_create_courses_table',1),(21,'2021_11_14_211548_create_instructor_courses_table',1),(22,'2021_11_15_143100_create_employment_types_table',1),(23,'2021_11_15_143101_create_workplace_policies_table',1),(24,'2021_11_15_143102_create_jobs_table',1),(25,'2021_11_17_171038_add_columns_users_cover_image',1),(26,'2021_11_17_171202_drop_column_user_role',1),(27,'2021_11_17_171320_add_column_user_role_users',1),(28,'2021_11_18_004641_create_saved_jobs_table',1),(29,'2021_11_24_154557_create_currencies_table',1),(30,'2021_11_24_180038_add_column_currency_instructor_courses',1),(31,'2021_11_30_162041_add_column_category_id_to_courses',1),(32,'2021_12_02_091755_create_countries_table',1),(33,'2021_12_02_095639_create_cities_table',1),(34,'2021_12_02_105223_remove_city_status_columns_user_table',1),(35,'2021_12_02_105617_add_country_id_city_id_columns_user_table',1),(36,'2021_12_22_124239_update_jobs_table',1),(37,'2021_12_28_110609_update_jobs_table_add_category_sub_category_currency',1),(38,'2022_02_08_125200_add_columns_google_id_and_microsoft_id_to_users_table',1),(39,'2022_02_09_142845_create_company_details_table',1),(40,'2022_02_09_154840_create_fields_of_interests_table',1),(41,'2022_02_09_233018_create_applies_table',1),(42,'2022_02_10_222903_create_contact_us_table',1),(43,'2022_02_13_100737_create_settings_table',1),(44,'2022_02_13_115627_drop_industry_field_from_table_experiences',1),(45,'2022_02_13_115840_add_column_category_id_to_experiences_table',1),(46,'2022_02_15_213043_create_table_user_follows',1),(47,'2022_02_15_221742_delete_location_table_experience',1),(48,'2022_02_15_222008_add_columns_table_experience',1),(49,'2022_02_17_100655_add_columns_table_posts',1),(50,'2022_02_24_110630_add_video_url_to_post',1),(51,'2022_02_27_104729_create_notification_messages_table',1),(52,'2022_02_27_155748_add_column_jobs',1),(53,'2022_02_27_171239_add_column_table_users',1),(54,'2022_02_27_172118_add_columns_table_instructor_courses',1),(55,'2022_03_08_094556_remove_employee_type_table_company_details',1),(56,'2022_03_08_094914_add_column_user_role',1),(57,'2022_03_17_183411_add_column_website_table_users',2),(58,'2022_04_03_081758_drop_jobs_table_course_time',3),(59,'2022_04_03_081938_update_jobs_table_course_time',3),(60,'2022_05_23_124937_drop_notify_on_comment_defualt_value_settings_table',4),(61,'2022_05_23_155217_add_notify_on_comment_post_with_default_value_settigns_table',4),(62,'2022_05_23_190531_add_column_seen_table_notification_messages',4),(63,'2022_06_06_052141_create_c_m_s_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_messages`
--

DROP TABLE IF EXISTS `notification_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_user_id` bigint unsigned NOT NULL,
  `from_user_id` bigint unsigned NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `notification_messages_owner_user_id_foreign` (`owner_user_id`),
  KEY `notification_messages_from_user_id_foreign` (`from_user_id`),
  CONSTRAINT `notification_messages_from_user_id_foreign` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_messages_owner_user_id_foreign` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_messages`
--

LOCK TABLES `notification_messages` WRITE;
/*!40000 ALTER TABLE `notification_messages` DISABLE KEYS */;
INSERT INTO `notification_messages` VALUES (1,1,7,'test test has commented your Post.','2022-03-15 15:38:02','2022-03-15 15:38:02',0),(8,17,41,'Baker Collins has commented your Post.','2022-03-17 19:53:34','2022-03-17 19:53:34',0),(9,17,41,'Baker Collins has Liked your Post.','2022-03-17 19:54:07','2022-03-17 19:54:07',0),(10,17,51,'AHMED GOUDA has Liked your Post.','2022-03-20 16:41:48','2022-03-20 16:41:48',0),(11,17,15,'Start learn has Liked your Post.','2022-03-21 20:29:18','2022-03-21 20:29:18',0),(12,17,15,'Start learn has commented your Post.','2022-03-21 20:29:32','2022-03-21 20:29:32',0),(13,45,33,'Leilani Sears has Applied to your Job Application.','2022-03-24 15:07:51','2022-03-24 15:07:51',0),(14,45,33,'Leilani Sears has Applied to your Job Application.','2022-03-24 15:08:04','2022-03-24 15:08:04',0),(15,47,45,'Ulla Gross has Liked your Post.','2022-03-27 13:35:31','2022-03-27 13:35:31',0),(16,47,45,'Ulla Gross has commented your Post.','2022-03-27 13:35:41','2022-03-27 13:35:41',0),(17,47,45,'Ulla Gross has Liked your Post.','2022-03-27 13:39:28','2022-03-27 13:39:28',0),(18,47,45,'Ulla Gross has commented your Post.','2022-03-27 13:39:39','2022-03-27 13:39:39',0),(19,17,15,'Start learn has Liked your Post.','2022-03-27 17:52:08','2022-05-25 20:40:46',1),(20,17,15,'Start learn has commented your Post.','2022-03-27 17:52:50','2022-05-25 20:40:46',1),(21,15,17,'Wael Mohammed has commented your Post.','2022-03-27 17:53:47','2022-05-29 18:58:04',1),(22,17,49,'Wael GOUDA has Liked your Post.','2022-03-27 18:00:39','2022-05-25 20:40:46',1),(23,15,49,'Wael GOUDA has commented your Post.','2022-03-27 18:01:01','2022-05-29 18:58:04',1),(24,17,41,'Baker Collins has Liked your Post.','2022-05-12 07:51:25','2022-05-25 20:40:46',1),(25,17,55,'%s has Applied to your Job Application.','2022-05-25 15:01:29','2022-05-25 20:40:46',1),(26,17,49,'Wael GOUDA has commented your Post.','2022-05-28 18:30:43','2022-05-28 18:31:35',1),(27,17,49,'Wael GOUDA has commented your Post.','2022-05-28 18:30:44','2022-05-28 18:31:35',1),(28,17,15,'%s has Applied to your Job Application.','2022-05-29 18:59:51','2022-06-06 16:39:05',1),(29,15,15,'%s has Liked your Post.','2022-05-29 19:04:09','2022-05-29 19:06:05',1),(30,15,15,'%s has commented your Post.','2022-05-29 19:04:20','2022-05-29 19:06:05',1),(31,15,17,'%s has Liked your Post.','2022-05-29 19:05:16','2022-05-29 19:06:05',1),(32,15,17,'%s has commented your Post.','2022-05-29 19:05:25','2022-05-29 19:06:05',1),(33,17,55,'%s has Applied to your Job Application.','2022-06-13 16:59:08','2022-06-17 13:55:54',1),(34,49,17,'%s has Liked your Post.','2022-07-03 17:24:08','2022-10-01 19:39:57',1),(35,15,5,'%s has commented your Post.','2022-07-04 12:00:13','2022-11-04 11:12:26',1),(36,49,60,'soso memo has commented your Post.','2022-10-01 19:19:18','2022-10-01 19:39:57',1),(37,49,60,'%s has Liked your Post.','2022-10-01 19:19:29','2022-10-01 19:39:57',1),(38,53,58,'%s has Liked your Post.','2022-10-10 10:21:32','2022-10-10 10:22:18',1),(39,53,58,'%s has commented your Post.','2022-10-10 10:21:53','2022-10-10 10:22:18',1),(40,17,60,'soso memo has Liked your Post.','2022-10-15 13:09:09','2022-10-15 13:10:29',1),(41,91,93,'%s has Applied to your Job Application.','2023-01-03 19:47:23','2023-01-28 13:34:24',1),(42,17,94,'Mohammed ElShaigi has Liked your Post.','2023-01-11 19:55:48','2023-01-11 19:55:48',0),(43,17,94,'Mohammed ElShaigi has Liked your Post.','2023-01-11 19:55:52','2023-01-11 19:55:52',0),(44,17,94,'Mohammed ElShaigi has Liked your Post.','2023-01-11 19:55:57','2023-01-11 19:55:57',0),(45,25,104,'%s has Applied to your Job Application.','2023-02-04 09:07:52','2023-02-04 09:07:52',0);
/*!40000 ALTER TABLE `notification_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('startlearn2021@gmail.com','$2y$10$RmJQRO4yFi.Omqr3sZH/m.rQuIdPnV40K41B5hvSeIJi1uOOghD9W','2022-06-26 18:30:53'),('wsadani@gmail.com','$2y$10$LLtueMiUE3j57NE6O8.reu7BLiOauvF6xlPb6kQLgYqroiCXH2iTi','2022-06-26 18:36:05'),('kazijahidul1987@gmail.com','$2y$10$oJaF4tNM/DMhXD71HrUkbOVXZ1NjM5fwwRtPsgjnX55cMvv5Sfgmm','2023-04-01 19:50:21');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `sub_category_id` bigint unsigned NOT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_user_id_foreign` (`user_id`),
  KEY `posts_category_id_foreign` (`category_id`),
  KEY `posts_sub_category_id_foreign` (`sub_category_id`),
  CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'Ipsa reprehenderit',1,'1647345943_78550_avatar.PNG','2022-03-15 12:05:43','2022-03-15 12:05:43',NULL,1,2,'Rerum excepturi quas'),(3,'Hi there',15,NULL,'2022-03-16 20:03:18','2022-03-16 20:03:18',NULL,3,7,NULL),(6,'Tempora nesciunt do',25,'1647526660_61044_Screen Shot 2022-01-31 at 1.48.31 PM.png','2022-03-17 14:17:40','2022-03-17 14:17:40',NULL,3,6,NULL),(7,'welcome to our website',33,NULL,'2022-03-17 15:48:54','2022-03-17 15:48:54',NULL,1,2,NULL),(10,'test notification',17,NULL,'2022-03-17 19:50:21','2022-03-17 19:50:21',NULL,3,7,NULL),(11,'test N',47,'1648388108_70704_11.PNG','2022-03-27 13:35:08','2022-03-27 13:35:08',NULL,1,1,NULL),(12,'test test',47,'1648388212_34766_avatar1.PNG','2022-03-27 13:36:52','2022-03-27 13:37:14','2022-03-27 13:37:14',2,4,NULL),(13,'test Notification',47,'1648388341_61062_avatar.PNG','2022-03-27 13:39:01','2022-03-27 13:39:01',NULL,2,3,NULL),(14,'This my first post',17,NULL,'2022-03-27 17:51:11','2022-03-27 17:51:11',NULL,3,6,NULL),(15,'New NSE4 series coming soon',15,NULL,'2022-05-29 19:03:46','2022-05-29 19:03:46',NULL,3,7,NULL),(16,'First design post',17,NULL,'2022-06-06 16:43:53','2022-06-06 16:43:53',NULL,5,8,NULL),(17,'Hi this a test post for instructors',17,NULL,'2022-06-30 15:41:24','2022-06-30 15:41:24',NULL,2,3,NULL),(18,'test posts and comments',17,NULL,'2022-07-01 19:45:17','2022-07-01 19:45:17',NULL,9,12,NULL),(19,'Hi  another test for comment',49,NULL,'2022-07-03 17:23:17','2022-07-03 17:23:17',NULL,10,1,NULL),(20,'test',25,NULL,'2022-07-04 13:57:11','2022-07-04 16:14:42','2022-07-04 16:14:42',2,4,NULL),(21,'Ut qui quaerat accus',53,NULL,'2022-10-10 10:20:55','2022-10-10 10:20:55',NULL,5,8,'Atque velit sit in'),(22,'Need ISO 27001 (ISO/IEC 27001) Foundation',91,'1679779401_74033_Screenshot 2023-03-26 002217.png','2023-03-25 21:23:21','2023-03-25 21:23:21',NULL,3,7,'https://www.youtube.com/watch?v=WWWi2RYWczU');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replies`
--

DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `replies_comment_id_foreign` (`comment_id`),
  KEY `replies_user_id_foreign` (`user_id`),
  CONSTRAINT `replies_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replies`
--

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_jobs`
--

DROP TABLE IF EXISTS `saved_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saved_jobs_job_id_foreign` (`job_id`),
  KEY `saved_jobs_user_id_foreign` (`user_id`),
  CONSTRAINT `saved_jobs_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `saved_jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_jobs`
--

LOCK TABLES `saved_jobs` WRITE;
/*!40000 ALTER TABLE `saved_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `notify_on_like_post` tinyint NOT NULL DEFAULT '0',
  `notify_on_apply_job` tinyint NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `notify_on_comment_post` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `settings_user_id_foreign` (`user_id`),
  CONSTRAINT `settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,1,0,0,NULL,'2022-03-15 12:00:53','2022-03-15 12:08:41',1),(2,5,1,0,NULL,'2022-03-15 12:06:52','2022-03-22 10:27:53',1),(3,11,0,0,NULL,'2022-03-15 15:40:38','2022-03-15 15:40:38',1),(5,15,0,0,NULL,'2022-03-16 19:46:42','2022-05-29 19:02:37',0),(8,25,1,0,NULL,'2022-03-17 14:11:51','2022-06-09 12:31:49',1),(11,33,1,0,NULL,'2022-03-17 15:44:47','2022-03-17 15:47:46',1),(15,41,1,0,NULL,'2022-03-17 19:03:13','2022-03-17 19:05:15',1),(17,47,1,0,NULL,'2022-03-17 19:31:53','2022-03-22 10:29:52',1),(18,45,1,0,NULL,'2022-03-17 19:36:12','2022-04-03 12:13:39',1),(19,17,1,0,NULL,'2022-03-17 19:53:19','2022-10-03 00:22:12',1),(20,49,0,0,NULL,'2022-03-20 15:10:13','2022-06-06 16:32:22',1),(21,51,0,0,NULL,'2022-03-20 16:28:26','2022-03-20 16:28:26',1),(22,57,0,0,NULL,'2022-09-25 18:16:44','2022-09-25 18:16:44',1),(23,60,0,0,NULL,'2022-09-26 19:36:26','2022-09-26 19:36:26',1),(24,62,0,0,NULL,'2022-10-01 19:42:53','2022-10-01 19:42:53',1),(25,55,0,0,NULL,'2022-10-11 11:51:22','2022-10-11 11:51:22',1),(26,67,0,0,NULL,'2022-11-03 10:24:35','2022-11-03 10:24:35',1),(27,68,0,0,NULL,'2022-11-04 07:04:22','2022-11-04 10:49:08',1),(28,70,0,0,NULL,'2022-11-07 07:40:24','2022-11-07 07:40:24',1),(29,73,0,0,NULL,'2022-11-30 18:50:46','2022-11-30 18:50:46',1),(30,79,0,0,NULL,'2022-12-12 20:53:21','2022-12-12 20:53:21',1),(31,80,0,0,NULL,'2022-12-12 21:50:45','2022-12-12 21:50:45',1),(32,81,0,0,NULL,'2022-12-12 21:59:36','2022-12-12 21:59:36',1),(33,83,0,0,NULL,'2022-12-13 08:31:18','2022-12-13 08:31:18',1),(34,91,0,0,NULL,'2023-01-03 19:23:42','2023-03-25 21:20:10',1),(35,93,0,0,NULL,'2023-01-03 19:46:25','2023-01-03 19:46:25',1),(36,94,0,0,NULL,'2023-01-11 19:54:47','2023-01-11 19:54:47',1),(37,95,0,0,NULL,'2023-01-25 19:58:15','2023-01-25 19:58:15',1),(38,96,0,0,NULL,'2023-01-28 13:30:21','2023-01-28 13:30:21',1),(39,98,0,0,NULL,'2023-01-30 00:31:27','2023-01-30 00:31:27',1),(40,100,0,0,NULL,'2023-01-30 11:17:41','2023-01-30 11:17:41',1),(41,102,0,0,NULL,'2023-01-31 11:09:26','2023-01-31 11:09:26',1),(42,103,0,0,NULL,'2023-02-02 19:54:29','2023-02-04 09:08:31',1),(43,104,0,0,NULL,'2023-02-03 06:52:49','2023-02-03 06:52:49',1),(44,97,0,0,NULL,'2023-02-04 18:41:49','2023-03-01 16:13:12',1),(45,105,0,0,NULL,'2023-02-11 13:30:10','2023-02-11 13:30:10',1),(46,107,0,0,NULL,'2023-03-01 06:33:54','2023-03-01 06:35:29',1),(47,110,0,0,NULL,'2023-03-01 16:14:49','2023-03-01 16:14:49',1),(48,113,0,0,NULL,'2023-03-05 04:14:26','2023-03-05 04:14:26',1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_categories`
--

DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_categories`
--

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,'Accounting','Accounting',10,NULL,'2022-07-01 19:43:14'),(2,'business Intensive','Business Intensive',1,NULL,NULL),(3,'Web Development','Web Development',2,NULL,NULL),(4,'Mobile Development','Mobile Development',2,NULL,NULL),(5,'Computer Science Fundamentals','Computer Science Fundamentals',2,NULL,NULL),(6,'Networking','Networking',3,NULL,NULL),(7,'Cybersecurity','Cybersecurity',3,NULL,NULL),(8,'Web design','Web Design',5,'2022-06-06 16:30:32','2022-06-06 16:30:32'),(12,'Wireless','Wireless',9,'2022-07-01 19:43:58','2022-07-01 19:43:58'),(13,'Operating Systems & Servers','Operating Systems & Servers',3,'2023-01-02 19:01:19','2023-01-02 19:01:19'),(14,'Business Strategy','Business Strategy',1,'2023-01-02 19:02:36','2023-01-02 19:02:36'),(15,'Project Management','Project Management',1,'2023-01-02 19:03:49','2023-01-02 19:03:49'),(16,'IT certificate','IT certificate',3,'2023-01-02 19:06:03','2023-01-02 19:06:03');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `follower_id` bigint unsigned NOT NULL,
  `followed_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_follows_follower_id_foreign` (`follower_id`),
  KEY `user_follows_followed_id_foreign` (`followed_id`),
  CONSTRAINT `user_follows_followed_id_foreign` FOREIGN KEY (`followed_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_follower_id_foreign` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES (2,11,7),(3,17,15),(4,15,17),(5,17,1),(6,17,5),(7,17,11),(11,33,25),(23,41,17),(26,47,17),(27,33,17),(28,49,1),(29,49,5),(30,49,11),(31,49,15),(32,49,33),(33,49,41),(34,49,47),(35,51,17),(36,51,7),(37,51,25),(38,51,49),(39,51,45),(40,17,33),(41,17,41),(42,17,47),(43,17,51),(44,17,53),(45,55,5),(46,57,7),(47,57,25),(48,62,33),(49,62,15),(50,62,51),(51,62,53),(52,62,57),(53,62,58),(54,62,59),(55,62,60),(56,62,61),(57,62,41),(58,62,11),(59,62,5),(60,62,1),(61,73,17),(62,73,49),(63,73,64),(64,73,62),(65,91,1),(66,91,15),(67,91,33),(68,91,53),(69,91,58),(70,91,59),(71,91,61),(72,91,65),(73,91,66),(74,91,67),(75,91,73),(76,91,77),(77,91,78),(78,91,79),(79,91,80),(80,91,81),(81,91,83),(82,91,84),(83,93,17),(84,94,17),(85,98,58),(86,98,59),(87,102,62),(88,102,63),(89,102,64),(90,102,68),(91,102,69),(92,102,70),(93,102,71),(94,103,1),(95,104,62),(96,91,94),(97,110,7),(98,113,1),(99,113,33);
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `cover_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin','instructor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `country_id` bigint unsigned DEFAULT NULL,
  `city_id` bigint unsigned DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `microsoft_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_category_id` bigint unsigned DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_sub_category_id_foreign` (`sub_category_id`),
  CONSTRAINT `users_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Steven','William','StevenWilliam_1647346001','Quaerat rem elit lo','xivomyzuf@mailinator.com','+1 (759) 242-1945','Itaque enim exercita','29202','1647345966_92206_avatar1.PNG','$2y$10$ok9sCFOg/07tXk6MhToRl.EThjiG8mZqSz3d5swHMPlfJT.BGTXeK',NULL,'2022-03-15 12:00:10','2022-03-15 12:12:55',NULL,NULL,'2022-03-15 12:00:36','1647345980_16560_article-15-ezgif-6-39f0baa439.jpeg','instructor',1,1,NULL,NULL,NULL,NULL),(5,'Uriah','Sandoval','Uriah_1647345990','Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit Anim omnis do velit','abdelrahman.abas@bakerysoft.net','+1 (832) 841-8214',NULL,NULL,'1647346028_29118_Screen Shot 2022-01-28 at 11.03.12 PM.png','$2y$10$8b1.J5c1SkHoo4exP9.dnOTMi.FQTvak6XvWDAP6xr2JroBnXuirG',NULL,'2022-03-15 12:06:30','2022-11-23 10:57:15','2022-11-23 10:57:15',NULL,'2022-03-15 12:06:48',NULL,'instructor',3,8,NULL,NULL,NULL,NULL),(7,'Idona','Sykes','IdonaSykes_1647363773','Ut velit facere mol','dupa@mailinator.com','+1 (544) 188-2091','Nisi explicabo Dolo','89974','1647363469_47556_avatar1.PNG','$2y$10$aeQhWcz4OY036hnIJACfLulAUtRhhQNdFJyJppZVeAIHKmjX04lEG',NULL,'2022-03-15 12:27:04','2022-03-15 17:02:53',NULL,NULL,'2022-03-15 12:31:02',NULL,'user',1,3,NULL,NULL,NULL,NULL),(11,'Raymond','Sweeney','Raymond_1647358812',NULL,'abdofifa16@gmail.com_deleted',NULL,NULL,NULL,NULL,'$2y$10$mU98al0kACFWKez57ZJfFuXbUx/BrP0tGJ8oDbO6z4y1VJVBgpgDS',NULL,'2022-03-15 15:40:12','2022-11-23 21:01:33','2022-11-23 21:01:33',NULL,'2022-03-15 15:40:27','1647358910_76043_Screen Shot 2022-01-24 at 9.09.59 PM.png','instructor',NULL,NULL,NULL,NULL,NULL,NULL),(15,'Start','learn','Start_1647459961','an experienced instructor who can provide course in different domain network , cybersecurity and system , I am TOT certified and have master in cyber security','startlearn2021@gmail.com','00966114332156',NULL,NULL,'1647460155_95599_download.png','$2y$10$82xh//xif09443fC5cKP6.X1lNX21eyJ2CPiVMpYHfcLT4oKe.V9W',NULL,'2022-03-16 19:46:01','2022-03-16 19:58:14',NULL,NULL,'2022-03-16 19:46:22',NULL,'instructor',2,4,NULL,NULL,NULL,NULL),(17,'Wael','Mohammed','Wael_1647461114',NULL,'wsadani@gmail.com','0020100135453454',NULL,NULL,'1648403377_59535_366a38001e9b709648625627dc31c187.png','$2y$10$R8CzVO7sITc9pUVV2AkxrOrPHnlAlwIXuvNchbb2FXeWZDWnOLCoW','TUQzZIXTTkBiQPUoIJz98QzUCGLZ5iG4yFHEo4nCmAtnswZ8lasPZfnGnNQP','2022-03-16 20:05:14','2023-01-23 20:00:18','2023-01-23 20:00:18',NULL,'2022-03-16 20:05:25',NULL,'user',1,3,NULL,NULL,6,NULL),(25,'Hedley','Burt','Hedley_1647526286','Et omnis aperiam ull Et omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ullEt omnis aperiam ull','abdofifa15@gmail.com','+1 (897) 143-2224',NULL,NULL,'1647526538_32953_Screen Shot 2022-01-28 at 11.03.12 PM.png','$2y$10$oktm5mr4YVfVWrGVT2/pTeFsjkXWpm.1Zh39QGkfdlMYXUur7CpBO',NULL,'2022-03-17 14:11:27','2022-03-17 14:16:29',NULL,NULL,'2022-03-17 14:11:45',NULL,'user',3,8,NULL,NULL,4,NULL),(33,'Leilani','Sears','Leilani_1647531865','something','finerteam@gmail.com','01087388743',NULL,NULL,'1647531932_16637_chat-agent.png','$2y$10$IswTea8Wi7H3ihMZHNgVLeORKgxQpTMarLT80CvcQxr7tJByjtBd2',NULL,'2022-03-17 15:44:25','2022-03-17 15:45:43',NULL,NULL,'2022-03-17 15:44:41',NULL,'instructor',1,1,NULL,NULL,NULL,NULL),(41,'Baker','Collins','Baker_1647543770','Sunt ut dolores omn','amr.megahed@bakerysoft.net','+13975828986',NULL,NULL,'1647543816_23023_chat-agent.png','$2y$10$u0WxuB5Begwqkwp5AVebYeuc.lg4uuY5Oa22Bw5fpUQTux7RMezMO',NULL,'2022-03-17 19:02:50','2022-11-23 12:48:48','2022-11-23 12:48:48',NULL,'2022-03-17 19:03:04',NULL,'instructor',1,1,NULL,NULL,NULL,NULL),(45,'Ulla','Gross','Ulla_1647545334',NULL,'hagerhussien@bakerysoft.net',NULL,NULL,NULL,NULL,'$2y$10$j8CLVNpB9PGKJzq/ELe3AuP9asxH1anja.SpqGPdEruHaCJb42eHC',NULL,'2022-03-17 19:28:54','2022-09-12 20:10:37','2022-09-12 20:10:37',NULL,'2022-03-17 19:29:47',NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(47,'Serina','Graham','Serina_1647545371',NULL,'hagerhussien2698@gmail.com','+1 (234) 117-9942',NULL,NULL,'1647851629_89449_avatar1.PNG','$2y$10$bM.j.mODiTOyUbEFYobBUe0EyaybHBdM0Iu5nGjHrFN2PP.Ilp2Ou',NULL,'2022-03-17 19:29:31','2022-09-17 10:41:36','2022-09-17 10:41:36',NULL,'2022-03-17 19:31:43',NULL,'instructor',3,7,NULL,NULL,NULL,NULL),(49,'Wael','GOUDA','Wael_1647788960','A leading cybersecurity company','wsadani@hotmail.com_deleted','0097152031456',NULL,NULL,NULL,'$2y$10$aEpaxbaAkmi5LtSs0LKV1u65KdWvV2oL4AwWKiQQzVhkp.hSGGO5W',NULL,'2022-03-20 15:09:20','2022-12-27 17:50:53','2022-12-27 17:50:53',NULL,'2022-03-20 15:09:55',NULL,'user',3,7,NULL,NULL,7,NULL),(51,'AHMED','GOUDA','AHMED_1647793681','a cyber security instructor for more 5 years providing \nSecurity + \nCCNA security coursed','cutememowael@gmail.com_deleted','0097152345697',NULL,NULL,NULL,'$2y$10$ivb2HkK6R0AmiUtZ6iXu3Ood.iSZjlgFiKPijr19BoXeJXCzAcAQ.','c5IkY6jHzVRZ7BcwORQgcnVnRjD4bXQpAt8DXATVgExKZIWWnC7YLWHQNg9U','2022-03-20 16:28:01','2022-11-23 21:01:46','2022-11-23 21:01:46',NULL,'2022-03-20 16:28:13',NULL,'instructor',3,NULL,NULL,NULL,NULL,NULL),(53,'Ariel','Whitley','Ariel_1648563475',NULL,'eng.abdelrahman.ahmed11@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$RD5R/6vsUnEWKtuLaExmguCL/zzob170XdPymqfl6Znq5U0T/kv9C',NULL,'2022-03-29 14:17:56','2022-03-29 14:18:22',NULL,NULL,'2022-03-29 14:18:22',NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(55,'admin','admin','admin_1651263982',NULL,'admin@admin.com',NULL,NULL,NULL,NULL,'$2y$10$dX20Vm/tVA5ou8Q9qg.zCeCbnGbuV0zBtQ0vti2EQ0P6EvIRkVoi2',NULL,'2022-04-29 20:26:22','2022-04-29 20:26:22',NULL,NULL,'2022-04-29 20:26:22',NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL),(56,'test1','test2','test user',NULL,'test@test.com_deleted',NULL,NULL,NULL,NULL,NULL,NULL,'2022-09-17 17:44:05','2022-11-04 13:12:09','2022-11-04 13:12:09',NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(57,'Mohamed','Metwally','Mohamed_1664109510',NULL,'muhamedmetwally@bakerysoft.net',NULL,NULL,NULL,NULL,'$2y$10$bjciQJK8kn5lXJS0GZvN..Efe.y9IZmPvCQkQlJJESr9QtHe/eIRe',NULL,'2022-09-25 12:38:31','2022-11-23 21:00:57','2022-11-23 21:00:57',NULL,'2022-09-25 18:16:02',NULL,'instructor',NULL,NULL,'111758246172877775712',NULL,NULL,NULL),(58,'Abdelrahman','Ahmed','Abdelrahman_1664109891',NULL,'abdelrahman.abas11493@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$wSJZcM8jV25vTIyDTn2fxO58pVmsenVhvKmNFCKzudgFWYFiVBiYi',NULL,'2022-09-25 12:44:52','2022-09-25 12:44:52',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'111964169159115429057',NULL,NULL,NULL),(59,'MuhaMmed','Metwally','MuhaMmed_1664109964',NULL,'muhamedmetwally94@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$TivKFl1zX4406.7xLXAyL.JBTVFtHcR/O/Bamx/5Pl0U04d2yqgVC',NULL,'2022-09-25 12:46:04','2022-09-25 12:46:04',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'112933228905642288719',NULL,NULL,NULL),(60,'soso','memo','soso_1664123417',NULL,'sosoandmemoland@gmail.com_deleted',NULL,NULL,NULL,NULL,'$2y$10$KO2tvPcgGNBlkF9KTfxh5evtfeQNpjhGxRHS8rOa7AFMdSrKJmz1K',NULL,'2022-09-25 16:30:17','2022-12-31 13:46:56','2022-12-31 13:46:56',NULL,'2022-09-26 19:36:03',NULL,'instructor',NULL,NULL,'100650221192212278235',NULL,NULL,NULL),(61,'Mohamed','Metwally','Mohamed_1664126591',NULL,'discovermyinfo@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$pDY0GmedJ2ibQy4khajnBuwpMbRStgygT2YhqQRFRAyr0Rs9p7FEO',NULL,'2022-09-25 17:23:11','2022-09-25 17:23:11',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'104627268474884653086',NULL,NULL,NULL),(62,'Start learn','at peconto','Start_learn_1664653321',NULL,'startlearnatpeconto@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$Mm6UuG942rpR3V54BU.Knu.xDElt6wyWQG/4woRFCDNKyLN0ZqY52',NULL,'2022-10-01 19:42:01','2022-10-01 19:42:40',NULL,NULL,'2022-10-01 19:42:40',NULL,'user',NULL,NULL,'113520193772813045284',NULL,NULL,NULL),(63,'charli','charli','charli_1666597324',NULL,'ccharli491@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$6azSEJBb3.ju91tyeM7Ug.eRQS4tsYTD1kgecTPbc4CiDLLYoAg3O',NULL,'2022-10-24 07:42:04','2022-10-24 07:42:04',NULL,NULL,NULL,NULL,'user',NULL,NULL,'108283879960783717854',NULL,NULL,NULL),(64,'Dua','Alim','Dua_1666604117',NULL,'duaalem@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$RsufpzlwEEtwXwmWHFf4keGwepmEs9gKcp7QVfjl7/rwqM4kheELW',NULL,'2022-10-24 09:35:17','2022-10-24 09:35:17',NULL,NULL,NULL,NULL,'user',NULL,NULL,'117690670239840407115',NULL,NULL,NULL),(65,'AVBInvest','Limited','AVBInvest_1666605153',NULL,'avbinvestltd@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$WXe6nfzvwapL17nntQWO/Oaz0WrE75czItiz.rQXTfattqH1ZkoNq',NULL,'2022-10-24 09:52:33','2022-10-24 09:53:00',NULL,NULL,'2022-10-24 09:53:00',NULL,'instructor',NULL,NULL,'114606457619346474660',NULL,NULL,NULL),(66,'Life By Design','With Lady Si','Life_By_Design_1666608335',NULL,'justsiluvuno@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$R1MqbXRQhi4n85WyeLJMGePDp2w0dO4urhdA8V.ZrAQR6PVlgFkz2',NULL,'2022-10-24 10:45:35','2022-10-24 10:45:57',NULL,NULL,'2022-10-24 10:45:57',NULL,'instructor',NULL,NULL,'108806513032697898057',NULL,NULL,NULL),(67,'alaa','helala','alaa_1667471026',NULL,'3laa.helala@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$rw9eHEzTTLIlU245ZJ75BeXewnpWDaSzxIXAKWeB2Mi086nXFdV7K',NULL,'2022-11-03 10:23:46','2022-11-03 10:24:12',NULL,NULL,'2022-11-03 10:24:12',NULL,'instructor',NULL,NULL,'106296781940171027201',NULL,NULL,NULL),(68,'zeeshan','khan','zeeshan_1667545369',NULL,'xeeshii@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$cM3L1Y8CcA8Kja799wuFTeU/PjHE10uTSj4.2RzhN7LyO6GXs2d/a',NULL,'2022-11-04 07:02:49','2022-11-04 07:03:12',NULL,NULL,'2022-11-04 07:03:12',NULL,'user',NULL,NULL,'109739123734506107720',NULL,NULL,NULL),(69,'Taha','Niazi','Taha_1667570861',NULL,'tahaasadniazi2003@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$GqVHNTxal4qfGiKoiDJmae94qaMXWuuxJXBI1pOmKKv8CcArHEbeK',NULL,'2022-11-04 14:07:41','2022-11-04 14:08:44',NULL,NULL,'2022-11-04 14:08:44',NULL,'user',NULL,NULL,'105329831261873206426',NULL,NULL,NULL),(70,'Sufian','Ahmad','Sufian_1667806782',NULL,'sufian.personal.14@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$IS5m4gOSakYO.8TaCOrfYuQlQSQ9vtX7u8CiGcFbKIsmJ5RHtZolG',NULL,'2022-11-07 07:39:42','2022-11-07 07:40:08',NULL,NULL,'2022-11-07 07:40:08',NULL,'user',NULL,NULL,'114552636524807172012',NULL,NULL,NULL),(71,'Mariam','Wael','Mariam_1668018022',NULL,'MARIAMGOUDA2010@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$sfwhnNh/7FPK2WYSfgpAX.RaOZI/leB5dm5DBcBhyKwvXjty5B3UG',NULL,'2022-11-09 18:20:22','2022-11-09 18:21:08',NULL,NULL,'2022-11-09 18:21:08',NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(73,'Ahmed','Wael','Ahmed_1669834107','I am Python  instructor','Awgoda2012@outlook.com','05678780212',NULL,NULL,NULL,'$2y$10$fjRUn9FX8oFCsY4sMKWBMOo8pJHDfJU1qpK05u3ofyekHQeDJhBLK',NULL,'2022-11-30 18:48:27','2022-11-30 18:54:10',NULL,NULL,'2022-11-30 18:49:57',NULL,'instructor',3,7,NULL,NULL,NULL,NULL),(75,'test','test 1','test_1670442152',NULL,'dremanhamed10@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$L4lF9.Eq5lzfTHuuG7kIju9pPQ4y9y2dDNLTL0GIO3X7nDFfHO/9u',NULL,'2022-12-07 19:42:32','2022-12-07 20:00:07',NULL,NULL,'2022-12-07 20:00:07',NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(77,'Matthew','Ayiku','Matthew_1670738610',NULL,'ayikumatthew@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$hPw04rC4Occ1ZOCDChixSeSqxAh/tNkmc3rj7JSSVlWOnaQKFi3Vq',NULL,'2022-12-11 06:03:30','2022-12-11 06:03:30',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'103962717524062667133',NULL,NULL,NULL),(78,'Md Roni','Biswas','Md_Roni_1670877029',NULL,'ronibiswasup@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$uIg/TXZrqUCgfW29gBNU3eTcu3i7jFnhk/THifwrzX/9XpqlU5IiO',NULL,'2022-12-12 20:30:29','2022-12-12 20:30:29',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'100037631064118577622',NULL,NULL,NULL),(79,'Chong John','Chuah','Chong_John_1670878337',NULL,'topcj7@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$mnUA2ALsBACnh48Ay3N2ouy4O9a7bx/VlutL/G7Ibu/JMUs1iuOiO',NULL,'2022-12-12 20:52:17','2022-12-12 20:53:11',NULL,NULL,'2022-12-12 20:53:11',NULL,'instructor',NULL,NULL,'110302204125022831839',NULL,NULL,NULL),(80,'Shaima','Ahmed','Shaima_1670881778',NULL,'shaimabadawi994@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$Kxhm5UJkRBxOY6/CIjkWR.NDH6eF5T5dw4KIHLGu/hCzeNp6X9T2i',NULL,'2022-12-12 21:49:38','2022-12-12 21:50:15',NULL,NULL,'2022-12-12 21:50:15',NULL,'instructor',NULL,NULL,'104148125723333330422',NULL,NULL,NULL),(81,'Dylan','Moore','Dylan_1670882305',NULL,'dylan@dmr.mobi',NULL,NULL,NULL,NULL,'$2y$10$YQ1g3sO/PvZtzrFalWkJueikBvPgOU2BGxu6tV9xpMl0xl5hdmpT2',NULL,'2022-12-12 21:58:25','2022-12-12 21:59:19',NULL,NULL,'2022-12-12 21:59:19',NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(83,'Muhammad Zaheer','Khan','Muhammad_Zaheer_1670920132',NULL,'mmzaheerkhan@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$oVKIf7fnAdwt35EcGksnSeD/sETmPQen1poQQcGju3ylnq951fowK',NULL,'2022-12-13 08:28:52','2022-12-13 08:30:46',NULL,NULL,'2022-12-13 08:30:46',NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(84,'Ashely','Hays','Ashely_1670932269',NULL,'gicexi7197@paxven.com',NULL,NULL,NULL,NULL,'$2y$10$i5ieqq4CfFwcLUdTsAC06uHZIlwWDVCklg1sK6MTA6FyvXHFc70Ta',NULL,'2022-12-13 11:51:09','2022-12-13 11:51:09',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(86,'test','test','test_1670940113',NULL,'yagiyo2407@nazyno.com',NULL,NULL,NULL,NULL,'$2y$10$Y.rSQV6R3P6vViLYlQnviu1K.Rnw8pSyxFHiqy6mzsrE764TvBUL6',NULL,'2022-12-13 14:01:53','2022-12-13 14:01:53',NULL,NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(88,'Wael','Ahmed','wsadani@hotmail.com',NULL,'wsadani@hotmail.com_deleted',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-02 18:27:51','2023-01-02 18:28:07','2023-01-02 18:28:07',NULL,NULL,NULL,'user',3,7,NULL,NULL,NULL,NULL),(89,'Soso','Ahmed','Soso_1672684595',NULL,'Cutememo@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$HtjhY/CfmS1cSDwuzJERPO9x35sweT1mIccMMdg.B6GHKLbzKhD4.',NULL,'2023-01-02 18:36:35','2023-01-03 19:37:17','2023-01-03 19:37:17',NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(91,'Wael','Ahmed','Wael_1672773726',NULL,'wsadani@hotmail.com',NULL,NULL,NULL,NULL,'$2y$10$rSwfQhMGetrgDagG.wZhne5fDnpoq/u910ZqPw1mmoWKiiUsLHeAu',NULL,'2023-01-03 19:22:06','2023-01-03 19:23:29',NULL,NULL,'2023-01-03 19:23:29',NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(93,'Memo','Time','Memo_1672774880',NULL,'cutememowael@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$rvPK/70cNWmeC8Gle3u1u.ewdLrf3NEoJnILj5bFI1dQij1xyJ/my',NULL,'2023-01-03 19:41:20','2023-01-03 19:43:04',NULL,NULL,'2023-01-03 19:43:04',NULL,'instructor',NULL,NULL,'105951343882473401110',NULL,NULL,NULL),(94,'Mohammed','ElShaigi','Mohammed_1673466849',NULL,'mhshaigi@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$7461.pcey6XCgHZB5zYSV.QgdYJhPiSnRcjxSKSNxhqzzm7Dy5TfO',NULL,'2023-01-11 19:54:09','2023-01-11 19:54:34',NULL,NULL,'2023-01-11 19:54:34',NULL,'instructor',NULL,NULL,'101390231710906921742',NULL,NULL,NULL),(95,'Mohamed','Helala','Mohamed_1674676661',NULL,'m.s.helala.2020@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$CHeTdDBrkpWyNry1aEXXhe0V8ciDqc.oVx8TUsk8ThXVY9gztS0sO',NULL,'2023-01-25 19:57:41','2023-01-25 19:58:03',NULL,NULL,'2023-01-25 19:58:03',NULL,'user',NULL,NULL,'112290461573958262880',NULL,NULL,NULL),(96,'WAEL','Instructor','WAEL_1674912585',NULL,'waelinstructor2022@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$mkofMWbkSTMW/aPWkUYNiuiHHlZX7nXrF8nrhHWXliiXlr57x9.nW','YRsTLlSuSJrDXDqxek5nObA4GLAT7JOu0XxzULU3Ac4vYz1zWebkC88Ujrpr','2023-01-28 13:29:46','2023-02-19 17:50:25',NULL,NULL,'2023-01-28 13:30:01',NULL,'instructor',1,1,'106954726143813643596',NULL,NULL,NULL),(97,'Muhammed','Elbeihairy','Muhammed_1675038604','afasfsafas','m.elbeihairy@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$ojRL8TcpnKgTsklWLaFWAeMBHhggbZbDaKNnSnaZn1LDhUEFVyvz2',NULL,'2023-01-30 00:30:04','2023-02-27 03:18:29',NULL,NULL,'2023-02-04 18:41:42',NULL,'user',1,1,'106420818314801954710',NULL,2,NULL),(98,'Chukwuebuka','Eze','Chukwuebuka_1675038609',NULL,'connect.kecnation@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$2HKmxH5tF40sqzi7MZU/y.O3xFdlXfNvTFjtwtWb6gb2UcxIytXW2',NULL,'2023-01-30 00:30:09','2023-01-30 00:31:02',NULL,NULL,'2023-01-30 00:31:02',NULL,'user',NULL,NULL,'113652405619646925890',NULL,NULL,NULL),(99,'Med Amine','Ben Hmida','Med_Amine_1675040657',NULL,'aminebenhmida1999@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$lWpvB9FsSWVkAX6z8V2E0uSSEJCEzLBJouWiLVWPYiJrruM02IGVa',NULL,'2023-01-30 01:04:17','2023-01-30 01:04:17',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'110607677053927865399',NULL,NULL,NULL),(100,'Ahmed','Magdy','Ahmed_1675075326',NULL,'ahmadmagdynaser@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$7IhK72QdA4SqTwbFMaj3ZudzbmQUV7xSXiR/RWuXBFAJUXJboZw4y',NULL,'2023-01-30 10:42:06','2023-01-30 11:17:21',NULL,NULL,'2023-01-30 11:17:21',NULL,'instructor',NULL,NULL,'116365278760908031656',NULL,NULL,NULL),(101,'Oleksandra','Tonachova','Oleksandra_1675112520',NULL,'tonachovatarget@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$MK8xoGXDVyvOWz9JMr7zV.rJFC/O1Ezcli4atwqvYQtwDjTSPYSX6',NULL,'2023-01-30 21:02:00','2023-01-30 21:02:00',NULL,NULL,NULL,NULL,'user',NULL,NULL,'106249163380239617414',NULL,NULL,NULL),(102,'Vadym','Derevianko','Vadym_1675163338',NULL,'slogger1990@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$9s/Nh6Uo7nm/RWLF4iGy6.UbgqUWElKoDc.rVjg5G.h6jGMnzm0LS',NULL,'2023-01-31 11:08:58','2023-01-31 11:09:15',NULL,NULL,'2023-01-31 11:09:15',NULL,'instructor',NULL,NULL,'101576831252607371184',NULL,NULL,NULL),(103,'Ahmed','AlRashid Design','Ahmed_1675364592',NULL,'ahmed.ali.alrashid@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$hoXRKS/2/dKfiY4e2jLyqOVOEdhFofKbTZZ0Ss4gO8dif0c9n0ISC',NULL,'2023-02-02 19:03:12','2023-02-02 19:54:17',NULL,NULL,'2023-02-02 19:54:17',NULL,'user',NULL,NULL,'103156785277824839464',NULL,NULL,NULL),(104,'ahmed','ali','ahmed_1675407140',NULL,'maajestty@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$VtNn0mzjJjN5vbMNYoFvQecGqRsWAvzNg0fg5yTX8mjCQEkzJV9/6',NULL,'2023-02-03 06:52:20','2023-02-03 06:52:42',NULL,NULL,'2023-02-03 06:52:42',NULL,'instructor',NULL,NULL,'107200970571915003095',NULL,NULL,NULL),(105,'Mustafa','Elkhalifa','Mustafa_1676122172',NULL,'phpier2@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$V.Ud2zUUOxlRYWtIOYSS.u5ff.OP97Mlf0Yl5lNm1c0RGeznvlxpW',NULL,'2023-02-11 13:29:32','2023-02-11 13:30:01',NULL,NULL,'2023-02-11 13:30:01',NULL,'instructor',NULL,NULL,'110660032926361093707',NULL,NULL,NULL),(106,'Muhammed','Nasr','Muhammed_1677463840',NULL,'nasrmuhammed711@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$n3crNmgX5jgdP.QdmTRcpub6EIAJ5G7BeKrt9fAYpvQJtZcOQcjDi',NULL,'2023-02-27 02:10:40','2023-02-27 02:12:29',NULL,NULL,'2023-02-27 02:12:29',NULL,'user',NULL,NULL,'108470819524707688842',NULL,NULL,NULL),(107,'design','Whiteflame','design_1677652371',NULL,'design@whiteflame.com.au',NULL,NULL,NULL,NULL,'$2y$10$lL49g/doGHUEu9YO/RAk9uBKSmjqU.4SBaPTrweBlkUiRE0czXOom',NULL,'2023-03-01 06:32:51','2023-03-01 06:33:23',NULL,NULL,'2023-03-01 06:33:23',NULL,'user',NULL,NULL,'112159415853623105782',NULL,NULL,NULL),(108,'Muhammed','nasr','Muhammed_1677686415',NULL,'moelbeihiri@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$oQFVk1iF2TAEjN05HY/CiumuwkeLluuYLq9LwdzMf4I32vdhJiQ2W',NULL,'2023-03-01 16:00:15','2023-03-01 16:00:43',NULL,NULL,'2023-03-01 16:00:43',NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(110,'Learn','peconto','Learn_1677687227','a 13 year Expert instructor in cyber security','waelinstructor2023@gmail.com','0020100777555666',NULL,NULL,NULL,'$2y$10$6iwfSKINlPQqLSLnBKi2seHPj.6N4uIGcJuFG0QEriW2VZULEXpz2',NULL,'2023-03-01 16:13:47','2023-03-01 16:16:25',NULL,NULL,'2023-03-01 16:13:56',NULL,'instructor',1,2,NULL,NULL,NULL,NULL),(113,'Ghada','abouzaid','Ghada_1677988830',NULL,'Ghada.abouzeid1508@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$8Dr2poxxnW4D56JD/.8R6.aOeDhLPHG4nW1BlVXTdy2tMKNwiySnC',NULL,'2023-03-05 04:00:30','2023-03-05 04:04:57',NULL,NULL,'2023-03-05 04:04:57',NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(115,'Jahidul','Islam','Jahidul_1680204896',NULL,'kazijahidul1987@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$4kc.FiAav1SPRRhfcDCzeuSBlREDG5v81Bn8RQLnyQ4od54XH6vyC',NULL,'2023-03-30 19:34:56','2023-03-30 19:34:56',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,NULL,NULL,NULL,NULL),(116,'Jahidul','Islam','Jahidul_1680378954',NULL,'kzis@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$3gJWbCBRQhna3Jc3mKpe7umDUdvwDljBuf9eZOa00gkS2cTalCKXS',NULL,'2023-04-01 19:55:54','2023-04-01 19:55:54',NULL,NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),(118,'Jahidul','Islam','Jahidul_1680380755',NULL,'jahidul.teknovus@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$uOJx/r4FuwOUQ4isDDCEAuJT5/I6dSwhSvXp3ugHQMzLzq9dbrYr6',NULL,'2023-04-01 20:25:55','2023-04-01 20:25:55',NULL,NULL,NULL,NULL,'instructor',NULL,NULL,'108427733909031630243',NULL,NULL,NULL),(119,'Jahidul','Islam','Jahidul_1680468260',NULL,'jahiduldev@gmail.com',NULL,NULL,NULL,NULL,'$2y$10$M.Ue.OMGpJDQJr3Vy/Xc1ep3mWWGfLQ9WKheDAFuUeRMuOpn9stj2',NULL,'2023-04-02 20:44:21','2023-04-02 20:44:21',NULL,NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workplace_policies`
--

DROP TABLE IF EXISTS `workplace_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workplace_policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workplace_policies`
--

LOCK TABLES `workplace_policies` WRITE;
/*!40000 ALTER TABLE `workplace_policies` DISABLE KEYS */;
INSERT INTO `workplace_policies` VALUES (1,'on_site','On-site','Employees come to work in-person',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(2,'hybrid','Hybrid','Employees work on-site and off-site',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20'),(3,'remote','Remote','Employees work off-site',NULL,'2022-03-15 11:59:20','2022-03-15 11:59:20');
/*!40000 ALTER TABLE `workplace_policies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-04 22:53:42
